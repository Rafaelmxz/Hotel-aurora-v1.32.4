import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { O as formatCurrency } from "./bookingStore-Bq0ubAXy.mjs";
import { o as Trash2 } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/FolioStatement-D_wrLK-R.js
var import_jsx_runtime = require_jsx_runtime();
var TIPO_LABEL = {
	diaria: "Diária",
	consumo: "Consumo",
	pagamento: "Pagamento"
};
function FolioStatement({ linhas, totais, onRemoveConsumo }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-lg border border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-secondary text-xs tracking-wide text-muted-foreground uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Lançamento"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Qtd"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Valor"
							}),
							onRemoveConsumo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-2 py-2" }) : null
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: linhas.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: onRemoveConsumo ? 4 : 3,
						className: "px-3 py-4 text-muted-foreground",
						children: "Nenhum lançamento na conta."
					}) }) : linhas.map((linha) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-[11px] tracking-wide text-muted-foreground uppercase",
									children: TIPO_LABEL[linha.tipo]
								}), linha.descricao]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 tabular-nums",
								children: linha.quantidade
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-2 tabular-nums",
								children: [linha.tipo === "pagamento" ? "− " : "", formatCurrency(Math.abs(linha.total))]
							}),
							onRemoveConsumo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2 text-right",
								children: linha.removivel ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-label": `Remover ${linha.descricao}`,
									className: "inline-flex size-8 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground",
									onClick: () => onRemoveConsumo(linha.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								}) : null
							}) : null
						]
					}, linha.id)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-2 gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Diárias"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-right tabular-nums",
						children: formatCurrency(totais.totalDiarias)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Consumo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-right tabular-nums",
						children: formatCurrency(totais.totalConsumo)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Pagamentos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "text-right tabular-nums",
						children: ["− ", formatCurrency(totais.totalPagamentos)]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-secondary px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Saldo da conta"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display mt-1 text-3xl font-medium tracking-tight tabular-nums",
					children: formatCurrency(totais.saldo)
				})]
			})
		]
	});
}
//#endregion
export { FolioStatement as t };
