import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as DialogDescription, n as DialogClose, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { g as addHours, i as format, t as ptBR, y as addDays } from "../_libs/date-fns.mjs";
import { G as parseISODate, O as formatCurrency, c as TODAY, l as TODAY_ISO, r as HOLD_REASON_LABEL, s as OverbookingError, tt as roomHoldReason, ut as toISODate } from "./bookingStore-Bq0ubAXy.mjs";
import { C as ChevronLeft, S as ChevronRight, a as TriangleAlert, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Nt as typeHoldsParty, Pt as cn, _t as quoteNewReservation, a as Input, i as Label, o as Button, p as useProperty } from "./router-D2QglEY4.mjs";
import { r as STATUS_LABEL } from "./status-lXSun_aS.mjs";
import { a as useReservations, r as useCreateReservation } from "./useReservations-BEok-WZp.mjs";
import { r as useRooms } from "./useRooms-DVLudIq6.mjs";
import { n as useGuestSearch } from "./useGuests-BJjZTm3Q.mjs";
import { t as useRoomTypes } from "./useRoomTypes-B7WZBIgo.mjs";
import { t as useBlocks } from "./useBlocks-Dt0MBuAT.mjs";
import { r as useSaleCloses } from "./useSaleCloses-BDBCA2UD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/PendingBookingsAlert-CWuJWCAN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function OnMapDialog({ open, onOpenChange, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		modal: false,
		open,
		onOpenChange,
		children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Fechar fundo",
			className: "absolute inset-0 z-40 cursor-default bg-transparent",
			onClick: () => onOpenChange(false)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			onOpenAutoFocus: (event) => event.preventDefault(),
			onInteractOutside: (event) => event.preventDefault(),
			onPointerDownOutside: (event) => event.preventDefault(),
			onFocusOutside: (event) => event.preventDefault(),
			style: { transform: "translateX(-50%)" },
			className: cn("absolute top-10 left-1/2 z-50 w-[min(32rem,calc(100%-2rem))] max-h-[min(36rem,calc(100dvh-6rem))] overflow-y-auto rounded-xl border border-border bg-card p-6 shadow-[var(--shadow-border)]", className),
			children
		})] }) : null
	});
}
function GuestSearch({ onSelect }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const { data: results = [] } = useGuestSearch(query);
	const open = query.trim().length >= 2 && results.length > 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value: query,
			onChange: (event) => setQuery(event.target.value),
			placeholder: "Nome ou CPF",
			autoComplete: "off",
			"aria-label": "Buscar hóspede"
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "absolute z-30 mt-1 max-h-56 w-full overflow-auto rounded-lg border border-border bg-card shadow-md",
			children: results.map((guest) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: cn("flex w-full flex-col items-start px-3 py-2 text-left text-sm hover:bg-secondary"),
				onClick: () => {
					onSelect(guest);
					setQuery(guest.name);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: guest.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [
						guest.cpf,
						" · ",
						guest.tags.join(" · ") || "sem tag"
					]
				})]
			}) }, guest.id))
		}) : null]
	});
}
/**
* Ficha do balcão: datas → pessoas → quarto → hóspede → origem → criar.
* Pode: pré-reserva pendente com prazo, ou reserva confirmada.
* Proibido: OTA, tarifário por segmento, Experiências, Pix, folio extra.
* Grava: reservationStore (cofre). Preço: quoteStay. Vaga: overbooking.
* Lista risca ocupado / bloqueado / venda fechada / tipo que não cabe.
*/
var ORIGINS = [
	"Balcão",
	"Telefone",
	"WhatsApp",
	"Site"
];
var STRIP_DAYS = 7;
function tomorrowIso() {
	return toISODate(addDays(parseISODate(TODAY_ISO), 1));
}
function CreateReservationModal({ open, onOpenChange, draft = null }) {
	const { data: rooms = [] } = useRooms();
	const { data: types = [] } = useRoomTypes();
	const { data: reservations = [] } = useReservations();
	const { data: blocks = [] } = useBlocks();
	const { data: saleCloses = [] } = useSaleCloses();
	const { data: property } = useProperty();
	const create = useCreateReservation();
	const [guest, setGuest] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [origin, setOrigin] = (0, import_react.useState)("Balcão");
	const [adults, setAdults] = (0, import_react.useState)(2);
	const [children, setChildren] = (0, import_react.useState)(0);
	const [roomId, setRoomId] = (0, import_react.useState)("");
	const [checkIn, setCheckIn] = (0, import_react.useState)(TODAY_ISO);
	const [checkOut, setCheckOut] = (0, import_react.useState)(() => tomorrowIso());
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(null);
	const [stripStart, setStripStart] = (0, import_react.useState)(TODAY);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setGuest(null);
		setName("");
		setPhone("");
		setEmail("");
		setOrigin("Balcão");
		setAdults(2);
		setChildren(0);
		const inDate = draft?.checkIn && draft.checkIn >= TODAY_ISO ? draft.checkIn : TODAY_ISO;
		const outDate = draft?.checkOut && draft.checkOut > inDate ? draft.checkOut : toISODate(addDays(parseISODate(inDate), 1));
		setRoomId(draft?.roomId ?? "");
		setCheckIn(inDate);
		setCheckOut(outDate);
		setNotes("");
		setSaving(null);
		setStripStart(parseISODate(inDate) < TODAY ? TODAY : parseISODate(inDate));
	}, [open, draft]);
	const previewDays = (0, import_react.useMemo)(() => Array.from({ length: STRIP_DAYS }, (_, index) => addDays(stripStart, index)), [stripStart]);
	const typeByName = (0, import_react.useMemo)(() => new Map(types.map((row) => [row.type, row])), [types]);
	const roomRows = (0, import_react.useMemo)(() => {
		return rooms.map((room) => {
			const profile = typeByName.get(room.type);
			const fits = profile ? typeHoldsParty(profile, adults, children) : true;
			const hold = roomHoldReason(room, reservations, checkIn, checkOut, blocks, saleCloses);
			return {
				room,
				fits,
				hold,
				free: hold === "livre"
			};
		});
	}, [
		rooms,
		typeByName,
		adults,
		children,
		reservations,
		checkIn,
		checkOut,
		blocks,
		saleCloses
	]);
	const freeRooms = roomRows.filter((row) => row.free);
	const freeIds = freeRooms.map((row) => row.room.id).join(",");
	const selected = roomRows.find((row) => row.room.id === roomId) ?? null;
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const ids = freeIds ? freeIds.split(",") : [];
		if (roomId && ids.includes(roomId)) return;
		setRoomId(ids[0] ?? "");
	}, [
		open,
		freeIds,
		roomId
	]);
	const quote = (0, import_react.useMemo)(() => {
		if (!roomId || !checkIn || !checkOut) return null;
		try {
			return quoteNewReservation(roomId, checkIn, checkOut, {
				adults,
				children
			});
		} catch {
			return null;
		}
	}, [
		roomId,
		checkIn,
		checkOut,
		adults,
		children
	]);
	const holdLabel = (0, import_react.useMemo)(() => {
		const hours = property?.cancelFreeHours ?? 48;
		const until = addHours(/* @__PURE__ */ new Date(), hours);
		return {
			hours,
			iso: until.toISOString(),
			text: format(until, "d MMM HH:mm", { locale: ptBR })
		};
	}, [property?.cancelFreeHours]);
	function applyGuest(next) {
		setGuest(next);
		setName(next.name);
		setEmail(next.email);
		setPhone(next.phone);
		if (next.tags.includes("Inadimplente") || next.preferences.length) toast.warning(`${next.name}: ${[...next.tags, ...next.preferences].slice(0, 3).join(" · ")}`);
	}
	function setIn(iso) {
		setCheckIn(iso);
		if (checkOut <= iso) setCheckOut(toISODate(addDays(parseISODate(iso), 1)));
		const picked = parseISODate(iso);
		const end = addDays(stripStart, 6);
		if (picked < stripStart || picked > end) setStripStart(picked < TODAY ? TODAY : picked);
	}
	async function save(mode) {
		if (!name.trim()) {
			toast.error("Informe o nome do hóspede.");
			return;
		}
		if (!selected?.free) {
			toast.error("Escolha um quarto livre nestas datas.");
			return;
		}
		setSaving(mode);
		const party = Math.max(1, adults) + Math.max(0, children);
		const holdLine = mode === "hold" ? `Confirmar até ${holdLabel.text} (${holdLabel.hours}h)` : "";
		const extra = [
			notes.trim(),
			guest?.preferences.join("; "),
			holdLine
		].filter(Boolean).join(" · ");
		try {
			await create.mutateAsync({
				roomId: selected.room.id,
				guestName: name.trim(),
				guestEmail: email,
				guestPhone: phone,
				checkIn,
				checkOut,
				guests: party,
				adults,
				children,
				origin,
				notes: extra || void 0,
				status: mode === "hold" ? "pendente" : "confirmada",
				holdUntil: mode === "hold" ? holdLabel.iso : void 0
			});
			toast.success(mode === "hold" ? `Pré-reserva de ${name} até ${holdLabel.text}` : `Reserva criada · ${name}`);
			onOpenChange(false);
		} catch (error) {
			const message = error instanceof OverbookingError || error instanceof Error ? error.message : "Não foi possível criar a reserva.";
			toast.error(message);
		} finally {
			setSaving(null);
		}
	}
	const busy = create.isPending || saving !== null;
	const canBook = Boolean(selected?.free && name.trim());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(OnMapDialog, {
		open,
		onOpenChange,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-display text-xl font-medium tracking-tight",
				children: "Nova reserva"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Datas e ocupação primeiro. Depois o quarto que cabe, e o hóspede."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
				className: "absolute top-4 right-4 opacity-70 hover:opacity-100",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "Fechar"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Check-in" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								required: true,
								min: TODAY_ISO,
								value: checkIn,
								onChange: (event) => setIn(event.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Check-out" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								required: true,
								min: toISODate(addDays(parseISODate(checkIn), 1)),
								value: checkOut,
								onChange: (event) => setCheckOut(event.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Disponibilidade (7 dias)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								size: "icon",
								className: "size-9 shrink-0",
								"aria-label": "Dias anteriores",
								disabled: stripStart <= TODAY,
								onClick: () => setStripStart((current) => {
									const next = addDays(current, -7);
									return next < TODAY ? TODAY : next;
								}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex min-w-0 flex-1 gap-1",
								children: previewDays.map((day) => {
									const iso = format(day, "yyyy-MM-dd");
									const next = toISODate(addDays(day, 1));
									const anyFree = rooms.some((room) => roomHoldReason(room, reservations, iso, next, blocks, saleCloses) === "livre");
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: !anyFree,
										onClick: () => setIn(iso),
										className: cn("flex h-9 min-w-0 flex-1 flex-col items-center justify-center rounded-md text-[11px] leading-none tabular-nums", !anyFree ? "cursor-not-allowed bg-destructive/15 text-destructive line-through" : iso === checkIn ? "bg-primary text-primary-foreground" : "bg-secondary"),
										title: !anyFree ? "Sem quarto livre" : iso,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[9px] uppercase opacity-70",
											children: format(day, "EEEEE", { locale: ptBR })
										}), format(day, "d")]
									}, iso);
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								size: "icon",
								className: "size-9 shrink-0",
								"aria-label": "Próximos dias",
								onClick: () => setStripStart((current) => addDays(current, STRIP_DAYS)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "new-adults",
								children: "Adultos"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "new-adults",
								inputMode: "numeric",
								value: String(adults),
								onChange: (event) => setAdults(Math.max(1, Number(event.target.value) || 1))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "new-children",
								children: "Crianças"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "new-children",
								inputMode: "numeric",
								value: String(children),
								onChange: (event) => setChildren(Math.max(0, Number(event.target.value) || 0))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Quarto" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid max-h-44 gap-1 overflow-y-auto rounded-lg border border-border p-1",
								children: roomRows.map(({ room, fits, hold, free }) => {
									const reason = !fits ? "capacidade + extra" : HOLD_REASON_LABEL[hold];
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										disabled: !free,
										onClick: () => setRoomId(room.id),
										className: cn("flex w-full items-center justify-between rounded-md px-3 py-2 text-left text-sm", free ? roomId === room.id ? "bg-primary text-primary-foreground" : "hover:bg-secondary" : "cursor-not-allowed text-muted-foreground"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: cn(!free && "line-through"),
											children: [
												room.number,
												" · ",
												room.type
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-xs opacity-80",
											children: reason
										})]
									}) }, room.id);
								})
							}),
							freeRooms.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-destructive",
								children: "Nenhum quarto livre nestas datas."
							}) : null,
							selected && !selected.fits ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg border-2 border-destructive bg-destructive/15 p-4 text-destructive",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-semibold leading-tight",
									children: "Capacidade excedida"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm",
									children: [
										selected.room.type,
										" cabe ",
										typeByName.get(selected.room.type)?.maxAdults ?? "?",
										" ",
										"adulto(s) e ",
										typeByName.get(selected.room.type)?.maxChildren ?? 0,
										" criança(s). Pode confirmar: entra taxa extra +ADL / +CHD."
									]
								})]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Busca de hóspede" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuestSearch, { onSelect: applyGuest })]
					}),
					guest && (guest.preferences.length > 0 || guest.tags.length > 0) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 rounded-lg bg-status-pending/10 px-3 py-3 text-sm text-status-pending",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [guest.tags.join(" · "), guest.preferences.length ? ` · ${guest.preferences.join(" · ")}` : ""] })]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "new-name",
							children: "Nome"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "new-name",
							required: true,
							value: name,
							placeholder: "Se a busca não achar, cadastre aqui",
							onChange: (event) => setName(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "new-phone",
								children: "Telefone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "new-phone",
								value: phone,
								onChange: (event) => setPhone(event.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "new-email",
								children: "E-mail (opcional)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "new-email",
								type: "email",
								value: email,
								onChange: (event) => setEmail(event.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "new-origin",
							children: "Origem"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "new-origin",
							className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
							value: origin,
							onChange: (event) => setOrigin(event.target.value),
							children: ORIGINS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: row,
								children: row
							}, row))
						})]
					}),
					quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							quote.nights,
							" noites · ",
							formatCurrency(quote.total),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-2 text-muted-foreground",
								children: "tarifa do hotel"
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "new-notes",
							children: "Observação"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "new-notes",
							maxLength: 160,
							value: notes,
							placeholder: "Chega tarde, berço…",
							onChange: (event) => setNotes(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							disabled: busy || !canBook,
							onClick: () => void save("hold"),
							children: [
								"Pré-reserva · ",
								holdLabel.hours,
								"h"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							disabled: busy || !canBook,
							onClick: () => void save("confirm"),
							children: "Criar reserva"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"Pré-reserva entra pendente e segura a vaga até ",
							holdLabel.text,
							". Criar confirma agora."
						]
					})
				]
			})
		]
	});
}
/**
* Pedidos do site na recepção. No mapa: faixa compacta com rolagem.
* Clique abre a reserva no pop-up. Não confirma, não mexe ouro/OTA.
*/
function PendingBookingsAlert({ map = false, onSelect }) {
	const { data: reservations = [] } = useReservations();
	const { data: rooms = [] } = useRooms();
	const pending = reservations.filter((row) => row.status === "pendente" || row.origin === "Link público" && row.status === "confirmada").sort((a, b) => a.checkIn.localeCompare(b.checkIn) || a.guestName.localeCompare(b.guestName));
	if (pending.length === 0) return null;
	const roomLabel = (roomId) => {
		const room = rooms.find((item) => item.id === roomId);
		return room ? `${room.number}` : roomId;
	};
	if (map && onSelect) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex max-h-16 items-stretch gap-2 overflow-hidden rounded-lg bg-status-pending/10 px-2 py-1 text-status-pending",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "flex shrink-0 items-center text-xs font-medium",
			children: [pending.length, " pedidos"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pending-scroll flex min-h-0 min-w-0 flex-1 flex-col flex-wrap content-start gap-1 overflow-x-auto overflow-y-auto",
			children: pending.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => onSelect(row),
				className: "h-6 shrink-0 rounded-md bg-card px-2 text-left text-xs text-foreground",
				title: `${row.guestName} · ${roomLabel(row.roomId)} · ${row.checkIn}`,
				children: [row.guestName, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "ml-1 text-muted-foreground",
					children: [
						roomLabel(row.roomId),
						" · ",
						STATUS_LABEL[row.status]
					]
				})]
			}, row.id))
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-xl bg-status-pending/10 px-4 py-3 text-sm text-status-pending",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-medium",
			children: [
				pending.length,
				" pedido(s) do site aguardando a recepção.",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/calendario",
					className: "underline",
					children: "Abrir mapa da recepção"
				})
			]
		})
	});
}
//#endregion
export { OnMapDialog as n, PendingBookingsAlert as r, CreateReservationModal as t };
