import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { O as formatCurrency, k as formatStayRange, lt as stayNights } from "./bookingStore-Bq0ubAXy.mjs";
import { d as Printer, m as Mail } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Input, i as Label, o as Button } from "./router-D2QglEY4.mjs";
import { t as locatorOf } from "./voucherMail-B5SCu78P.mjs";
import { r as STATUS_LABEL } from "./status-lXSun_aS.mjs";
import { t as renderSVG } from "../_libs/uqr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/StayVoucher-BMRYBVTZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/** Payload Pix (BR Code EMV) no padrão do Banco Central. */
function tlv(id, value) {
	return id + String(value.length).padStart(2, "0") + value;
}
function crc16(payload) {
	let crc = 65535;
	for (let i = 0; i < payload.length; i += 1) {
		crc ^= payload.charCodeAt(i) << 8;
		for (let bit = 0; bit < 8; bit += 1) crc = crc & 32768 ? (crc << 1 ^ 4129) & 65535 : crc << 1 & 65535;
	}
	return crc.toString(16).toUpperCase().padStart(4, "0");
}
function asciiField(value, max) {
	return (value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Za-z0-9 ]/g, " ").replace(/\s+/g, " ").trim().toUpperCase() || "HOTEL").slice(0, max);
}
function pixCityFromAddress(address) {
	return asciiField((address.match(/([^,—\-]+)\s*\/\s*[A-Za-z]{2}/)?.[1] ?? address.split("—").pop() ?? "SAO PAULO").trim(), 15);
}
function pixTxid(seed) {
	return `AUR${(seed.replace(/[^A-Za-z0-9]/g, "").toUpperCase() || Date.now().toString(36).toUpperCase()).slice(-21)}`.slice(0, 25);
}
function buildPixPayload(input) {
	const key = input.key.trim();
	if (!key) throw new Error("Informe a chave Pix do hotel.");
	const amount = Math.round(input.amount * 100) / 100;
	if (!(amount > 0)) throw new Error("Valor do Pix inválido.");
	const merchant = tlv("00", "BR.GOV.BCB.PIX") + tlv("01", key) + (input.description ? tlv("02", input.description.slice(0, 72)) : "");
	const additional = tlv("05", pixTxid(input.txid) || "***");
	const body = tlv("00", "01") + tlv("26", merchant) + tlv("52", "0000") + tlv("53", "986") + tlv("54", amount.toFixed(2)) + tlv("58", "BR") + tlv("59", asciiField(input.name, 25)) + tlv("60", asciiField(input.city, 15)) + tlv("62", additional) + "6304";
	return body + crc16(body);
}
function PixCharge({ amount, pixKey, payee, address, seed, description }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const txid = (0, import_react.useMemo)(() => pixTxid(seed), [seed]);
	const payload = (0, import_react.useMemo)(() => {
		try {
			return buildPixPayload({
				key: pixKey,
				name: payee,
				city: pixCityFromAddress(address),
				amount,
				txid,
				description
			});
		} catch {
			return "";
		}
	}, [
		pixKey,
		payee,
		address,
		amount,
		txid,
		description
	]);
	const svg = (0, import_react.useMemo)(() => payload ? renderSVG(payload, {
		border: 2,
		pixelSize: 4,
		blackColor: "currentColor",
		whiteColor: "transparent"
	}) : "", [payload]);
	async function copy() {
		if (!payload) return;
		try {
			await navigator.clipboard.writeText(payload);
			setCopied(true);
			toast.success("Código Pix copiado.");
		} catch {
			toast.error("Não foi possível copiar. Selecione o código e copie.");
		}
	}
	if (!pixKey.trim()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "O hotel ainda não cadastrou a chave Pix em Hotel."
	});
	if (!payload) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Não foi possível montar o Pix."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 rounded-lg bg-secondary p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-medium",
				children: ["Pix · ", formatCurrency(amount)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					payee,
					" · chave ",
					pixKey
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-48 text-foreground",
				"aria-hidden": true,
				dangerouslySetInnerHTML: { __html: svg }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs text-muted-foreground",
				children: "Abra o app do banco e leia o QR"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				readOnly: true,
				value: payload,
				className: "min-h-16 w-full resize-none rounded-md border border-input bg-card px-3 py-2 font-mono text-[11px] leading-snug",
				"aria-label": "Pix copia e cola"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				onClick: () => void copy(),
				children: copied ? "Código copiado" : "Copiar Pix (copia e cola)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] text-muted-foreground",
				children: ["Identificador ", txid]
			})
		]
	});
}
function pixNote(txidSeed, percent) {
	return `Sinal Pix ${percent}% · txid ${pixTxid(txidSeed)}`;
}
function StayVoucher({ reservation, roomLabel, hotelName, address, phone, checkInTime, checkOutTime, cancellationPolicy, totais, heading, emailedTo }) {
	const nights = stayNights(reservation.checkIn, reservation.checkOut);
	const title = heading ?? (reservation.status === "pendente" ? "Pré-reserva" : "Comprovante de reserva");
	const [to, setTo] = (0, import_react.useState)(reservation.guestEmail);
	const [sentTo, setSentTo] = (0, import_react.useState)(emailedTo ?? "");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function sendEmail() {
		setBusy(true);
		try {
			const { sendVoucherEmailFn } = await import("./api-iTCU0mCO.mjs").then((n) => n.t);
			const result = await sendVoucherEmailFn({ data: {
				to,
				reservationId: reservation.id,
				heading: title,
				guestName: reservation.guestName,
				roomLabel,
				checkIn: reservation.checkIn,
				checkOut: reservation.checkOut,
				statusLabel: STATUS_LABEL[reservation.status],
				hotelName,
				address,
				phone,
				checkInTime,
				checkOutTime,
				cancellationPolicy,
				totalDiarias: totais.totalDiarias,
				totalConsumo: totais.totalConsumo,
				totalPagamentos: totais.totalPagamentos,
				saldo: totais.saldo
			} });
			setSentTo(result.to);
			toast.success(result.delivered ? `Voucher enviado para ${result.to}.` : `Voucher na caixa do hotel para ${result.to}.`);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível enviar o e-mail.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "stay-voucher rounded-xl bg-card p-5 shadow-[var(--shadow-border)] sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
				children: hotelName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display mt-1 text-2xl font-medium tracking-tight",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					"Localizador ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: locatorOf(reservation.id)
					}),
					" · ",
					STATUS_LABEL[reservation.status]
				]
			}),
			sentTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-emerald-800",
				children: [
					"Enviado para ",
					sentTo,
					"."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-5 grid gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted-foreground",
							children: "Hóspede"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-right font-medium",
							children: reservation.guestName
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted-foreground",
							children: "E-mail"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-right",
							children: reservation.guestEmail
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted-foreground",
							children: "Quarto"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-right",
							children: roomLabel
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted-foreground",
							children: "Estadia"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "text-right",
							children: [formatStayRange(reservation.checkIn, reservation.checkOut), ` · ${nights} ${nights === 1 ? "noite" : "noites"}`]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted-foreground",
							children: "Horários"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "text-right",
							children: [
								"Check-in ",
								checkInTime,
								" · Check-out ",
								checkOutTime
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 grid grid-cols-2 gap-2 border-t border-border pt-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Diárias"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-right tabular-nums",
						children: formatCurrency(totais.totalDiarias)
					}),
					totais.totalConsumo > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Consumo"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-right tabular-nums",
						children: formatCurrency(totais.totalConsumo)
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Pagamentos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "text-right tabular-nums",
						children: ["− ", formatCurrency(totais.totalPagamentos)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-medium",
						children: "Saldo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-right font-medium tabular-nums",
						children: formatCurrency(totais.saldo)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-muted-foreground",
				children: cancellationPolicy
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-muted-foreground",
				children: [address, phone ? ` · ${phone}` : ""]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print mt-5 grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `voucher-email-${reservation.id}`,
							className: "text-xs",
							children: "Enviar por e-mail"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `voucher-email-${reservation.id}`,
							type: "email",
							value: to,
							onChange: (event) => setTo(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						className: "w-full",
						disabled: busy,
						onClick: () => void sendEmail(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4" }), busy ? "Enviando…" : sentTo ? "Reenviar voucher" : "Enviar voucher por e-mail"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						className: "w-full",
						onClick: () => window.print(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Imprimir voucher"]
					})
				]
			})
		]
	});
}
//#endregion
export { pixTxid as i, StayVoucher as n, pixNote as r, PixCharge as t };
