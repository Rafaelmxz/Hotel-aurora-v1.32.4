import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-inRQBZ0y.mjs";
import { D as _enum, F as object, P as number, R as string, k as array } from "../_libs/@better-auth/core+[...].mjs";
import { g as createSsrRpc } from "./router-D2QglEY4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-iTCU0mCO.js
var api_exports = /* @__PURE__ */ __exportAll({
	listVoucherEmailsFn: () => listVoucherEmailsFn,
	pullHotelVaultFn: () => pullHotelVaultFn,
	pullPublicBookingsFn: () => pullPublicBookingsFn,
	pullPublicStayFn: () => pullPublicStayFn,
	pushHotelVaultFn: () => pushHotelVaultFn,
	sendVoucherEmailFn: () => sendVoucherEmailFn,
	submitPublicBookingFn: () => submitPublicBookingFn
});
var ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
var pullHotelVaultFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("108224dbb03326c14fd5c672c8fa6a4ccc20ea6e7d7f23e2572a005203b5f723"));
/** Fatia leve: pedidos do site (tabela + cofre). A recepção sempre une isto, mesmo se o cofre local for mais novo. */
var pullPublicBookingsFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("3cb3ea539046505fae972085faec85390d2abbd767d0b43059e1c90932b9d364"));
var pushHotelVaultFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ payload: string().min(2) })).handler(createSsrRpc("e807183d1903ae609e0d162302385a3123e32333ce7ac8ae43d0ce91df77264f"));
var pullPublicStayFn = createServerFn({ method: "GET" }).handler(createSsrRpc("8a2e751109d872e14f1505ddf6dfc6d7af574adeb3af3bef671c9eefe9202045"));
var publicBookingSchema = object({
	id: string().min(3).max(80),
	roomId: string().min(1).max(80),
	guestName: string().trim().min(2).max(120),
	guestEmail: string().min(3).max(160),
	checkIn: string().regex(ISO_DATE),
	checkOut: string().regex(ISO_DATE),
	guests: number().int().min(1).max(8).optional(),
	nightlyRate: number().nonnegative(),
	totalAmount: number().nonnegative(),
	notes: string().max(500).optional(),
	status: _enum(["pendente", "confirmada"]).optional(),
	deposit: object({
		id: string().min(3).max(80),
		valor: number().positive(),
		metodo: _enum([
			"pix",
			"cartao_credito",
			"cartao_debito",
			"dinheiro"
		]),
		descricao: string().max(200),
		observacao: string().max(300).optional(),
		data_pagamento: string().regex(ISO_DATE).optional()
	}).optional(),
	extras: array(object({
		id: string().min(3).max(80),
		descricao: string().min(2).max(120),
		valor: number().nonnegative(),
		quantidade: number().int().min(1).max(20)
	})).max(8).optional()
});
var submitPublicBookingFn = createServerFn({ method: "POST" }).validator(publicBookingSchema).handler(createSsrRpc("d18aa834b90fa5eb29bd7a12cde9748b36f4fe1c6956be714aa452ffbc9e9853"));
var sendVoucherSchema = object({
	to: string().min(3).max(160),
	reservationId: string().min(3).max(80),
	heading: string().max(80).optional(),
	guestName: string().min(1).max(120),
	roomLabel: string().min(1).max(120),
	checkIn: string().regex(ISO_DATE),
	checkOut: string().regex(ISO_DATE),
	statusLabel: string().min(1).max(40),
	hotelName: string().min(1).max(120),
	address: string().max(240),
	phone: string().max(40),
	checkInTime: string().max(12),
	checkOutTime: string().max(12),
	cancellationPolicy: string().max(400),
	totalDiarias: number().nonnegative(),
	totalConsumo: number().nonnegative(),
	totalPagamentos: number().nonnegative(),
	saldo: number()
});
var sendVoucherEmailFn = createServerFn({ method: "POST" }).validator(sendVoucherSchema).handler(createSsrRpc("d995be9cfd96a693b4ae9d292fc3033b6b534252172708ca24ba1cbe3de1d7ef"));
var listVoucherEmailsFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("50364d2359e124ab8ab04748eb0f6ffb6a696ecebabc72647e5ff90393da8839"));
//#endregion
export { listVoucherEmailsFn as n, api_exports as t };
