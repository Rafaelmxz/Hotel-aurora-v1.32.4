import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { t as authMiddleware } from "./middleware-inRQBZ0y.mjs";
import { B as mergeReservations, F as isSiteBooking, K as parseVault, R as mergeConsumos, U as normalizeExtras, W as occupancyOf, _ as assertValidPeriod, g as assertValidEmail, lt as stayNights, p as appendWithoutOverbooking, st as splitPublicPending, u as VAULT_ID, v as assertVaultTransition, w as extraQuantity, z as mergePagamentos } from "./bookingStore-Bq0ubAXy.mjs";
import { D as _enum, F as object, P as number, R as string, k as array } from "../_libs/@better-auth/core+[...].mjs";
import { i as voucherMailText, n as voucherMailHtml, r as voucherMailSubject } from "./voucherMail-B5SCu78P.mjs";
import { r as STATUS_LABEL } from "./status-lXSun_aS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-ir_89aMU.js
async function deliverMail(payload) {
	const key = process.env.RESEND_API_KEY?.trim();
	const from = process.env.VOUCHER_FROM_EMAIL?.trim() || "Hotel Aurora <noreply@hotelaurora.com>";
	if (!key) return {
		delivered: false,
		channel: "caixa"
	};
	try {
		if (!(await fetch("https://api.resend.com/emails", {
			method: "POST",
			headers: {
				Authorization: `Bearer ${key}`,
				"Content-Type": "application/json"
			},
			body: JSON.stringify({
				from,
				to: payload.to,
				subject: payload.subject,
				html: payload.html,
				text: payload.text
			})
		})).ok) return {
			delivered: false,
			channel: "caixa"
		};
		return {
			delivered: true,
			channel: "resend"
		};
	} catch {
		return {
			delivered: false,
			channel: "caixa"
		};
	}
}
var ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
async function loadPendingReservations(sql) {
	const rows = await sql`
    select payload from hotel_public_pending where hotel_id = ${VAULT_ID}
  `;
	const reservations = [];
	const deposits = [];
	const consumos = [];
	for (const row of rows) try {
		const split = splitPublicPending(JSON.parse(row.payload));
		if (!split) continue;
		reservations.push(split.reservation);
		if (split.deposit) deposits.push(split.deposit);
		consumos.push(...split.consumos);
	} catch {}
	return {
		reservations,
		deposits,
		consumos
	};
}
function siteSliceOf(vault, pendings) {
	const fromVault = (vault?.reservations ?? []).filter(isSiteBooking);
	const reservations = mergeReservations(fromVault, pendings.reservations);
	const publicIds = new Set(reservations.map((row) => row.id));
	const fromVaultPays = (vault?.pagamentos ?? []).filter((item) => publicIds.has(item.reserva_id));
	const fromVaultConsumos = (vault?.consumos ?? []).filter((item) => publicIds.has(item.reserva_id));
	return {
		reservations,
		pagamentos: mergePagamentos(fromVaultPays, pendings.deposits),
		consumos: mergeConsumos(fromVaultConsumos, pendings.consumos)
	};
}
function protectSiteBookings(client, server, pendings) {
	const slice = siteSliceOf(server, pendings);
	return {
		...client,
		reservations: mergeReservations(client.reservations, slice.reservations),
		pagamentos: mergePagamentos(client.pagamentos ?? [], slice.pagamentos),
		consumos: mergeConsumos(client.consumos ?? [], slice.consumos),
		savedAt: Date.now()
	};
}
function absorbPendings(vault, pendings) {
	if (!vault) return null;
	return {
		...vault,
		reservations: mergeReservations(vault.reservations, pendings.reservations),
		pagamentos: mergePagamentos(vault.pagamentos ?? [], pendings.deposits),
		consumos: mergeConsumos(vault.consumos ?? [], pendings.consumos)
	};
}
async function loadVault(sql) {
	const rows = await sql`
    select payload from hotel_vault where id = ${VAULT_ID} limit 1
  `;
	return parseVault(rows[0]?.payload);
}
async function saveVault(sql, vault) {
	const payload = JSON.stringify(vault);
	if ((await sql`
    select id from hotel_vault where id = ${"aurora"} limit 1
  `).length) await sql`
      update hotel_vault
      set payload = ${payload}, updated_at = now()
      where id = ${VAULT_ID}
    `;
	else await sql`
      insert into hotel_vault (id, payload)
      values (${VAULT_ID}, ${payload})
    `;
}
async function ensureMembership(sql, userId) {
	const current = (await sql`
    select role from hotel_member
    where user_id = ${userId} and hotel_id = ${VAULT_ID}
    limit 1
  `)[0]?.role;
	if (current === "admin" || current === "recepcionista") return current;
	const countRows = await sql`
    select count(*)::int as n from hotel_member where hotel_id = ${VAULT_ID}
  `;
	const role = Number(countRows[0]?.n ?? 0) === 0 ? "admin" : "recepcionista";
	await sql`
    insert into hotel_member (user_id, hotel_id, role)
    values (${userId}, ${VAULT_ID}, ${role})
    on conflict (user_id, hotel_id) do nothing
  `;
	return role;
}
var pullHotelVaultFn_createServerFn_handler = createServerRpc({
	id: "108224dbb03326c14fd5c672c8fa6a4ccc20ea6e7d7f23e2572a005203b5f723",
	name: "pullHotelVaultFn",
	filename: "src/lib/hotel/api.ts"
}, (opts) => pullHotelVaultFn.__executeServer(opts));
var pullHotelVaultFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(pullHotelVaultFn_createServerFn_handler, async ({ context }) => {
	const { getSql } = await import("./db-Cbgz4UAo.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	const role = await ensureMembership(sql, context.userId);
	const vault = await loadVault(sql);
	const pendings = await loadPendingReservations(sql);
	if (!vault) {
		if (!pendings.reservations.length) return {
			payload: "",
			role
		};
		const stub = {
			version: 1,
			savedAt: 0,
			reservations: pendings.reservations,
			pagamentos: pendings.deposits,
			rooms: [],
			consumos: pendings.consumos,
			guests: [],
			cashCloses: []
		};
		return {
			payload: JSON.stringify(stub),
			role
		};
	}
	const merged = absorbPendings(vault, pendings);
	return {
		payload: JSON.stringify(merged),
		role
	};
});
var pullPublicBookingsFn_createServerFn_handler = createServerRpc({
	id: "3cb3ea539046505fae972085faec85390d2abbd767d0b43059e1c90932b9d364",
	name: "pullPublicBookingsFn",
	filename: "src/lib/hotel/api.ts"
}, (opts) => pullPublicBookingsFn.__executeServer(opts));
var pullPublicBookingsFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(pullPublicBookingsFn_createServerFn_handler, async ({ context }) => {
	const { getSql } = await import("./db-Cbgz4UAo.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	await ensureMembership(sql, context.userId);
	return siteSliceOf(await loadVault(sql), await loadPendingReservations(sql));
});
var pushHotelVaultFn_createServerFn_handler = createServerRpc({
	id: "e807183d1903ae609e0d162302385a3123e32333ce7ac8ae43d0ce91df77264f",
	name: "pushHotelVaultFn",
	filename: "src/lib/hotel/api.ts"
}, (opts) => pushHotelVaultFn.__executeServer(opts));
var pushHotelVaultFn = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator(object({ payload: string().min(2) })).handler(pushHotelVaultFn_createServerFn_handler, async ({ context, data }) => {
	const { getSql } = await import("./db-Cbgz4UAo.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	await ensureMembership(sql, context.userId);
	const vault = parseVault(data.payload);
	if (!vault) throw new Error("Cofre inválido");
	const current = await loadVault(sql);
	const pendings = await loadPendingReservations(sql);
	const merged = protectSiteBookings(vault, current, pendings);
	assertVaultTransition(current, merged);
	await saveVault(sql, merged);
	if (pendings.reservations.length) {
		const kept = new Set(merged.reservations.map((row) => row.id));
		for (const row of pendings.reservations) {
			if (!kept.has(row.id)) continue;
			await sql`delete from hotel_public_pending where id = ${row.id}`;
		}
	}
	return { ok: true };
});
var pullPublicStayFn_createServerFn_handler = createServerRpc({
	id: "8a2e751109d872e14f1505ddf6dfc6d7af574adeb3af3bef671c9eefe9202045",
	name: "pullPublicStayFn",
	filename: "src/lib/hotel/api.ts"
}, (opts) => pullPublicStayFn.__executeServer(opts));
var pullPublicStayFn = createServerFn({ method: "GET" }).handler(pullPublicStayFn_createServerFn_handler, async () => {
	const { getSql } = await import("./db-Cbgz4UAo.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	const vault = await loadVault(sql);
	const pendings = await loadPendingReservations(sql);
	const occupancy = occupancyOf(appendWithoutOverbooking(vault?.reservations ?? [], pendings.reservations, vault?.blocks ?? [], vault?.saleCloses ?? [], (roomId) => (vault?.rooms ?? []).find((room) => room.id === roomId)?.type));
	return {
		hasVault: Boolean(vault),
		rooms: vault?.rooms ?? [],
		occupancy,
		blocks: vault?.blocks ?? [],
		saleCloses: vault?.saleCloses ?? null,
		property: vault?.property ?? null,
		booking: vault?.booking ? {
			...vault.booking,
			checkInTime: vault.property?.checkInTime ?? vault.booking.checkInTime,
			checkOutTime: vault.property?.checkOutTime ?? vault.booking.checkOutTime,
			cancellationPolicy: vault.property?.cancellationPolicy ?? vault.booking.cancellationPolicy
		} : null,
		rates: vault?.rates ?? null,
		offers: vault?.offers ?? null,
		roomTypes: vault?.roomTypes ?? null
	};
});
var publicBookingSchema = object({
	id: string().min(3).max(80),
	roomId: string().min(1).max(80),
	guestName: string().trim().min(2).max(120),
	guestEmail: string().min(3).max(160),
	checkIn: string().regex(ISO_DATE),
	checkOut: string().regex(ISO_DATE),
	guests: number().int().min(1).max(8).optional(),
	nightlyRate: number().nonnegative(),
	totalAmount: number().nonnegative(),
	notes: string().max(500).optional(),
	status: _enum(["pendente", "confirmada"]).optional(),
	deposit: object({
		id: string().min(3).max(80),
		valor: number().positive(),
		metodo: _enum([
			"pix",
			"cartao_credito",
			"cartao_debito",
			"dinheiro"
		]),
		descricao: string().max(200),
		observacao: string().max(300).optional(),
		data_pagamento: string().regex(ISO_DATE).optional()
	}).optional(),
	extras: array(object({
		id: string().min(3).max(80),
		descricao: string().min(2).max(120),
		valor: number().nonnegative(),
		quantidade: number().int().min(1).max(20)
	})).max(8).optional()
});
async function enqueueVoucher(sql, input) {
	const to = assertValidEmail(input.to);
	const mail = {
		...input,
		to
	};
	const subject = voucherMailSubject(mail);
	const html = voucherMailHtml(mail);
	const text = voucherMailText(mail);
	if ((await sql`
    select id from hotel_email_outbox
    where hotel_id = ${"aurora"}
      and reservation_id = ${mail.reservationId}
      and to_email = ${to}
      and created_at > now() - interval '45 seconds'
    limit 1
  `).length) return {
		emailed: true,
		to,
		channel: "caixa",
		delivered: false
	};
	const delivery = await deliverMail({
		to,
		subject,
		html,
		text
	});
	await sql`
    insert into hotel_email_outbox (
      id, hotel_id, reservation_id, to_email, subject, html, text_body, delivered, channel
    ) values (
      ${`mail-${mail.reservationId}-${Date.now()}`}, ${VAULT_ID}, ${mail.reservationId}, ${to}, ${subject}, ${html}, ${text},
      ${delivery.delivered}, ${delivery.channel}
    )
  `;
	return {
		emailed: true,
		to,
		channel: delivery.channel,
		delivered: delivery.delivered
	};
}
function voucherHeading(status) {
	return status === "pendente" ? "Pré-reserva" : "Comprovante de reserva";
}
var submitPublicBookingFn_createServerFn_handler = createServerRpc({
	id: "d18aa834b90fa5eb29bd7a12cde9748b36f4fe1c6956be714aa452ffbc9e9853",
	name: "submitPublicBookingFn",
	filename: "src/lib/hotel/api.ts"
}, (opts) => submitPublicBookingFn.__executeServer(opts));
var submitPublicBookingFn = createServerFn({ method: "POST" }).validator(publicBookingSchema).handler(submitPublicBookingFn_createServerFn_handler, async ({ data }) => {
	assertValidPeriod(data.checkIn, data.checkOut);
	const email = assertValidEmail(data.guestEmail);
	const { getSql } = await import("./db-Cbgz4UAo.mjs").then((n) => n.t).then((n) => n.t);
	const { assertNoOverbooking } = await import("./bookingStore-Bq0ubAXy.mjs").then((n) => n.S).then((n) => n.F);
	const { rooms } = await import("./bookingStore-Bq0ubAXy.mjs").then((n) => n.S).then((n) => n.it);
	const sql = await getSql();
	const vault = await loadVault(sql);
	const pendings = await loadPendingReservations(sql);
	const roomList = vault?.rooms?.length ? vault.rooms : rooms;
	if (!roomList.some((room) => room.id === data.roomId)) throw new Error("Quarto não encontrado");
	const known = mergeReservations(vault?.reservations ?? [], pendings.reservations);
	assertNoOverbooking(known, {
		roomId: data.roomId,
		checkIn: data.checkIn,
		checkOut: data.checkOut
	}, vault?.blocks ?? [], vault?.saleCloses ?? [], roomList);
	const duplicate = known.find((row) => row.id === data.id);
	if (duplicate) {
		if (duplicate.guestEmail === email && duplicate.roomId === data.roomId && duplicate.checkIn === data.checkIn && duplicate.checkOut === data.checkOut) return {
			ok: true,
			id: duplicate.id,
			status: duplicate.status,
			emailed: false,
			emailTo: email
		};
		throw new Error("Esta reserva não pôde ser gravada. Atualize a página e tente de novo.");
	}
	const autoConfirm = data.status === "confirmada" && Boolean(data.deposit);
	const reservation = {
		id: data.id,
		roomId: data.roomId,
		guestName: data.guestName.trim(),
		guestEmail: email,
		guests: data.guests ?? 1,
		checkIn: data.checkIn,
		checkOut: data.checkOut,
		status: autoConfirm ? "confirmada" : "pendente",
		nightlyRate: data.nightlyRate,
		totalAmount: data.totalAmount,
		origin: "Link público",
		createdAt: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
		notes: data.notes
	};
	const deposit = autoConfirm && data.deposit ? {
		id: data.deposit.id,
		reserva_id: reservation.id,
		descricao: data.deposit.descricao,
		valor: data.deposit.valor,
		data_pagamento: data.deposit.data_pagamento ?? (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
		metodo: data.deposit.metodo,
		observacao: data.deposit.observacao
	} : void 0;
	const catalog = normalizeExtras(vault?.booking?.extras);
	const nights = stayNights(reservation.checkIn, reservation.checkOut);
	const guests = reservation.guests;
	const picked = new Set((data.extras ?? []).map((line) => line.id));
	const extraLines = catalog.filter((item) => item.enabled && picked.has(item.id) && item.price >= 0).map((item) => ({
		id: `csm-extra-${item.id}-${reservation.id}`,
		reserva_id: reservation.id,
		descricao: item.name,
		valor: item.price,
		quantidade: extraQuantity(item, nights, guests),
		data_lancamento: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
	}));
	const extrasTotal = extraLines.reduce((sum, item) => sum + item.valor * item.quantidade, 0);
	if (!(await sql`
      select id from hotel_public_pending where id = ${reservation.id} limit 1
    `).length) {
		const payload = {
			...reservation,
			...deposit ? { deposit } : {},
			...extraLines.length ? { consumos: extraLines } : {}
		};
		await sql`
        insert into hotel_public_pending (id, hotel_id, payload)
        values (${reservation.id}, ${VAULT_ID}, ${JSON.stringify(payload)})
      `;
	}
	if (vault) await saveVault(sql, {
		...vault,
		reservations: mergeReservations(vault.reservations, [reservation]),
		pagamentos: mergePagamentos(vault.pagamentos ?? [], deposit ? [deposit] : []),
		consumos: mergeConsumos(vault.consumos ?? [], extraLines),
		savedAt: Date.now()
	});
	let emailed = { emailed: false };
	try {
		const room = roomList.find((item) => item.id === reservation.roomId);
		const property = vault?.property;
		const booking = vault?.booking;
		const paid = deposit?.valor ?? 0;
		emailed = await enqueueVoucher(sql, {
			to: email,
			hotelName: property?.name ?? "Hotel Aurora",
			address: property?.address ?? "",
			phone: property?.phone ?? "",
			checkInTime: property?.checkInTime ?? booking?.checkInTime ?? "14:00",
			checkOutTime: property?.checkOutTime ?? booking?.checkOutTime ?? "12:00",
			cancellationPolicy: property?.cancellationPolicy ?? booking?.cancellationPolicy ?? "Cancelamento conforme política da casa.",
			reservationId: reservation.id,
			heading: voucherHeading(reservation.status),
			guestName: reservation.guestName,
			roomLabel: room ? `Quarto ${room.number} · ${room.type}` : reservation.roomId,
			checkIn: reservation.checkIn,
			checkOut: reservation.checkOut,
			statusLabel: STATUS_LABEL[reservation.status],
			totalDiarias: reservation.totalAmount,
			totalConsumo: extrasTotal,
			totalPagamentos: paid,
			saldo: Math.max(0, reservation.totalAmount + extrasTotal - paid)
		});
	} catch {
		emailed = { emailed: false };
	}
	return {
		ok: true,
		id: reservation.id,
		status: reservation.status,
		emailed: emailed.emailed,
		emailTo: emailed.emailed ? emailed.to : email
	};
});
var sendVoucherSchema = object({
	to: string().min(3).max(160),
	reservationId: string().min(3).max(80),
	heading: string().max(80).optional(),
	guestName: string().min(1).max(120),
	roomLabel: string().min(1).max(120),
	checkIn: string().regex(ISO_DATE),
	checkOut: string().regex(ISO_DATE),
	statusLabel: string().min(1).max(40),
	hotelName: string().min(1).max(120),
	address: string().max(240),
	phone: string().max(40),
	checkInTime: string().max(12),
	checkOutTime: string().max(12),
	cancellationPolicy: string().max(400),
	totalDiarias: number().nonnegative(),
	totalConsumo: number().nonnegative(),
	totalPagamentos: number().nonnegative(),
	saldo: number()
});
var sendVoucherEmailFn_createServerFn_handler = createServerRpc({
	id: "d995be9cfd96a693b4ae9d292fc3033b6b534252172708ca24ba1cbe3de1d7ef",
	name: "sendVoucherEmailFn",
	filename: "src/lib/hotel/api.ts"
}, (opts) => sendVoucherEmailFn.__executeServer(opts));
var sendVoucherEmailFn = createServerFn({ method: "POST" }).validator(sendVoucherSchema).handler(sendVoucherEmailFn_createServerFn_handler, async ({ data }) => {
	const to = assertValidEmail(data.to);
	const { getSql } = await import("./db-Cbgz4UAo.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	const vault = await loadVault(sql);
	const pendings = await loadPendingReservations(sql);
	const stay = mergeReservations(vault?.reservations ?? [], pendings.reservations).find((row) => row.id === data.reservationId);
	if (!stay) throw new Error("Reserva não encontrada para enviar o voucher.");
	if (!await import("./verify.server-B7OrHrtp.mjs").then((mod) => mod.getSessionUser()).catch(() => null) && to !== stay.guestEmail) throw new Error("Só a recepção pode enviar o voucher para outro e-mail.");
	return enqueueVoucher(sql, {
		...data,
		to,
		reservationId: data.reservationId,
		heading: data.heading ?? voucherHeading(stay.status)
	});
});
var listVoucherEmailsFn_createServerFn_handler = createServerRpc({
	id: "50364d2359e124ab8ab04748eb0f6ffb6a696ecebabc72647e5ff90393da8839",
	name: "listVoucherEmailsFn",
	filename: "src/lib/hotel/api.ts"
}, (opts) => listVoucherEmailsFn.__executeServer(opts));
var listVoucherEmailsFn = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listVoucherEmailsFn_createServerFn_handler, async ({ context }) => {
	const { getSql } = await import("./db-Cbgz4UAo.mjs").then((n) => n.t).then((n) => n.t);
	const sql = await getSql();
	await ensureMembership(sql, context.userId);
	return await sql`
      select id, reservation_id, to_email, subject, html, delivered, channel,
             created_at::text as created_at
      from hotel_email_outbox
      where hotel_id = ${VAULT_ID}
      order by created_at desc
      limit 40
    `;
});
//#endregion
export { listVoucherEmailsFn_createServerFn_handler, pullHotelVaultFn_createServerFn_handler, pullPublicBookingsFn_createServerFn_handler, pullPublicStayFn_createServerFn_handler, pushHotelVaultFn_createServerFn_handler, sendVoucherEmailFn_createServerFn_handler, submitPublicBookingFn_createServerFn_handler };
