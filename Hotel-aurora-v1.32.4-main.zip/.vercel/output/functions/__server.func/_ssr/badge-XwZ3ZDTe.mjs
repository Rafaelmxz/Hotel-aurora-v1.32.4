import "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { Pt as cn } from "./router-D2QglEY4.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-[0.6875rem] font-medium tracking-wide uppercase", {
	variants: { variant: {
		default: "bg-secondary text-secondary-foreground",
		pending: "bg-status-pending text-status-pending-fg",
		confirmed: "bg-status-confirmed text-status-confirmed-fg",
		checkin: "bg-status-checkin text-status-checkin-fg",
		checkout: "bg-status-checkout text-status-checkout-fg",
		cancelled: "bg-status-cancelled text-status-cancelled-fg"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"data-slot": "badge",
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
//#endregion
export { Badge as t };
