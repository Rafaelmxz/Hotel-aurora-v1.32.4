import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { a as startOfYear, c as endOfMonth, d as max, i as format, l as isSameDay, m as startOfDay, o as startOfMonth, p as differenceInCalendarDays, r as isBefore, t as ptBR, u as min, v as addMonths, y as addDays } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bookingStore-Bq0ubAXy.js
var bookingStore_Bq0ubAXy_exports = /* @__PURE__ */ __exportAll({
	$: () => TODAY_ISO,
	A: () => assertNoOverbooking,
	B: () => removeSaleClose,
	C: () => splitPublicPending,
	D: () => normalizeEmail,
	E: () => assertValidEmail,
	F: () => overbooking_exports,
	G: () => assertValidPeriod,
	H: () => saleCloseKeys,
	I: () => roomHoldReason,
	J: () => HOUSEKEEPING_LABEL,
	K: () => assertVaultTransition,
	L: () => saleCloseOnNight,
	M: () => findBlockConflicts,
	N: () => findConflicts,
	O: () => HOLD_REASON_LABEL,
	P: () => findOverbookedIds,
	Q: () => TODAY,
	R: () => createSaleClose,
	S: () => parseVault,
	T: () => VAULT_ID,
	U: () => appendWithoutOverbooking,
	V: () => replaceSaleCloses,
	W: () => assertStayTransition,
	X: () => blocksCheckIn,
	Y: () => HOUSEKEEPING_ORDER,
	Z: () => CURRENT_YEAR,
	_: () => isSiteBooking,
	a: () => normalizeExtras,
	at: () => isStayActiveOn,
	b: () => mergeReservations,
	c: () => saveBookingConfig,
	ct: () => reservations,
	d: () => isCancelFree,
	dt: () => stayNights,
	et: () => formatCurrency,
	f: () => propertyKeys,
	ft: () => toISODate,
	g: () => absorbSiteBookings,
	h: () => stayHoursLabel,
	i: () => getBookingConfig,
	it: () => hotelData_exports,
	j: () => availableRoomsByType,
	k: () => OverbookingError,
	l: () => alignCancellationPolicy,
	lt: () => roomById,
	m: () => saveProperty,
	n: () => bookingKeys,
	nt: () => getDashboardStats,
	o: () => quoteExtras,
	ot: () => monthlyMetrics,
	p: () => replaceProperty,
	q: () => HOUSEKEEPING_DOT,
	r: () => extraQuantity,
	rt: () => getReservationsOverlapping,
	s: () => replaceBookingConfig,
	st: () => parseISODate,
	t: () => EXTRA_UNIT_LABEL,
	tt: () => formatStayRange,
	u: () => getProperty,
	ut: () => rooms,
	v: () => mergeConsumos,
	w: () => unionVaultReservations,
	x: () => occupancyOf,
	y: () => mergePagamentos,
	z: () => listSaleCloses
});
var hotelData_exports = /* @__PURE__ */ __exportAll$1({
	CURRENT_YEAR: () => CURRENT_YEAR,
	HOTEL_NAME: () => HOTEL_NAME,
	MONTH_LABELS: () => MONTH_LABELS,
	TODAY: () => TODAY,
	TODAY_ISO: () => TODAY_ISO,
	formatCurrency: () => formatCurrency,
	formatStayRange: () => formatStayRange,
	getDashboardStats: () => getDashboardStats,
	getMonthlyMetrics: () => getMonthlyMetrics,
	getReservationsOverlapping: () => getReservationsOverlapping,
	isStayActiveOn: () => isStayActiveOn,
	monthlyMetrics: () => monthlyMetrics,
	parseISODate: () => parseISODate,
	reservations: () => reservations,
	roomById: () => roomById,
	rooms: () => rooms,
	stayNights: () => stayNights,
	toISODate: () => toISODate
});
var MONTH_LABELS = [
	"Jan",
	"Fev",
	"Mar",
	"Abr",
	"Mai",
	"Jun",
	"Jul",
	"Ago",
	"Set",
	"Out",
	"Nov",
	"Dez"
];
var rooms = [
	{
		id: "room-101",
		number: "101",
		type: "Standard",
		floor: 1,
		capacity: 2,
		nightlyRate: 320
	},
	{
		id: "room-102",
		number: "102",
		type: "Standard",
		floor: 1,
		capacity: 2,
		nightlyRate: 320
	},
	{
		id: "room-103",
		number: "103",
		type: "Standard",
		floor: 1,
		capacity: 3,
		nightlyRate: 360
	},
	{
		id: "room-201",
		number: "201",
		type: "Luxo",
		floor: 2,
		capacity: 2,
		nightlyRate: 540
	},
	{
		id: "room-202",
		number: "202",
		type: "Luxo",
		floor: 2,
		capacity: 2,
		nightlyRate: 560
	},
	{
		id: "room-203",
		number: "203",
		type: "Luxo",
		floor: 2,
		capacity: 3,
		nightlyRate: 610
	},
	{
		id: "room-301",
		number: "301",
		type: "Suíte",
		floor: 3,
		capacity: 4,
		nightlyRate: 890
	},
	{
		id: "room-302",
		number: "302",
		type: "Suíte",
		floor: 3,
		capacity: 4,
		nightlyRate: 940
	},
	{
		id: "room-401",
		number: "401",
		type: "Standard",
		floor: 4,
		capacity: 2,
		nightlyRate: 340
	},
	{
		id: "room-402",
		number: "402",
		type: "Luxo",
		floor: 4,
		capacity: 3,
		nightlyRate: 580
	}
];
var GUESTS = [
	"Ana Ribeiro",
	"Bruno Costa",
	"Camila Ferreira",
	"Diego Almeida",
	"Elena Souza",
	"Felipe Martins",
	"Gabriela Lima",
	"Henrique Dias",
	"Isabel Rocha",
	"João Mendes",
	"Karina Nunes",
	"Lucas Barbosa",
	"Marina Teixeira",
	"Nicolas Prado",
	"Olivia Castro",
	"Paulo Vieira",
	"Quésia Moura",
	"Rafael Pinto",
	"Sofia Azevedo",
	"Thiago Ramos",
	"Vera Campos",
	"Vinícius Lopes",
	"Wanda Freitas",
	"Yara Cardoso",
	"Zeca Antunes",
	"Beatriz Moraes",
	"Caio Pacheco",
	"Daniela Brito",
	"Eduardo Sampaio",
	"Fernanda Duarte",
	"Gustavo Nogueira",
	"Helena Paiva",
	"Igor Vasconcelos",
	"Júlia Tavares",
	"Leandro Farias",
	"Marta Quintana"
];
var ORIGINS = [
	"Direto",
	"Booking.com",
	"Airbnb",
	"Expedia",
	"Website"
];
var NOTES = [
	"Chegada prevista após 21h.",
	"Berço extra solicitado.",
	"Aniversário na segunda noite.",
	"Preferência por andar alto.",
	"Transfer do aeroporto confirmado.",
	"Hóspede frequente — cortesia no minibar."
];
/** Smaller gaps → higher occupancy. Values keep monthly occupancy in 40–85%. */
var GAP_BY_MONTH = [
	1,
	1,
	2,
	2,
	3,
	4,
	1,
	2,
	2,
	2,
	3,
	1
];
var TODAY = startOfDay(/* @__PURE__ */ new Date());
var TODAY_ISO = format(TODAY, "yyyy-MM-dd");
var CURRENT_YEAR = TODAY.getFullYear();
function parseISODate(iso) {
	const [year, month, day] = iso.split("-").map(Number);
	return new Date(year, month - 1, day);
}
function toISODate(date) {
	return format(date, "yyyy-MM-dd");
}
function stayNights(checkIn, checkOut) {
	return Math.max(1, differenceInCalendarDays(parseISODate(checkOut), parseISODate(checkIn)));
}
function formatCurrency(value) {
	return new Intl.NumberFormat("pt-BR", {
		style: "currency",
		currency: "BRL",
		maximumFractionDigits: 0
	}).format(Math.round(value));
}
function formatStayRange(checkIn, checkOut) {
	const start = parseISODate(checkIn);
	const end = parseISODate(checkOut);
	if (start.getMonth() === end.getMonth()) return `${format(start, "d", { locale: ptBR })}–${format(end, "d 'de' MMMM", { locale: ptBR })}`;
	return `${format(start, "d MMM", { locale: ptBR })} – ${format(end, "d MMM", { locale: ptBR })}`;
}
function roomById(id) {
	return rooms.find((room) => room.id === id);
}
function mulberry32(seed) {
	return function rng() {
		let t = seed += 1831565813;
		t = Math.imul(t ^ t >>> 15, t | 1);
		t ^= t + Math.imul(t ^ t >>> 7, t | 61);
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function emailFromName(name) {
	return name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z\s]/g, "").trim().replace(/\s+/g, ".") + "@email.com";
}
function pick(rng, list) {
	return list[Math.floor(rng() * list.length)];
}
function overlapNights(aStart, aEnd, bStart, bEnd) {
	const start = max([aStart, bStart]);
	const end = min([aEnd, bEnd]);
	const nights = differenceInCalendarDays(end, start);
	return nights > 0 ? nights : 0;
}
function rangesOverlap(aStart, aEnd, bStart, bEnd) {
	return overlapNights(aStart, aEnd, bStart, bEnd) > 0;
}
/**
* Stays pinned to "today" so the dashboard and the 21-day map always look
* occupied — arrivals, departures, in-house guests and empty rooms.
*/
var WINDOW_SEEDS = [
	{
		roomNumber: "101",
		startOffset: -2,
		nights: 5,
		guestName: "Ana Ribeiro",
		origin: "Direto",
		notes: "Hóspede frequente — cortesia no minibar."
	},
	{
		roomNumber: "101",
		startOffset: 5,
		nights: 4,
		guestName: "Lucas Barbosa",
		origin: "Booking.com"
	},
	{
		roomNumber: "101",
		startOffset: 10,
		nights: 3,
		status: "pendente",
		guestName: "Sofia Azevedo",
		origin: "Website"
	},
	{
		roomNumber: "102",
		startOffset: -4,
		nights: 9,
		guestName: "Bruno Costa",
		origin: "Expedia",
		notes: "Preferência por andar alto."
	},
	{
		roomNumber: "102",
		startOffset: 7,
		nights: 6,
		guestName: "Helena Paiva",
		origin: "Booking.com"
	},
	{
		roomNumber: "103",
		startOffset: 0,
		nights: 4,
		guestName: "Camila Ferreira",
		origin: "Direto",
		notes: "Chegada prevista após 21h."
	},
	{
		roomNumber: "103",
		startOffset: 6,
		nights: 3,
		status: "pendente",
		guestName: "Igor Vasconcelos",
		origin: "Airbnb"
	},
	{
		roomNumber: "103",
		startOffset: 12,
		nights: 4,
		guestName: "Marta Quintana",
		origin: "Website"
	},
	{
		roomNumber: "201",
		startOffset: -1,
		nights: 4,
		guestName: "Diego Almeida",
		origin: "Booking.com"
	},
	{
		roomNumber: "201",
		startOffset: 5,
		nights: 5,
		guestName: "Júlia Tavares",
		origin: "Direto",
		notes: "Aniversário na segunda noite."
	},
	{
		roomNumber: "201",
		startOffset: 12,
		nights: 3,
		status: "pendente",
		guestName: "Caio Pacheco",
		origin: "Expedia"
	},
	{
		roomNumber: "202",
		startOffset: 0,
		nights: 7,
		guestName: "Elena Souza",
		origin: "Airbnb",
		notes: "Berço extra solicitado."
	},
	{
		roomNumber: "202",
		startOffset: 9,
		nights: 4,
		guestName: "Leandro Farias",
		origin: "Booking.com"
	},
	{
		roomNumber: "203",
		startOffset: -3,
		nights: 3,
		guestName: "Felipe Martins",
		origin: "Direto"
	},
	{
		roomNumber: "203",
		startOffset: 2,
		nights: 4,
		guestName: "Daniela Brito",
		origin: "Website"
	},
	{
		roomNumber: "203",
		startOffset: 8,
		nights: 5,
		status: "pendente",
		guestName: "Gustavo Nogueira",
		origin: "Booking.com"
	},
	{
		roomNumber: "301",
		startOffset: 0,
		nights: 3,
		guestName: "Gabriela Lima",
		origin: "Direto",
		notes: "Transfer do aeroporto confirmado."
	},
	{
		roomNumber: "301",
		startOffset: 5,
		nights: 4,
		guestName: "Eduardo Sampaio",
		origin: "Expedia"
	},
	{
		roomNumber: "301",
		startOffset: 11,
		nights: 4,
		guestName: "Fernanda Duarte",
		origin: "Website"
	},
	{
		roomNumber: "302",
		startOffset: -2,
		nights: 8,
		guestName: "Henrique Dias",
		origin: "Booking.com"
	},
	{
		roomNumber: "302",
		startOffset: 8,
		nights: 3,
		status: "cancelada",
		guestName: "Yara Cardoso",
		origin: "Airbnb"
	},
	{
		roomNumber: "302",
		startOffset: 12,
		nights: 5,
		guestName: "Beatriz Moraes",
		origin: "Direto"
	},
	{
		roomNumber: "401",
		startOffset: -6,
		nights: 6,
		guestName: "Isabel Rocha",
		origin: "Website"
	},
	{
		roomNumber: "401",
		startOffset: 3,
		nights: 4,
		status: "pendente",
		guestName: "Paulo Vieira",
		origin: "Booking.com"
	},
	{
		roomNumber: "401",
		startOffset: 9,
		nights: 4,
		guestName: "Thiago Ramos",
		origin: "Expedia"
	},
	{
		roomNumber: "402",
		startOffset: -10,
		nights: 4,
		status: "cancelada",
		guestName: "Zeca Antunes",
		origin: "Airbnb"
	},
	{
		roomNumber: "402",
		startOffset: 4,
		nights: 3,
		status: "pendente",
		guestName: "Olivia Castro",
		origin: "Direto"
	},
	{
		roomNumber: "402",
		startOffset: 8,
		nights: 6,
		guestName: "Rafael Pinto",
		origin: "Booking.com"
	}
];
function inferStatus(checkIn, checkOut, today, override) {
	if (override) return override;
	if (!isBefore(today, checkIn) && isBefore(today, checkOut)) return "check-in";
	if (isBefore(today, checkIn)) return "confirmada";
	return "confirmada";
}
function makeReservation(id, room, checkIn, checkOut, today, guestName, rng, override, origin, notes) {
	const nights = Math.max(1, differenceInCalendarDays(checkOut, checkIn));
	const jitter = 1 + (rng() - .5) * .08;
	const nightlyRate = Math.round(room.nightlyRate * jitter);
	const guests = 1 + Math.floor(rng() * room.capacity);
	return {
		id,
		roomId: room.id,
		guestName,
		guestEmail: emailFromName(guestName),
		guests,
		checkIn: toISODate(checkIn),
		checkOut: toISODate(checkOut),
		status: inferStatus(checkIn, checkOut, today, override),
		nightlyRate,
		totalAmount: nightlyRate * nights,
		origin: origin ?? pick(rng, ORIGINS),
		createdAt: toISODate(addDays(checkIn, -Math.max(1, Math.floor(rng() * 10)))),
		notes
	};
}
function buildReservations(today) {
	const rng = mulberry32(today.getFullYear() * 1e4 + (today.getMonth() + 1) * 100 + today.getDate());
	const yearStart = startOfYear(today);
	const yearEnd = addDays(addMonths(yearStart, 12), 0);
	const reservations = [];
	const occupied = /* @__PURE__ */ new Map();
	let seq = 1;
	const mark = (roomId, start, end) => {
		const list = occupied.get(roomId) ?? [];
		list.push({
			start,
			end
		});
		occupied.set(roomId, list);
	};
	const isFree = (roomId, start, end) => {
		return (occupied.get(roomId) ?? []).every((range) => !rangesOverlap(start, end, range.start, range.end));
	};
	for (const seed of WINDOW_SEEDS) {
		const room = rooms.find((item) => item.number === seed.roomNumber);
		if (!room) continue;
		const checkIn = addDays(today, seed.startOffset);
		const checkOut = addDays(checkIn, seed.nights);
		reservations.push(makeReservation(`res-${String(seq++).padStart(3, "0")}`, room, checkIn, checkOut, today, seed.guestName, rng, seed.status, seed.origin, seed.notes));
		mark(room.id, checkIn, checkOut);
	}
	let guestCursor = 0;
	for (const room of rooms) {
		let cursor = new Date(yearStart);
		while (isBefore(cursor, yearEnd)) {
			const gap = GAP_BY_MONTH[cursor.getMonth()] + (rng() < .35 ? 1 : 0);
			const proposedStart = addDays(cursor, gap);
			if (!isBefore(proposedStart, yearEnd)) break;
			const stay = 2 + Math.floor(rng() * 5);
			const proposedEnd = addDays(proposedStart, stay);
			const checkOut = isBefore(proposedEnd, yearEnd) ? proposedEnd : yearEnd;
			if (differenceInCalendarDays(checkOut, proposedStart) < 1) {
				cursor = addDays(proposedStart, 1);
				continue;
			}
			if (!isFree(room.id, proposedStart, checkOut)) {
				cursor = addDays(proposedStart, 1);
				continue;
			}
			const demoStart = addDays(today, -14);
			const demoEnd = addDays(today, 21);
			if (rangesOverlap(proposedStart, checkOut, demoStart, demoEnd)) {
				if (isBefore(proposedStart, demoStart) && differenceInCalendarDays(demoStart, proposedStart) >= 1 && isFree(room.id, proposedStart, demoStart)) {
					const guestName = GUESTS[guestCursor % GUESTS.length];
					guestCursor += 1;
					reservations.push(makeReservation(`res-${String(seq++).padStart(3, "0")}`, room, proposedStart, demoStart, today, guestName, rng, isBefore(demoStart, today) ? void 0 : "confirmada", pick(rng, ORIGINS)));
					mark(room.id, proposedStart, demoStart);
				}
				cursor = demoEnd;
				continue;
			}
			const guestName = GUESTS[guestCursor % GUESTS.length];
			guestCursor += 1;
			let status;
			if (rng() < .07 && isBefore(checkOut, today)) status = "cancelada";
			else if (isBefore(today, proposedStart) && rng() < .22) status = "pendente";
			reservations.push(makeReservation(`res-${String(seq++).padStart(3, "0")}`, room, proposedStart, checkOut, today, guestName, rng, status, pick(rng, ORIGINS), rng() < .18 ? pick(rng, NOTES) : void 0));
			mark(room.id, proposedStart, checkOut);
			cursor = checkOut;
		}
	}
	return reservations.sort((a, b) => a.checkIn.localeCompare(b.checkIn) || a.roomId.localeCompare(b.roomId));
}
var reservations = buildReservations(TODAY);
function isStayActiveOn(reservation, day) {
	if (reservation.status === "cancelada" || reservation.status === "check-out") return false;
	const start = parseISODate(reservation.checkIn);
	const end = parseISODate(reservation.checkOut);
	return !isBefore(day, start) && isBefore(day, end);
}
function getDashboardStats(day = TODAY, all = reservations) {
	const occupiedRoomIds = /* @__PURE__ */ new Set();
	let checkInsToday = 0;
	let checkOutsToday = 0;
	for (const reservation of all) {
		if (reservation.status === "cancelada") continue;
		const checkIn = parseISODate(reservation.checkIn);
		const checkOut = parseISODate(reservation.checkOut);
		if (isSameDay(checkIn, day)) checkInsToday += 1;
		if (isSameDay(checkOut, day)) checkOutsToday += 1;
		if (isStayActiveOn(reservation, day)) occupiedRoomIds.add(reservation.roomId);
	}
	const monthStart = startOfMonth(day);
	const monthEnd = addDays(endOfMonth(day), 1);
	const tomorrow = addDays(day, 1);
	let forecastRevenue = 0;
	let receivedRevenue = 0;
	for (const reservation of all) {
		if (reservation.status === "cancelada") continue;
		const checkIn = parseISODate(reservation.checkIn);
		const checkOut = parseISODate(reservation.checkOut);
		const nights = stayNights(reservation.checkIn, reservation.checkOut);
		const rate = nights > 0 ? reservation.totalAmount / nights : 0;
		forecastRevenue += rate * overlapNights(checkIn, checkOut, monthStart, monthEnd);
		receivedRevenue += rate * overlapNights(checkIn, checkOut, monthStart, tomorrow);
	}
	const occupied = occupiedRoomIds.size;
	const totalRooms = rooms.length;
	return {
		occupied,
		vacant: totalRooms - occupied,
		checkInsToday,
		checkOutsToday,
		forecastRevenue: Math.round(forecastRevenue),
		receivedRevenue: Math.round(receivedRevenue),
		occupancyToday: Math.round(occupied / totalRooms * 100),
		totalRooms
	};
}
function getMonthlyMetrics(year = CURRENT_YEAR, all = reservations) {
	return MONTH_LABELS.map((month, monthIndex) => {
		const start = new Date(year, monthIndex, 1);
		const end = addMonths(start, 1);
		const daysInMonth = differenceInCalendarDays(end, start);
		const capacity = rooms.length * daysInMonth;
		let occupiedNights = 0;
		let revenue = 0;
		for (const reservation of all) {
			if (reservation.status === "cancelada") continue;
			const overlap = overlapNights(parseISODate(reservation.checkIn), parseISODate(reservation.checkOut), start, end);
			if (overlap <= 0) continue;
			occupiedNights += overlap;
			const nights = stayNights(reservation.checkIn, reservation.checkOut);
			revenue += nights > 0 ? reservation.totalAmount * overlap / nights : 0;
		}
		return {
			month,
			monthIndex,
			revenue: Math.round(revenue),
			occupancy: capacity > 0 ? Math.round(occupiedNights / capacity * 1e3) / 10 : 0
		};
	});
}
function getReservationsOverlapping(start, end, all = reservations) {
	return all.filter((reservation) => {
		return rangesOverlap(parseISODate(reservation.checkIn), parseISODate(reservation.checkOut), start, end);
	});
}
getDashboardStats(TODAY);
var monthlyMetrics = getMonthlyMetrics(CURRENT_YEAR);
var HOUSEKEEPING_LABEL = {
	sujo: "Sujo",
	em_limpeza: "Em limpeza",
	limpo: "Limpo",
	manutencao: "Manutenção"
};
var HOUSEKEEPING_DOT = {
	sujo: "bg-status-pending",
	em_limpeza: "bg-status-confirmed",
	limpo: "bg-status-checkout",
	manutencao: "bg-status-cancelled"
};
var HOUSEKEEPING_ORDER = [
	"sujo",
	"em_limpeza",
	"limpo",
	"manutencao"
];
var HOUSEKEEPING_BLOCKS_CHECKIN = [
	"sujo",
	"em_limpeza",
	"manutencao"
];
function blocksCheckIn(status) {
	return HOUSEKEEPING_BLOCKS_CHECKIN.includes(status);
}
var HotelRuleError = class extends Error {
	code;
	constructor(message, code) {
		super(message);
		this.code = code;
		this.name = "HotelRuleError";
	}
};
function staySaldo(reservation, consumos, pagamentos) {
	const consumo = consumos.filter((row) => row.reserva_id === reservation.id).reduce((sum, row) => sum + row.valor * row.quantidade, 0);
	const pagos = pagamentos.filter((row) => row.reserva_id === reservation.id).reduce((sum, row) => sum + row.valor, 0);
	return reservation.totalAmount + consumo - pagos;
}
function assertValidPeriod(checkIn, checkOut) {
	if (!checkIn || !checkOut || checkOut <= checkIn) throw new HotelRuleError("Informe um período válido de check-in e check-out.", "PERIOD");
}
function assertNoOverbookingSnapshot(reservations, previous, blocks = [], previousBlocks = []) {
	const ids = findOverbookedIds(reservations);
	if (ids.size > 0) {
		if (previous) {
			const prevIds = findOverbookedIds(previous);
			if ([...ids].some((id) => !prevIds.has(id))) throw new HotelRuleError("Não é possível ocupar o mesmo quarto nas mesmas noites.", "OVERBOOKING");
		} else throw new HotelRuleError("Não é possível ocupar o mesmo quarto nas mesmas noites.", "OVERBOOKING");
	}
	for (const block of blocks) {
		if (findConflicts(reservations, block.roomId, block.checkIn, block.checkOut).length === 0) continue;
		if (!previousBlocks.some((row) => row.id === block.id)) throw new HotelRuleError("Não é possível bloquear um quarto já ocupado nas mesmas noites.", "OVERBOOKING");
	}
}
/** Pendências do site que não batem com o que a recepção já gravou são descartadas. */
function appendWithoutOverbooking(base, extras, blocks = [], saleCloses = [], roomTypeOf) {
	const out = [...base];
	const ids = new Set(base.map((row) => row.id));
	for (const extra of extras) {
		if (ids.has(extra.id)) continue;
		if (isActiveStay(extra)) {
			if (findConflicts(out, extra.roomId, extra.checkIn, extra.checkOut, extra.id).length > 0) continue;
			if (findBlockConflicts(blocks, extra.roomId, extra.checkIn, extra.checkOut).length > 0) continue;
			const type = roomTypeOf?.(extra.roomId);
			if (type && findSaleCloseHits(saleCloses, type, extra.checkIn, extra.checkOut).length > 0) continue;
		}
		out.push(extra);
		ids.add(extra.id);
	}
	return out;
}
function assertStayTransition(input) {
	assertValidPeriod(input.next.checkIn, input.next.checkOut);
	if (isActiveStay(input.next)) assertNoOverbooking(input.reservations, {
		roomId: input.next.roomId,
		checkIn: input.next.checkIn,
		checkOut: input.next.checkOut,
		id: input.next.id
	}, input.blocks ?? [], input.saleCloses ?? []);
	const becameCheckIn = input.next.status === "check-in" && input.previous.status !== "check-in";
	const becameCheckOut = input.next.status === "check-out" && input.previous.status !== "check-out";
	if (becameCheckIn) {
		const room = input.rooms.find((row) => row.id === input.next.roomId);
		if (room && blocksCheckIn(room.housekeepingStatus)) throw new HotelRuleError(`Quarto ${room.number} está ${HOUSEKEEPING_LABEL[room.housekeepingStatus]}. Libere na governança antes do check-in.`, "CHECKIN_HOUSEKEEPING");
	}
	if (becameCheckOut) {
		const saldo = Math.round(input.saldo);
		if (saldo > 0) throw new HotelRuleError(`Saldo pendente de ${formatCurrency(saldo)}. Quite a conta para concluir.`, "CHECKOUT_BALANCE");
	}
}
function assertVaultTransition(previous, next) {
	for (const row of next.reservations) assertValidPeriod(row.checkIn, row.checkOut);
	for (const row of next.blocks ?? []) assertValidPeriod(row.checkIn, row.checkOut);
	if (!previous) return;
	assertNoOverbookingSnapshot(next.reservations, previous.reservations, next.blocks ?? [], previous.blocks ?? []);
	const prevById = new Map(previous.reservations.map((row) => [row.id, row]));
	const roomsById = new Map(next.rooms.map((row) => [row.id, row]));
	for (const row of next.reservations) {
		const before = prevById.get(row.id);
		if (!before) continue;
		const becameCheckIn = row.status === "check-in" && before.status !== "check-in";
		const becameCheckOut = row.status === "check-out" && before.status !== "check-out";
		if (becameCheckIn) {
			const room = roomsById.get(row.roomId);
			if (room && blocksCheckIn(room.housekeepingStatus)) throw new HotelRuleError(`Quarto ${room.number} está ${HOUSEKEEPING_LABEL[room.housekeepingStatus]}. Libere na governança antes do check-in.`, "CHECKIN_HOUSEKEEPING");
		}
		if (becameCheckOut) {
			const saldo = Math.round(staySaldo(row, next.consumos ?? [], next.pagamentos ?? []));
			if (saldo > 0) throw new HotelRuleError(`Saldo pendente de ${formatCurrency(saldo)}. Quite a conta para concluir.`, "CHECKOUT_BALANCE");
			const room = roomsById.get(row.roomId);
			if (room && room.housekeepingStatus !== "sujo" && room.housekeepingStatus !== "manutencao") throw new HotelRuleError(`Check-out deve deixar o quarto ${room.number} sujo.`, "CHECKOUT_DIRTY");
		}
	}
}
var saleCloseKeys = { all: ["sale-closes"] };
var store = [];
function listSaleCloses() {
	return store.map((row) => ({ ...row }));
}
function replaceSaleCloses(rows) {
	store = Array.isArray(rows) ? rows.map((row) => ({ ...row })) : [];
}
function newCloseId() {
	try {
		return `cls-${crypto.randomUUID()}`;
	} catch {
		return `cls-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
	}
}
function createSaleClose(input) {
	const reason = input.reason.trim();
	if (reason.length < 2 || reason.length > 80) throw new Error("Informe um motivo curto (2 a 80 caracteres).");
	if (input.roomType !== "todas" && ![
		"Standard",
		"Luxo",
		"Suíte"
	].includes(input.roomType)) throw new Error("Informe o tipo de quarto.");
	assertValidPeriod(input.checkIn, input.checkOut);
	const row = {
		id: newCloseId(),
		roomType: input.roomType,
		checkIn: input.checkIn,
		checkOut: input.checkOut,
		reason,
		createdAt: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
	};
	store = [...store, row];
	return { ...row };
}
function removeSaleClose(id) {
	const next = store.filter((row) => row.id !== id);
	if (next.length === store.length) throw new Error("Fechamento não encontrado");
	store = next;
}
function closeCoversType(row, roomType) {
	return row.roomType === "todas" || row.roomType === roomType;
}
/**
* Conflito de vaga: reserva ativa, bloqueio OU venda fechada no tipo/noites.
* Tela não decide overbooking; esta função recusa.
* Proibido: inventar reserva HOUSE / hóspede falso.
* Bloqueio e fechamento fecham mapa e site; não entram em folio nem pré-reserva.
*/
var overbooking_exports = /* @__PURE__ */ __exportAll$1({
	HOLD_REASON_LABEL: () => HOLD_REASON_LABEL,
	OverbookingError: () => OverbookingError,
	assertNoOverbooking: () => assertNoOverbooking,
	availableRoomsByType: () => availableRoomsByType,
	findAlternativeRooms: () => findAlternativeRooms,
	findBlockConflicts: () => findBlockConflicts,
	findConflicts: () => findConflicts,
	findOverbookedIds: () => findOverbookedIds,
	findSaleCloseHits: () => findSaleCloseHits,
	intervalsOverlap: () => intervalsOverlap,
	isActiveStay: () => isActiveStay,
	roomHoldReason: () => roomHoldReason,
	saleCloseOnNight: () => saleCloseOnNight
});
var ACTIVE = [
	"pendente",
	"confirmada",
	"check-in"
];
var OverbookingError = class extends Error {
	conflicts;
	alternatives;
	constructor(message, conflicts, alternatives) {
		super(message);
		this.conflicts = conflicts;
		this.alternatives = alternatives;
		this.name = "OverbookingError";
	}
};
function isActiveStay(reservation) {
	return ACTIVE.includes(reservation.status);
}
/** Check-in_Novo < Check-out_Existente AND Check-out_Novo > Check-in_Existente */
function intervalsOverlap(newIn, newOut, existingIn, existingOut) {
	return newIn < existingOut && newOut > existingIn;
}
function findConflicts(reservations, roomId, checkIn, checkOut, excludeId) {
	return reservations.filter((row) => row.roomId === roomId && row.id !== excludeId && isActiveStay(row) && intervalsOverlap(checkIn, checkOut, row.checkIn, row.checkOut));
}
function findBlockConflicts(blocks, roomId, checkIn, checkOut, excludeId) {
	return blocks.filter((row) => row.roomId === roomId && row.id !== excludeId && intervalsOverlap(checkIn, checkOut, row.checkIn, row.checkOut));
}
function findSaleCloseHits(closes, roomType, checkIn, checkOut) {
	return closes.filter((row) => closeCoversType(row, roomType) && intervalsOverlap(checkIn, checkOut, row.checkIn, row.checkOut));
}
function roomHoldReason(room, reservations, checkIn, checkOut, blocks = [], saleCloses = []) {
	if (findConflicts(reservations, room.id, checkIn, checkOut).length > 0) return "reserva";
	if (findBlockConflicts(blocks, room.id, checkIn, checkOut).length > 0) return "bloqueado";
	if (findSaleCloseHits(saleCloses, room.type, checkIn, checkOut).length > 0) return "fechado";
	return "livre";
}
var HOLD_REASON_LABEL = {
	livre: "livre",
	reserva: "reserva",
	bloqueado: "bloqueado",
	fechado: "venda fechada"
};
function saleCloseOnNight(closes, roomType, night) {
	return closes.find((row) => closeCoversType(row, roomType) && night >= row.checkIn && night < row.checkOut);
}
function availableRoomsByType(reservations, checkIn, checkOut, roomList = rooms, blocks = [], saleCloses = []) {
	const grouped = {};
	for (const room of roomList) {
		if (findConflicts(reservations, room.id, checkIn, checkOut).length > 0) continue;
		if (findBlockConflicts(blocks, room.id, checkIn, checkOut).length > 0) continue;
		if (findSaleCloseHits(saleCloses, room.type, checkIn, checkOut).length > 0) continue;
		const list = grouped[room.type] ?? [];
		list.push(room);
		grouped[room.type] = list;
	}
	return grouped;
}
function findAlternativeRooms(reservations, roomId, checkIn, checkOut, roomList = rooms, blocks = [], saleCloses = []) {
	const current = roomList.find((room) => room.id === roomId) ?? roomById(roomId);
	if (!current) return [];
	return roomList.filter((room) => {
		if (room.id === roomId) return false;
		if (room.type !== current.type) return false;
		if (findConflicts(reservations, room.id, checkIn, checkOut).length > 0) return false;
		if (findBlockConflicts(blocks, room.id, checkIn, checkOut).length > 0) return false;
		return findSaleCloseHits(saleCloses, room.type, checkIn, checkOut).length === 0;
	});
}
function findOverbookedIds(reservations) {
	const ids = /* @__PURE__ */ new Set();
	const active = reservations.filter(isActiveStay);
	for (let i = 0; i < active.length; i += 1) for (let j = i + 1; j < active.length; j += 1) {
		const a = active[i];
		const b = active[j];
		if (a.roomId !== b.roomId) continue;
		if (!intervalsOverlap(a.checkIn, a.checkOut, b.checkIn, b.checkOut)) continue;
		ids.add(a.id);
		ids.add(b.id);
	}
	return ids;
}
function assertNoOverbooking(reservations, input, blocks = [], saleCloses = [], roomList = rooms) {
	const conflicts = findConflicts(reservations, input.roomId, input.checkIn, input.checkOut, input.id);
	const blockHits = findBlockConflicts(blocks, input.roomId, input.checkIn, input.checkOut, input.id);
	const room = roomList.find((row) => row.id === input.roomId) ?? roomById(input.roomId);
	const closeHits = room ? findSaleCloseHits(saleCloses, room.type, input.checkIn, input.checkOut) : [];
	if (conflicts.length === 0 && blockHits.length === 0 && closeHits.length === 0) return;
	const alternatives = findAlternativeRooms(reservations, input.roomId, input.checkIn, input.checkOut, roomList, blocks, saleCloses);
	throw new OverbookingError(closeHits.length ? "Venda fechada neste tipo e período. A inserção foi recusada." : blockHits.length ? "Este quarto está bloqueado neste período. A inserção foi recusada." : "OVERBOOKING: já existe reserva ativa neste quarto e período. A inserção foi recusada.", conflicts, alternatives);
}
var EmailError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "EmailError";
	}
};
var EMAIL_RE = /^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$/i;
function normalizeEmail(value) {
	return value.trim().toLowerCase();
}
function isValidEmail(value) {
	const email = normalizeEmail(value);
	if (!email || email.length > 160) return false;
	if (email.includes("..")) return false;
	if (email.startsWith(".") || email.endsWith(".")) return false;
	return EMAIL_RE.test(email);
}
function assertValidEmail(value) {
	const email = normalizeEmail(value);
	if (!isValidEmail(email)) throw new EmailError("Informe um e-mail válido, no formato nome@dominio.com.");
	return email;
}
var VAULT_ID = "aurora";
function asSaleCloses(value) {
	if (!Array.isArray(value)) return [];
	return value.filter((row) => {
		if (!row || typeof row !== "object") return false;
		const close = row;
		return typeof close.id === "string" && typeof close.roomType === "string" && typeof close.checkIn === "string" && typeof close.checkOut === "string" && typeof close.reason === "string";
	});
}
function asBlocks(value) {
	if (!Array.isArray(value)) return [];
	return value.filter((row) => {
		if (!row || typeof row !== "object") return false;
		const block = row;
		return typeof block.id === "string" && typeof block.roomId === "string" && typeof block.checkIn === "string" && typeof block.checkOut === "string" && typeof block.reason === "string";
	});
}
function isVault(value) {
	if (!value || typeof value !== "object") return false;
	const vault = value;
	return vault.version === 1 && Array.isArray(vault.reservations);
}
function parseVault(payload) {
	if (!payload) return null;
	try {
		const parsed = JSON.parse(payload);
		if (!isVault(parsed)) return null;
		return {
			...parsed,
			blocks: asBlocks(parsed.blocks),
			saleCloses: asSaleCloses(parsed.saleCloses)
		};
	} catch {
		return null;
	}
}
function occupancyOf(reservations) {
	return reservations.map((row) => ({
		id: row.id,
		roomId: row.roomId,
		checkIn: row.checkIn,
		checkOut: row.checkOut,
		status: row.status
	}));
}
function mergeReservations(base, extras) {
	const ids = new Set(base.map((row) => row.id));
	const out = [...base];
	for (const extra of extras) {
		if (ids.has(extra.id)) continue;
		out.push(extra);
		ids.add(extra.id);
	}
	return out;
}
function mergeBlocks(base, extras) {
	const ids = new Set(base.map((row) => row.id));
	const out = [...base];
	for (const extra of extras) {
		if (!extra?.id || ids.has(extra.id)) continue;
		out.push(extra);
		ids.add(extra.id);
	}
	return out;
}
function mergeSaleCloses(base, extras) {
	const ids = new Set(base.map((row) => row.id));
	const out = [...base];
	for (const extra of extras) {
		if (!extra?.id || ids.has(extra.id)) continue;
		out.push(extra);
		ids.add(extra.id);
	}
	return out;
}
function mergePagamentos(base, extras) {
	const ids = new Set(base.map((row) => row.id));
	const out = [...base];
	for (const extra of extras) {
		if (!extra?.id || ids.has(extra.id)) continue;
		out.push(extra);
		ids.add(extra.id);
	}
	return out;
}
function mergeConsumos(base, extras) {
	const ids = new Set(base.map((row) => row.id));
	const out = [...base];
	for (const extra of extras) {
		if (!extra?.id || ids.has(extra.id)) continue;
		out.push(extra);
		ids.add(extra.id);
	}
	return out;
}
function isSiteBooking(row) {
	return row.origin === "Link público";
}
function asConsumo(raw, reservaId) {
	if (!raw || typeof raw !== "object") return null;
	const row = raw;
	if (typeof row.id !== "string" || typeof row.descricao !== "string" || typeof row.valor !== "number" || row.valor < 0 || typeof row.quantidade !== "number" || row.quantidade < 1) return null;
	return {
		id: row.id,
		reserva_id: row.reserva_id || reservaId,
		descricao: row.descricao,
		valor: row.valor,
		quantidade: row.quantidade,
		data_lancamento: row.data_lancamento || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
	};
}
function splitPublicPending(raw) {
	if (!raw || typeof raw !== "object") return null;
	const row = raw;
	if (!row.id || !row.roomId || !row.checkIn || !row.checkOut) return null;
	const { deposit, extras, consumos, ...rest } = row;
	const reservation = rest;
	const parsedConsumos = (Array.isArray(consumos) ? consumos : Array.isArray(extras) ? extras : []).map((item) => asConsumo(item, reservation.id)).filter((item) => Boolean(item));
	if (deposit && typeof deposit === "object" && typeof deposit.id === "string" && typeof deposit.valor === "number" && deposit.valor > 0) return {
		reservation,
		deposit: {
			...deposit,
			reserva_id: deposit.reserva_id || reservation.id
		},
		consumos: parsedConsumos
	};
	return {
		reservation,
		consumos: parsedConsumos
	};
}
function absorbSiteBookings(target, slice) {
	if (!slice) return target;
	const extras = (slice.reservations ?? []).filter(isSiteBooking);
	const mergedRes = mergeReservations(target.reservations, extras);
	const mergedPays = mergePagamentos(target.pagamentos ?? [], slice.pagamentos ?? []);
	const mergedConsumos = mergeConsumos(target.consumos ?? [], slice.consumos ?? []);
	if (mergedRes.length === target.reservations.length && mergedPays.length === (target.pagamentos ?? []).length && mergedConsumos.length === (target.consumos ?? []).length) return target;
	return {
		...target,
		reservations: mergedRes,
		pagamentos: mergedPays,
		consumos: mergedConsumos
	};
}
/** Une duas cópias do cofre: o preferido ganha em id repetido; o outro só acrescenta o que falta. */
function unionVaultReservations(preferred, other) {
	if (!other) return preferred;
	const reservations = mergeReservations(preferred.reservations, other.reservations);
	const pagamentos = mergePagamentos(preferred.pagamentos ?? [], other.pagamentos ?? []);
	const consumos = mergeConsumos(preferred.consumos ?? [], other.consumos ?? []);
	const blocks = mergeBlocks(preferred.blocks ?? [], other.blocks ?? []);
	const saleCloses = mergeSaleCloses(preferred.saleCloses ?? [], other.saleCloses ?? []);
	if (reservations.length === preferred.reservations.length && pagamentos.length === (preferred.pagamentos ?? []).length && consumos.length === (preferred.consumos ?? []).length && blocks.length === (preferred.blocks ?? []).length && saleCloses.length === (preferred.saleCloses ?? []).length) return preferred;
	return {
		...preferred,
		reservations,
		pagamentos,
		consumos,
		blocks,
		saleCloses
	};
}
/**
* Política da casa: check-in, check-out e cancelamento.
* A tela Hotel edita. Site e ficha só leem.
* Proibido: mudar preço, Experiências, ouro, OTA.
* Cofre: campo `property`. Vault antigo sem cancelamento usa o padrão.
*/
var propertyKeys = { current: ["property"] };
function defaultCancellationPolicy(hours) {
	return `Cancelamento gratuito até ${hours}h antes do check-in. Depois desse prazo, o sinal não é reembolsável.`;
}
function alignCancellationPolicy(text, hours) {
	const trimmed = text.trim();
	if (!trimmed) return defaultCancellationPolicy(hours);
	const next = trimmed.replace(/até\s*\d+\s*h(?:oras)?/gi, `até ${hours}h`).replace(/\b\d+\s*h(?:oras)?\s+antes/gi, `${hours}h antes`);
	return /\d+\s*h/.test(next) ? next : defaultCancellationPolicy(hours);
}
var DEFAULT_PROPERTY = {
	hotelId: "hotel-aurora",
	name: "Hotel Aurora",
	logoUrl: "",
	cnpj: "12.345.678/0001-90",
	phone: "(11) 4000-2026",
	address: "Rua das Palmeiras, 120 — Centro, Serra Azul/SP",
	pixKey: "pix@hotelaurora.com",
	pixPayee: "Hotel Aurora Hospedagem Ltda",
	transferInstructions: "Enviar o comprovante do sinal pelo WhatsApp da recepção.",
	checkInTime: "14:00",
	checkOutTime: "12:00",
	lateCheckoutMinutes: 60,
	cancelFreeHours: 48,
	cancellationPolicy: defaultCancellationPolicy(48),
	overbookingMode: "bloquear",
	depositPercent: 30
};
function asTime(value, fallback) {
	if (typeof value !== "string") return fallback;
	const trimmed = value.trim();
	return /^\d{2}:\d{2}$/.test(trimmed) ? trimmed : fallback;
}
function asHours(value, fallback) {
	const n = Number(value);
	if (!Number.isFinite(n)) return fallback;
	return Math.min(168, Math.max(0, Math.round(n)));
}
function normalizeProperty(raw) {
	const hours = asHours(raw?.cancelFreeHours, DEFAULT_PROPERTY.cancelFreeHours);
	const policy = alignCancellationPolicy(typeof raw?.cancellationPolicy === "string" ? raw.cancellationPolicy : "", hours);
	return {
		...DEFAULT_PROPERTY,
		...raw,
		name: (raw?.name ?? DEFAULT_PROPERTY.name).trim() || DEFAULT_PROPERTY.name,
		hotelId: (raw?.hotelId ?? DEFAULT_PROPERTY.hotelId).trim() || DEFAULT_PROPERTY.hotelId,
		pixKey: (raw?.pixKey ?? DEFAULT_PROPERTY.pixKey).trim(),
		pixPayee: (raw?.pixPayee ?? DEFAULT_PROPERTY.pixPayee).trim(),
		checkInTime: asTime(raw?.checkInTime, DEFAULT_PROPERTY.checkInTime),
		checkOutTime: asTime(raw?.checkOutTime, DEFAULT_PROPERTY.checkOutTime),
		lateCheckoutMinutes: asHours(raw?.lateCheckoutMinutes, DEFAULT_PROPERTY.lateCheckoutMinutes),
		cancelFreeHours: hours,
		cancellationPolicy: policy,
		overbookingMode: raw?.overbookingMode === "alertar" ? "alertar" : "bloquear",
		depositPercent: [
			30,
			50,
			100
		].includes(Number(raw?.depositPercent)) ? Number(raw?.depositPercent) : DEFAULT_PROPERTY.depositPercent
	};
}
var property = { ...DEFAULT_PROPERTY };
function getProperty() {
	property = normalizeProperty(property);
	return { ...property };
}
function replaceProperty(next) {
	property = normalizeProperty(next);
}
function saveProperty(next) {
	property = normalizeProperty(next);
	return getProperty();
}
function cancellationDeadline(checkIn, profile = getProperty()) {
	const start = /* @__PURE__ */ new Date(`${checkIn}T${profile.checkInTime}:00`);
	return /* @__PURE__ */ new Date(start.getTime() - profile.cancelFreeHours * 60 * 60 * 1e3);
}
function isCancelFree(checkIn, at = /* @__PURE__ */ new Date(), profile = getProperty()) {
	return at.getTime() <= cancellationDeadline(checkIn, profile).getTime();
}
function stayHoursLabel(profile = getProperty()) {
	return `Check-in ${profile.checkInTime} · Check-out ${profile.checkOutTime}`;
}
var bookingKeys = { config: ["booking-engine"] };
var EXTRA_UNIT_LABEL = {
	hospede: "por hóspede",
	noite: "por noite",
	estadia: "por estadia"
};
var DEFAULT_EXTRAS = [
	{
		id: "cafe",
		name: "Café da manhã extra",
		price: 45,
		unit: "hospede",
		enabled: true
	},
	{
		id: "traslado",
		name: "Traslado aeroporto",
		price: 120,
		unit: "estadia",
		enabled: true
	},
	{
		id: "cama",
		name: "Cama extra",
		price: 80,
		unit: "noite",
		enabled: true
	}
];
var UNITS = /* @__PURE__ */ new Set([
	"hospede",
	"noite",
	"estadia"
]);
function normalizeExtras(list) {
	const byId = new Map((list ?? []).map((row) => [row.id, row]));
	return DEFAULT_EXTRAS.map((def) => {
		const row = byId.get(def.id);
		if (!row) return { ...def };
		const price = Number(row.price);
		return {
			id: def.id,
			name: row.name?.trim() || def.name,
			price: Number.isFinite(price) && price >= 0 ? Math.round(price) : def.price,
			unit: UNITS.has(row.unit) ? row.unit : def.unit,
			enabled: row.enabled !== false
		};
	});
}
function extraQuantity(extra, nights, guests) {
	if (extra.unit === "hospede") return Math.max(1, guests);
	if (extra.unit === "noite") return Math.max(1, nights);
	return 1;
}
function quoteExtras(catalog, selectedIds, nights, guests) {
	const picked = new Set(selectedIds);
	const lines = catalog.filter((item) => item.enabled && picked.has(item.id) && item.price >= 0).map((item) => {
		const quantity = extraQuantity(item, nights, guests);
		return {
			id: item.id,
			name: item.name,
			unitPrice: item.price,
			quantity,
			total: item.price * quantity
		};
	});
	return {
		lines,
		total: lines.reduce((sum, line) => sum + line.total, 0)
	};
}
var DEFAULT_CONFIG = {
	photos: [
		"https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=60",
		"https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=60",
		"https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=60"
	],
	cancellationPolicy: "Cancelamento gratuito até 48h antes do check-in. Após esse prazo, o sinal de garantia não é reembolsável.",
	checkInTime: "14:00",
	checkOutTime: "12:00",
	pixKey: "pix@hotelaurora.com",
	depositPercent: 30,
	extras: DEFAULT_EXTRAS.map((row) => ({ ...row }))
};
var config = {
	...DEFAULT_CONFIG,
	photos: [...DEFAULT_CONFIG.photos],
	extras: DEFAULT_EXTRAS.map((row) => ({ ...row }))
};
function getBookingConfig() {
	const property = getProperty();
	return {
		...config,
		photos: [...config.photos],
		extras: normalizeExtras(config.extras),
		checkInTime: property.checkInTime,
		checkOutTime: property.checkOutTime,
		pixKey: property.pixKey,
		depositPercent: property.depositPercent,
		cancellationPolicy: property.cancellationPolicy
	};
}
function replaceBookingConfig(next) {
	config = {
		...next,
		photos: [...next.photos],
		extras: normalizeExtras(next.extras)
	};
}
function saveBookingConfig(next) {
	config = {
		...next,
		photos: next.photos.map((url) => url.trim()).filter(Boolean),
		cancellationPolicy: next.cancellationPolicy.trim(),
		pixKey: next.pixKey.trim(),
		extras: normalizeExtras(next.extras)
	};
	return getBookingConfig();
}
//#endregion
export { reservations as $, getBookingConfig as A, mergeReservations as B, createSaleClose as C, findOverbookedIds as D, findConflicts as E, isSiteBooking as F, parseISODate as G, normalizeEmail as H, isStayActiveOn as I, quoteExtras as J, parseVault as K, listSaleCloses as L, getProperty as M, getReservationsOverlapping as N, formatCurrency as O, isCancelFree as P, replaceSaleCloses as Q, mergeConsumos as R, bookingStore_Bq0ubAXy_exports as S, findBlockConflicts as T, normalizeExtras as U, monthlyMetrics as V, occupancyOf as W, replaceBookingConfig as X, removeSaleClose as Y, replaceProperty as Z, assertValidPeriod as _, HOUSEKEEPING_LABEL as a, saveBookingConfig as at, blocksCheckIn as b, TODAY as c, stayHoursLabel as ct, absorbSiteBookings as d, unionVaultReservations as dt, roomById as et, alignCancellationPolicy as f, assertValidEmail as g, assertStayTransition as h, HOUSEKEEPING_DOT as i, saleCloseOnNight as it, getDashboardStats as j, formatStayRange as k, TODAY_ISO as l, stayNights as lt, assertNoOverbooking as m, EXTRA_UNIT_LABEL as n, rooms as nt, HOUSEKEEPING_ORDER as o, saveProperty as ot, appendWithoutOverbooking as p, propertyKeys as q, HOLD_REASON_LABEL as r, saleCloseKeys as rt, OverbookingError as s, splitPublicPending as st, CURRENT_YEAR as t, roomHoldReason as tt, VAULT_ID as u, toISODate as ut, assertVaultTransition as v, extraQuantity as w, bookingKeys as x, availableRoomsByType as y, mergePagamentos as z };
