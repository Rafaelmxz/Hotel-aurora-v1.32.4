import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { i as format, t as ptBR } from "../_libs/date-fns.mjs";
import { O as formatCurrency, c as TODAY, et as roomById, l as TODAY_ISO } from "./bookingStore-Bq0ubAXy.mjs";
import { d as Printer, t as X } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { E as persistVault, J as folioKeys, M as METODO_PAGAMENTO_LABEL, Pt as cn, S as getCashClose, a as Input, et as listAllPagamentos, i as Label, j as totalsForDate, o as Button, p as useProperty, v as cashKeys, y as closeCash } from "./router-D2QglEY4.mjs";
import { n as CardContent, t as Card } from "./card-C5pfQ1_E.mjs";
import { t as Textarea } from "./textarea-CJRv6rNU.mjs";
import { a as useReservations } from "./useReservations-BEok-WZp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/caixa-z-ZXBYd7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useDailyCash(date = TODAY_ISO) {
	const payments = useQuery({
		queryKey: [
			...folioKeys.all,
			"payments",
			date
		],
		queryFn: async () => listAllPagamentos().filter((item) => item.data_pagamento === date),
		initialData: () => listAllPagamentos().filter((item) => item.data_pagamento === date)
	});
	const close = useQuery({
		queryKey: cashKeys.day(date),
		queryFn: async () => getCashClose(date) ?? null,
		initialData: () => getCashClose(date) ?? null
	});
	return {
		payments: payments.data ?? [],
		totals: totalsForDate(date),
		close: close.data,
		isClosed: close.data?.status === "fechado"
	};
}
function useCloseCash(date = TODAY_ISO) {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => {
			const report = closeCash({
				...input,
				date
			});
			await persistVault();
			return report;
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: cashKeys.all });
			await queryClient.invalidateQueries({ queryKey: cashKeys.day(date) });
			await queryClient.invalidateQueries({ queryKey: folioKeys.all });
		}
	});
}
var METHODS = [
	"pix",
	"cartao_credito",
	"cartao_debito",
	"dinheiro"
];
function DailyCashRegister() {
	const { payments, totals, close, isClosed } = useDailyCash(TODAY_ISO);
	const { data: reservations = [] } = useReservations();
	const { data: property } = useProperty();
	const closeMutation = useCloseCash(TODAY_ISO);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [counted, setCounted] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const reservationById = (0, import_react.useMemo)(() => {
		return new Map(reservations.map((row) => [row.id, row]));
	}, [reservations]);
	const countedValue = Number(counted.replace(",", "."));
	const countedOk = Number.isFinite(countedValue) && countedValue >= 0;
	const difference = countedOk ? countedValue - totals.dinheiro : 0;
	async function onClose(event) {
		event.preventDefault();
		if (!countedOk) return;
		try {
			await closeMutation.mutateAsync({
				countedCash: countedValue,
				notes
			});
			toast.success("Caixa encerrado");
			setOpen(false);
		} catch {
			toast.error("Não foi possível encerrar o caixa.");
		}
	}
	function printReport() {
		window.print();
	}
	function exportReport() {
		const lines = [
			`${property.name} — Fechamento de caixa`,
			format(TODAY, "dd/MM/yyyy", { locale: ptBR }),
			"",
			...METHODS.map((method) => `${METODO_PAGAMENTO_LABEL[method]}: ${formatCurrency(totals[method])}`),
			`Total: ${formatCurrency(totals.total)}`,
			`Dinheiro no sistema: ${formatCurrency(totals.dinheiro)}`,
			close ? `Dinheiro contado: ${formatCurrency(close.countedCash)}\nDiferença: ${formatCurrency(close.difference)}\n${close.notes ?? ""}` : "Status: aberto"
		];
		const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `caixa-${TODAY_ISO}.txt`;
		link.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Financeiro"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-medium tracking-tight",
						children: "Caixa do dia"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [format(TODAY, "EEEE, d 'de' MMMM", { locale: ptBR }), isClosed ? " · fechado" : " · aberto"]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: exportReport,
							children: "Exportar"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: printReport,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Imprimir"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							disabled: isClosed,
							onClick: () => setOpen(true),
							children: "Encerrar caixa"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-5 print:grid-cols-5",
				children: [METHODS.map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "pt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: METODO_PAGAMENTO_LABEL[method]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display mt-2 text-2xl font-medium tracking-tight tabular-nums",
						children: formatCurrency(totals[method])
					})]
				}) }, method)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "bg-primary text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "pt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide uppercase opacity-80",
							children: "Total"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display mt-2 text-2xl font-medium tracking-tight tabular-nums",
							children: formatCurrency(totals.total)
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "overflow-x-auto rounded-xl bg-card shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[40rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-secondary text-xs tracking-wide text-muted-foreground uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Hora"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Hóspede"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Quarto"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Método"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium text-right",
								children: "Valor"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: payments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 5,
						className: "px-4 py-8 text-center text-muted-foreground",
						children: "Nenhum pagamento hoje."
					}) }) : payments.slice().sort((a, b) => (a.hora ?? "").localeCompare(b.hora ?? "")).map((item) => {
						const reservation = reservationById.get(item.reserva_id);
						const room = reservation ? roomById(reservation.roomId) : void 0;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 tabular-nums",
									children: item.hora ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: reservation?.guestName ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 tabular-nums",
									children: room?.number ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: METODO_PAGAMENTO_LABEL[item.metodo]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-right tabular-nums",
									children: formatCurrency(item.valor)
								})
							]
						}, item.id);
					}) })]
				})
			}),
			close ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Fechamento"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid gap-2 text-sm sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: "Dinheiro no sistema"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums sm:text-right",
								children: formatCurrency(close.systemCash)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: "Dinheiro contado"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums sm:text-right",
								children: formatCurrency(close.countedCash)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: "Diferença"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: cn("tabular-nums sm:text-right", close.difference !== 0 && "text-status-pending"),
								children: [formatCurrency(close.difference), close.difference > 0 ? " · sobra" : close.difference < 0 ? " · falta" : " · conferido"]
							})
						]
					}),
					close.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm",
						children: close.notes
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open,
				onOpenChange: setOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-[60] bg-foreground/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "fixed top-1/2 left-1/2 z-[70] w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-card p-6 text-card-foreground shadow-lg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "font-display text-xl font-medium tracking-tight",
							children: "Encerrar caixa do dia"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Compare o dinheiro da gaveta com o registrado no sistema."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
							className: "absolute top-4 right-4 opacity-70 hover:opacity-100",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Fechar"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: onClose,
							className: "mt-5 grid gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm",
									children: [
										"Dinheiro no sistema:",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium tabular-nums",
											children: formatCurrency(totals.dinheiro)
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "counted-cash",
										children: "Valor contado na gaveta"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "counted-cash",
										required: true,
										inputMode: "decimal",
										value: counted,
										onChange: (event) => setCounted(event.target.value),
										placeholder: String(totals.dinheiro)
									})]
								}),
								countedOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: cn("text-sm", difference !== 0 && "text-status-pending"),
									children: [
										"Diferença: ",
										formatCurrency(difference),
										difference > 0 ? " (sobra / troco)" : difference < 0 ? " (falta / sangria)" : " (bateu)"
									]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "cash-notes",
										children: "Observações do turno"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "cash-notes",
										value: notes,
										onChange: (event) => setNotes(event.target.value),
										placeholder: "Ex.: sobrou R$ 2,00 no troco"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: closeMutation.isPending || !countedOk,
									children: "Confirmar fechamento"
								})
							]
						})
					]
				})] })
			})
		]
	});
}
var SplitComponent = DailyCashRegister;
//#endregion
export { SplitComponent as component };
