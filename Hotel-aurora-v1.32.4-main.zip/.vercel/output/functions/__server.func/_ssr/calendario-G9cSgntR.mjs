import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as getRouteApi } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { _ as isWeekend, i as format, l as isSameDay, p as differenceInCalendarDays, t as ptBR, y as addDays } from "../_libs/date-fns.mjs";
import { D as findOverbookedIds, E as findConflicts, G as parseISODate, N as getReservationsOverlapping, O as formatCurrency, P as isCancelFree, T as findBlockConflicts, a as HOUSEKEEPING_LABEL, b as blocksCheckIn, c as TODAY, ct as stayHoursLabel, et as roomById, i as HOUSEKEEPING_DOT, it as saleCloseOnNight, k as formatStayRange, l as TODAY_ISO, lt as stayNights, o as HOUSEKEEPING_ORDER, ut as toISODate } from "./bookingStore-Bq0ubAXy.mjs";
import { C as ChevronLeft, S as ChevronRight, a as TriangleAlert, g as LogIn, h as LogOut, k as Ban, t as X, x as Clock } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { E as persistVault, F as addConsumo, J as folioKeys, M as METODO_PAGAMENTO_LABEL, Pt as cn, R as addPagamento, Y as getFolio, a as Input, i as Label, o as Button, p as useProperty, q as findGuestByName, ut as notesSayPayAtCheckIn, x as ensureVaultRestored, xt as removeConsumo } from "./router-D2QglEY4.mjs";
import { n as STATUS_BAR, r as STATUS_LABEL, t as STATUS_BADGE } from "./status-lXSun_aS.mjs";
import { t as Textarea } from "./textarea-CJRv6rNU.mjs";
import { a as useReservations, i as usePatchReservation, t as syncReservationQueries } from "./useReservations-BEok-WZp.mjs";
import { r as useRooms, t as useMarkRoomDirty } from "./useRooms-DVLudIq6.mjs";
import { t as Badge } from "./badge-XwZ3ZDTe.mjs";
import { n as useCreateBlock, r as useRemoveBlock, t as useBlocks } from "./useBlocks-Dt0MBuAT.mjs";
import { n as useRemoveSaleClose, r as useSaleCloses, t as useCreateSaleClose } from "./useSaleCloses-BDBCA2UD.mjs";
import { n as OnMapDialog, r as PendingBookingsAlert, t as CreateReservationModal } from "./PendingBookingsAlert-CWuJWCAN.mjs";
import { t as FolioStatement } from "./FolioStatement-D_wrLK-R.mjs";
import { i as pixTxid, n as StayVoucher, t as PixCharge } from "./StayVoucher-BMRYBVTZ.mjs";
import { t as useBookingConfig } from "./useBookingEngine-1wAIPgj0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/calendario-G9cSgntR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var EMPTY_FOLIO = {
	reservaId: "",
	itens: [],
	pagamentos: [],
	linhas: [],
	totais: {
		totalDiarias: 0,
		totalConsumo: 0,
		totalPagamentos: 0,
		saldo: 0
	}
};
function useFolio(reservationId) {
	const queryClient = useQueryClient();
	const query = useQuery({
		queryKey: folioKeys.byReservation(reservationId ?? ""),
		queryFn: async () => {
			await ensureVaultRestored();
			return getFolio(reservationId);
		},
		enabled: Boolean(reservationId),
		initialData: () => reservationId ? getFolio(reservationId) : EMPTY_FOLIO
	});
	const folio = query.data ?? EMPTY_FOLIO;
	async function invalidateFolio() {
		await persistVault();
		if (!reservationId) return;
		await queryClient.invalidateQueries({ queryKey: folioKeys.byReservation(reservationId) });
		await queryClient.invalidateQueries({ queryKey: folioKeys.all });
	}
	const addItem = useMutation({
		mutationFn: async (input) => {
			if (!reservationId) throw new Error("Reserva não informada");
			return addConsumo({
				reserva_id: reservationId,
				...input
			});
		},
		onSuccess: invalidateFolio
	});
	const removeItem = useMutation({
		mutationFn: async (id) => removeConsumo(id),
		onSuccess: invalidateFolio
	});
	const addPayment = useMutation({
		mutationFn: async (input) => {
			if (!reservationId) throw new Error("Reserva não informada");
			return addPagamento({
				reserva_id: reservationId,
				...input
			});
		},
		onSuccess: async () => {
			await invalidateFolio();
		}
	});
	return {
		...query,
		itens: folio.itens,
		pagamentos: folio.pagamentos,
		linhas: folio.linhas,
		totais: folio.totais,
		saldo: folio.totais.saldo,
		addItem,
		removeItem,
		addPayment
	};
}
function ReservationFolio({ reservationId, onRegisterPayment }) {
	const folio = useFolio(reservationId);
	const [descricao, setDescricao] = (0, import_react.useState)("");
	const [valor, setValor] = (0, import_react.useState)("");
	const [quantidade, setQuantidade] = (0, import_react.useState)("1");
	async function onSubmit(event) {
		event.preventDefault();
		const parsedValor = Number(valor.replace(",", "."));
		const parsedQtd = Number(quantidade);
		if (!descricao.trim() || !Number.isFinite(parsedValor) || parsedValor <= 0) return;
		if (!Number.isFinite(parsedQtd) || parsedQtd <= 0) return;
		try {
			await folio.addItem.mutateAsync({
				descricao: descricao.trim(),
				valor: parsedValor,
				quantidade: parsedQtd
			});
			setDescricao("");
			setValor("");
			setQuantidade("1");
			toast.success("Consumo lançado");
		} catch {
			toast.error("Não foi possível lançar o consumo.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "flex flex-col gap-3 rounded-lg border border-border bg-secondary/50 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Novo consumo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "folio-descricao",
							children: "Descrição"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "folio-descricao",
							required: true,
							value: descricao,
							onChange: (event) => setDescricao(event.target.value),
							placeholder: "Ex.: Frigobar, café extra"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "folio-valor",
								children: "Valor (R$)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "folio-valor",
								required: true,
								inputMode: "decimal",
								value: valor,
								onChange: (event) => setValor(event.target.value),
								placeholder: "0,00"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "folio-qtd",
								children: "Quantidade"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "folio-qtd",
								required: true,
								inputMode: "numeric",
								value: quantidade,
								onChange: (event) => setQuantidade(event.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: folio.addItem.isPending,
						children: "Lançar item"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolioStatement, {
				linhas: folio.linhas,
				totais: folio.totais,
				onRemoveConsumo: (id) => folio.removeItem.mutate(id)
			}),
			onRegisterPayment ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				className: "w-full",
				onClick: onRegisterPayment,
				children: "Registrar pagamento"
			}) : null
		]
	});
}
var METODOS = [
	"pix",
	"cartao_credito",
	"cartao_debito",
	"dinheiro"
];
function ReservationPaymentModal({ reservationId, guestName, open, onOpenChange, onSettled }) {
	const folio = useFolio(reservationId);
	const { data: property } = useProperty();
	const [valor, setValor] = (0, import_react.useState)("");
	const [metodo, setMetodo] = (0, import_react.useState)("pix");
	const [observacao, setObservacao] = (0, import_react.useState)("");
	const saldo = folio.totais.saldo;
	const parsedValor = Number(valor.replace(",", "."));
	const pixAmount = Number.isFinite(parsedValor) && parsedValor > 0 ? parsedValor : saldo;
	(0, import_react.useEffect)(() => {
		if (open) setValor(saldo > 0 ? String(saldo) : "");
	}, [open, saldo]);
	async function onSubmit(event) {
		event.preventDefault();
		const parsed = Number(valor.replace(",", "."));
		if (!Number.isFinite(parsed) || parsed <= 0) return;
		try {
			await folio.addPayment.mutateAsync({
				valor: parsed,
				metodo,
				observacao: metodo === "pix" ? [observacao.trim(), `Pix ${pixTxid(`${reservationId}-${parsed}`)}`].filter(Boolean).join(" · ") : observacao.trim() || void 0
			});
			const nextSaldo = getSaldoAfter(saldo, parsed);
			toast.success(`Pagamento de ${formatCurrency(parsed)} registrado`);
			setObservacao("");
			onSettled?.(nextSaldo);
			if (nextSaldo <= 0) onOpenChange(false);
			else setValor(String(nextSaldo));
		} catch {
			toast.error("Não foi possível registrar o pagamento.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-[60] bg-foreground/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			onOpenAutoFocus: (event) => event.preventDefault(),
			onInteractOutside: (event) => event.preventDefault(),
			onPointerDownOutside: (event) => event.preventDefault(),
			onFocusOutside: (event) => event.preventDefault(),
			className: "fixed top-1/2 left-1/2 z-[70] flex max-h-[90dvh] w-[calc(100%-2rem)] max-w-md -translate-x-1/2 -translate-y-1/2 flex-col overflow-y-auto rounded-xl border border-border bg-card p-6 text-card-foreground shadow-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Pagamento e fechamento"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
					className: "mt-1 text-sm text-muted-foreground",
					children: [guestName, " · quite o saldo para liberar o check-out"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
					className: "absolute top-4 right-4 rounded-sm opacity-70 hover:opacity-100",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Fechar"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-5 grid grid-cols-2 gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted-foreground",
							children: "Diárias"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-right tabular-nums",
							children: formatCurrency(folio.totais.totalDiarias)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted-foreground",
							children: "Consumos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "text-right tabular-nums",
							children: formatCurrency(folio.totais.totalConsumo)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-muted-foreground",
							children: "Pagamentos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "text-right tabular-nums",
							children: ["− ", formatCurrency(folio.totais.totalPagamentos)]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 rounded-xl bg-secondary px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Saldo devedor"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display mt-1 text-2xl font-medium tracking-tight tabular-nums",
						children: formatCurrency(saldo)
					})]
				}),
				folio.pagamentos.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-1 text-sm",
					children: folio.pagamentos.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [METODO_PAGAMENTO_LABEL[item.metodo], item.observacao ? ` · ${item.observacao}` : ""]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: formatCurrency(item.valor)
						})]
					}, item.id))
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "mt-5 flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "pay-valor",
								children: "Valor a pagar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "pay-valor",
									required: true,
									inputMode: "decimal",
									value: valor,
									onChange: (event) => setValor(event.target.value)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									className: "shrink-0",
									disabled: saldo <= 0,
									onClick: () => setValor(String(saldo)),
									children: "Saldo total"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Forma de pagamento" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-2",
								children: METODOS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMetodo(option),
									className: metodo === option ? "h-10 rounded-md border-2 border-primary bg-primary/10 px-2 text-sm font-medium" : "h-10 rounded-md border border-input bg-card px-2 text-sm",
									children: METODO_PAGAMENTO_LABEL[option]
								}, option))
							})]
						}),
						metodo === "pix" && pixAmount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixCharge, {
							amount: pixAmount,
							pixKey: property.pixKey,
							payee: property.pixPayee || property.name,
							address: property.address,
							seed: `${reservationId}-${pixAmount}`,
							description: `Folio ${guestName}`
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "pay-obs",
								children: "Observação"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "pay-obs",
								value: observacao,
								onChange: (event) => setObservacao(event.target.value),
								placeholder: "Opcional"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: folio.addPayment.isPending || saldo <= 0,
							children: metodo === "pix" ? "Registrar Pix recebido" : "Registrar pagamento"
						})
					]
				})
			]
		})] })
	});
}
function getSaldoAfter(saldo, pago) {
	return Math.max(0, Math.round(saldo - pago));
}
function nowLocal() {
	return format(/* @__PURE__ */ new Date(), "yyyy-MM-dd'T'HH:mm");
}
function toDateTimeLocal(value) {
	if (!value) return "";
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return value.slice(0, 16);
	return format(date, "yyyy-MM-dd'T'HH:mm");
}
function fromDateTimeLocal(value) {
	if (!value) return void 0;
	const date = new Date(value);
	return Number.isNaN(date.getTime()) ? value : date.toISOString();
}
var ACTIONS = [
	{
		status: "check-in",
		label: "Em check-in",
		hint: "Hóspede no hotel",
		icon: LogIn,
		variant: "default"
	},
	{
		status: "check-out",
		label: "Checked-out",
		hint: "Saída registrada",
		icon: LogOut,
		variant: "secondary"
	},
	{
		status: "cancelada",
		label: "Cancelado",
		hint: "Libera o quarto",
		icon: Ban,
		variant: "destructive"
	}
];
function CheckInModal({ reservation, onOpenChange }) {
	const patch = usePatchReservation();
	const queryClient = useQueryClient();
	const markDirty = useMarkRoomDirty();
	const { data: rooms = [] } = useRooms();
	const [tab, setTab] = (0, import_react.useState)("atendimento");
	const [checkInAt, setCheckInAt] = (0, import_react.useState)("");
	const [checkOutAt, setCheckOutAt] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [fnrhDoc, setFnrhDoc] = (0, import_react.useState)("");
	const [fnrhBirth, setFnrhBirth] = (0, import_react.useState)("");
	const [fnrhNation, setFnrhNation] = (0, import_react.useState)("Brasil");
	const [fnrhJob, setFnrhJob] = (0, import_react.useState)("");
	const [fnrhFrom, setFnrhFrom] = (0, import_react.useState)("");
	const [fnrhTo, setFnrhTo] = (0, import_react.useState)("");
	const [paymentOpen, setPaymentOpen] = (0, import_react.useState)(false);
	const [checkoutPending, setCheckoutPending] = (0, import_react.useState)(false);
	const [localStatus, setLocalStatus] = (0, import_react.useState)(null);
	const folio = useFolio(reservation?.id);
	const { data: bookingConfig } = useBookingConfig();
	const { data: property } = useProperty();
	const displayStatus = localStatus ?? reservation?.status ?? "pendente";
	const isPreReservation = displayStatus === "pendente";
	(0, import_react.useEffect)(() => {
		if (!reservation) {
			setLocalStatus(null);
			return;
		}
		setTab("atendimento");
		setCheckInAt(toDateTimeLocal(reservation.actualCheckInAt) || nowLocal());
		setCheckOutAt(toDateTimeLocal(reservation.actualCheckOutAt));
		setNotes(reservation.receptionNotes ?? "");
		setFnrhDoc(reservation.fnrh?.document ?? findGuestByName(reservation.guestName)?.cpf ?? "");
		setFnrhBirth(reservation.fnrh?.birthDate ?? "");
		setFnrhNation(reservation.fnrh?.nationality || "Brasil");
		setFnrhJob(reservation.fnrh?.profession ?? "");
		setFnrhFrom(reservation.fnrh?.originCity ?? "");
		setFnrhTo(reservation.fnrh?.nextCity ?? "");
		setLocalStatus(reservation.status);
	}, [reservation?.id]);
	const room = reservation ? roomById(reservation.roomId) : void 0;
	const roomState = rooms.find((item) => item.id === reservation?.roomId);
	const housekeepingBlocked = roomState ? blocksCheckIn(roomState.housekeepingStatus) : false;
	const guestProfile = reservation ? findGuestByName(reservation.guestName) : void 0;
	async function completeCheckout() {
		if (!reservation) return;
		const payload = {
			id: reservation.id,
			status: "check-out",
			receptionNotes: notes.trim() || void 0,
			actualCheckInAt: fromDateTimeLocal(checkInAt || nowLocal()) ?? reservation.actualCheckInAt,
			actualCheckOutAt: fromDateTimeLocal(checkOutAt || nowLocal())
		};
		await patch.mutateAsync(payload);
		await markDirty.mutateAsync(reservation.roomId);
		setCheckoutPending(false);
		toast.success(`Checked-out · ${reservation.guestName} · quarto sujo`);
	}
	async function confirmPreReservation() {
		if (!reservation) return;
		const payAtCheckIn = notesSayPayAtCheckIn(reservation.notes);
		const deposit = Math.max(1, Math.round(reservation.totalAmount * (bookingConfig.depositPercent / 100)));
		try {
			const updated = await patch.mutateAsync({
				id: reservation.id,
				status: "confirmada",
				receptionNotes: notes.trim() || void 0
			});
			if (!payAtCheckIn) await folio.addPayment.mutateAsync({
				valor: deposit,
				metodo: "pix",
				descricao: "Sinal da pré-reserva",
				observacao: `Sinal da pré-reserva (${bookingConfig.depositPercent}%)`
			});
			await syncReservationQueries(queryClient, updated);
			setLocalStatus("confirmada");
			toast.success(payAtCheckIn ? "Reserva confirmada · pagamento no check-in" : `Reserva confirmada · sinal de ${formatCurrency(deposit)} no extrato`);
		} catch {
			toast.error("Não foi possível confirmar a pré-reserva.");
		}
	}
	async function applyStatus(status) {
		if (!reservation) return;
		if (status === "check-out") {
			const saldo = Math.round(folio.totais.saldo);
			if (saldo > 0) {
				setCheckoutPending(true);
				setPaymentOpen(true);
				toast.warning(`Saldo pendente de ${formatCurrency(saldo)}. Quite a conta para concluir.`);
				return;
			}
			try {
				await completeCheckout();
			} catch (error) {
				toast.error(error instanceof Error ? error.message : "Não foi possível atualizar a reserva.");
			}
			return;
		}
		if (status === "check-in") {
			if (housekeepingBlocked) {
				toast.warning(`Quarto ${roomState?.number ?? ""} está ${HOUSEKEEPING_LABEL[roomState.housekeepingStatus]}. Libere na governança antes do check-in.`);
				return;
			}
			if (fnrhDoc.trim().length < 5 || !fnrhBirth) {
				toast.error("Preencha a FNRH: documento e data de nascimento.");
				return;
			}
		}
		if (status === "cancelada") {
			const free = isCancelFree(reservation.checkIn, /* @__PURE__ */ new Date(), property);
			toast.message(free ? `Dentro da janela gratuita (${property.cancelFreeHours}h). ${property.cancellationPolicy}` : `Fora da janela gratuita (${property.cancelFreeHours}h). ${property.cancellationPolicy}`);
		}
		const payload = {
			id: reservation.id,
			status,
			receptionNotes: notes.trim() || void 0,
			fnrh: {
				document: fnrhDoc.trim(),
				birthDate: fnrhBirth,
				nationality: fnrhNation.trim() || "Brasil",
				profession: fnrhJob.trim(),
				originCity: fnrhFrom.trim(),
				nextCity: fnrhTo.trim()
			},
			actualCheckInAt: status === "check-in" ? fromDateTimeLocal(checkInAt || nowLocal()) : reservation.actualCheckInAt,
			actualCheckOutAt: status === "cancelada" ? reservation.actualCheckOutAt : void 0
		};
		try {
			await patch.mutateAsync(payload);
			setLocalStatus(status);
			toast.success(`${STATUS_LABEL[status]} · ${reservation.guestName}`);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível atualizar a reserva.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OnMapDialog, {
		open: Boolean(reservation),
		onOpenChange: (open) => {
			if (!open && paymentOpen) return;
			if (!open) {
				setTab("atendimento");
				setPaymentOpen(false);
				setCheckoutPending(false);
			}
			onOpenChange(open);
		},
		className: "flex max-h-[min(36rem,calc(100dvh-6rem))] flex-col overflow-hidden p-0",
		children: reservation ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-6 pt-6 pr-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: STATUS_BADGE[displayStatus],
						children: STATUS_LABEL[displayStatus]
					}), room ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [
							"Quarto ",
							room.number,
							" · ",
							room.type
						]
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display mt-2 text-xl font-medium tracking-tight",
					children: "Reserva"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
					className: "text-sm text-muted-foreground",
					children: [
						reservation.guestName,
						" · ",
						formatStayRange(reservation.checkIn, reservation.checkOut),
						" · ",
						stayHoursLabel(property)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
					className: "absolute top-4 right-4 opacity-70 hover:opacity-100",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Fechar"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto px-6 pb-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 rounded-full bg-secondary p-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn("h-9 rounded-full text-sm font-medium", tab === "atendimento" ? "bg-card text-foreground shadow-[var(--shadow-border)]" : "text-muted-foreground hover:text-foreground"),
						onClick: () => setTab("atendimento"),
						children: "Atendimento"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn("h-9 rounded-full text-sm font-medium", tab === "extrato" ? "bg-card text-foreground shadow-[var(--shadow-border)]" : "text-muted-foreground hover:text-foreground"),
						onClick: () => setTab("extrato"),
						children: "Conta"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn("h-9 rounded-full text-sm font-medium", tab === "voucher" ? "bg-card text-foreground shadow-[var(--shadow-border)]" : "text-muted-foreground hover:text-foreground"),
						onClick: () => setTab("voucher"),
						children: "Voucher"
					})
				]
			}), tab === "atendimento" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-lg bg-secondary/50 px-3 py-2 text-xs text-muted-foreground",
						children: [
							stayHoursLabel(property),
							". ",
							property.cancellationPolicy
						]
					}),
					housekeepingBlocked && roomState ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 rounded-lg bg-status-pending/10 px-3 py-3 text-sm text-status-pending",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "mt-0.5 size-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Quarto ",
							roomState.number,
							" está",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: HOUSEKEEPING_LABEL[roomState.housekeepingStatus] }),
							roomState.housekeepingNote ? ` · ${roomState.housekeepingNote}` : "",
							". Check-in bloqueado até a governança marcar Limpo."
						] })]
					}) : null,
					guestProfile && (guestProfile.preferences.length > 0 || guestProfile.tags.includes("Inadimplente") || guestProfile.tags.includes("VIP")) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-secondary px-3 py-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: guestProfile.tags.join(" · ")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-muted-foreground",
							children: guestProfile.preferences.join(" · ") || guestProfile.notes
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-3 rounded-xl border border-border p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
								children: "FNRH · ficha do hóspede"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-3 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "fnrh-doc",
											children: "Documento"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "fnrh-doc",
											value: fnrhDoc,
											onChange: (event) => setFnrhDoc(event.target.value),
											placeholder: "CPF ou passaporte"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "fnrh-birth",
											children: "Nascimento"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "fnrh-birth",
											type: "date",
											value: fnrhBirth,
											onChange: (event) => setFnrhBirth(event.target.value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "fnrh-nation",
											children: "Nacionalidade"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "fnrh-nation",
											value: fnrhNation,
											onChange: (event) => setFnrhNation(event.target.value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "fnrh-job",
											children: "Profissão"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "fnrh-job",
											value: fnrhJob,
											onChange: (event) => setFnrhJob(event.target.value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "fnrh-from",
											children: "Procedência"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "fnrh-from",
											value: fnrhFrom,
											onChange: (event) => setFnrhFrom(event.target.value),
											placeholder: "Cidade"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: "fnrh-to",
											children: "Próximo destino"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: "fnrh-to",
											value: fnrhTo,
											onChange: (event) => setFnrhTo(event.target.value),
											placeholder: "Cidade"
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Documento e nascimento são obrigatórios para o check-in."
							})
						]
					}),
					isPreReservation ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-3 rounded-xl bg-status-pending/10 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-status-pending",
								children: "Pré-reserva aguardando confirmação da recepção"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: reservation.notes ?? "Confirme para ocupar o quarto."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: notesSayPayAtCheckIn(reservation.notes) ? "Pagamento no check-in — confirmar não lança sinal." : "Confirme o comprovante para lançar o sinal e ocupar o quarto."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-2 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									className: "bg-status-checkout text-status-checkout-fg hover:opacity-90",
									disabled: patch.isPending || folio.addPayment.isPending,
									onClick: () => void confirmPreReservation(),
									children: "Confirmar reserva"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "destructive",
									disabled: patch.isPending,
									onClick: () => void applyStatus("cancelada"),
									children: "Recusar / Cancelar pré-reserva"
								})]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Um clique"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 gap-2 sm:grid-cols-3",
						children: ACTIONS.map((action) => {
							const Icon = action.icon;
							const active = displayStatus === action.status;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: patch.isPending,
								onClick: () => applyStatus(action.status),
								className: cn("flex min-h-11 flex-col items-start gap-1 rounded-lg px-3 py-3 text-left transition-colors duration-150", action.variant === "default" && "bg-primary text-primary-foreground hover:bg-primary/90", action.variant === "secondary" && "bg-status-checkout text-status-checkout-fg hover:opacity-90", action.variant === "destructive" && "bg-destructive text-destructive-foreground hover:bg-destructive/90", active && "ring-2 ring-ring ring-offset-2 ring-offset-card"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 text-sm font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-4",
										strokeWidth: 1.75
									}), action.label]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs opacity-80",
									children: action.hint
								})]
							}, action.status);
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "actual-check-in",
									children: "Horário real de entrada"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "actual-check-in",
										type: "datetime-local",
										className: "pl-10",
										value: checkInAt,
										onChange: (event) => setCheckInAt(event.target.value)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "actual-check-out",
									children: "Horário real de saída"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "actual-check-out",
										type: "datetime-local",
										className: "pl-10",
										value: checkOutAt,
										onChange: (event) => setCheckOutAt(event.target.value)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "reception-notes",
									children: "Observações da recepção"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "reception-notes",
									placeholder: "Ex.: documento conferido, late check-out autorizado…",
									value: notes,
									onChange: (event) => setNotes(event.target.value)
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Os horários e as notas são gravados junto com o status. O mapa muda de cor na hora."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						disabled: patch.isPending,
						onClick: () => applyStatus(reservation.status),
						children: "Salvar horários e notas"
					})
				]
			}) : tab === "voucher" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StayVoucher, {
				reservation,
				roomLabel: room ? `Quarto ${room.number} · ${room.type}` : reservation.roomId,
				hotelName: property.name,
				address: property.address,
				phone: property.phone,
				checkInTime: bookingConfig.checkInTime,
				checkOutTime: bookingConfig.checkOutTime,
				cancellationPolicy: bookingConfig.cancellationPolicy,
				totais: folio.totais
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReservationFolio, {
				reservationId: reservation.id,
				onRegisterPayment: () => setPaymentOpen(true)
			})]
		})] }) : null
	}), reservation ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReservationPaymentModal, {
		reservationId: reservation.id,
		guestName: reservation.guestName,
		open: paymentOpen,
		onOpenChange: setPaymentOpen,
		onSettled: async (saldo) => {
			if (checkoutPending && saldo <= 0) try {
				await completeCheckout();
			} catch (error) {
				toast.error(error instanceof Error ? error.message : "Pagamento ok, mas o check-out falhou.");
			}
		}
	}) : null] });
}
/**
* Ficha do bloqueio: criar ou remover.
* Pode: quarto, datas, motivo curto, apagar.
* Proibido: hóspede, folio, Pix, check-in.
* Grava: blockStore.
*/
function BlockRoomModal({ open, onOpenChange, draft, existing }) {
	const { data: rooms = [] } = useRooms();
	const { data: reservations = [] } = useReservations();
	const { data: blocks = [] } = useBlocks();
	const create = useCreateBlock();
	const remove = useRemoveBlock();
	const [roomId, setRoomId] = (0, import_react.useState)(draft?.roomId ?? rooms[0]?.id ?? "");
	const [checkIn, setCheckIn] = (0, import_react.useState)(draft?.checkIn ?? TODAY_ISO);
	const [checkOut, setCheckOut] = (0, import_react.useState)(draft?.checkOut ?? toISODate(addDays(parseISODate(TODAY_ISO), 1)));
	const [reason, setReason] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!open) return;
		if (existing) {
			setRoomId(existing.roomId);
			setCheckIn(existing.checkIn);
			setCheckOut(existing.checkOut);
			setReason(existing.reason);
			return;
		}
		setRoomId(draft?.roomId ?? rooms[0]?.id ?? "");
		setCheckIn(draft?.checkIn ?? TODAY_ISO);
		setCheckOut(draft?.checkOut ?? toISODate(addDays(parseISODate(TODAY_ISO), 1)));
		setReason("");
	}, [
		open,
		existing,
		draft,
		rooms
	]);
	const stayHits = (0, import_react.useMemo)(() => findConflicts(reservations, roomId, checkIn, checkOut), [
		reservations,
		roomId,
		checkIn,
		checkOut
	]);
	const blockHits = (0, import_react.useMemo)(() => findBlockConflicts(blocks, roomId, checkIn, checkOut, existing?.id), [
		blocks,
		roomId,
		checkIn,
		checkOut,
		existing?.id
	]);
	const busy = stayHits.length > 0 || blockHits.length > 0;
	async function onSubmit(event) {
		event.preventDefault();
		if (existing) return;
		if (busy) {
			toast.error("Este quarto já está ocupado ou bloqueado neste período.");
			return;
		}
		try {
			await create.mutateAsync({
				roomId,
				checkIn,
				checkOut,
				reason
			});
			toast.success("Quarto bloqueado no mapa e no site.");
			onOpenChange(false);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível bloquear.");
		}
	}
	async function onRemove() {
		if (!existing) return;
		try {
			await remove.mutateAsync(existing.id);
			toast.success("Bloqueio removido. A vaga voltou a vender.");
			onOpenChange(false);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível remover.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(OnMapDialog, {
		open,
		onOpenChange,
		className: "max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-display text-xl font-medium tracking-tight",
				children: existing ? "Bloqueio de quarto" : "Bloquear quarto"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Não cria reserva, hóspede nem conta. Só tira a vaga da venda."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
				className: "absolute top-4 right-4 rounded-md p-1 text-muted-foreground hover:text-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-5 flex flex-col gap-4",
				onSubmit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "block-room",
							children: "Quarto"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "block-room",
							className: "h-10 rounded-md border border-input bg-background px-3 text-sm",
							value: roomId,
							disabled: Boolean(existing),
							onChange: (event) => setRoomId(event.target.value),
							children: rooms.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: room.id,
								children: [
									room.number,
									" · ",
									room.type
								]
							}, room.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "block-in",
								children: "Início"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "block-in",
								type: "date",
								value: checkIn,
								disabled: Boolean(existing),
								onChange: (event) => setCheckIn(event.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "block-out",
								children: "Fim"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "block-out",
								type: "date",
								value: checkOut,
								disabled: Boolean(existing),
								onChange: (event) => setCheckOut(event.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "block-reason",
							children: "Motivo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "block-reason",
							maxLength: 80,
							value: reason,
							disabled: Boolean(existing),
							placeholder: "Manutenção, evento, uso da casa…",
							onChange: (event) => setReason(event.target.value)
						})]
					}),
					busy && !existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-destructive",
						children: "Período cruzado com reserva ou outro bloqueio."
					}) : null,
					existing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "destructive",
						onClick: () => void onRemove(),
						children: "Remover bloqueio"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: create.isPending || busy,
						children: "Bloquear vaga"
					})
				]
			})
		]
	});
}
/**
* Fecha venda por tipo e datas. Lista os fechamentos para reabrir.
* Pode: tipo, período, motivo, clicar na lista e liberar.
* Proibido: preço, reserva, folio.
* Grava: saleCloseStore.
*/
var TYPES = [
	"todas",
	"Standard",
	"Luxo",
	"Suíte"
];
function typeLabel(value) {
	return value === "todas" ? "Todos os tipos" : value;
}
function CloseSaleModal({ open, onOpenChange, existing }) {
	const { data: closes = [] } = useSaleCloses();
	const create = useCreateSaleClose();
	const remove = useRemoveSaleClose();
	const [roomType, setRoomType] = (0, import_react.useState)("todas");
	const [checkIn, setCheckIn] = (0, import_react.useState)(TODAY_ISO);
	const [checkOut, setCheckOut] = (0, import_react.useState)(toISODate(addDays(parseISODate(TODAY_ISO), 1)));
	const [reason, setReason] = (0, import_react.useState)("");
	const rows = [...closes].sort((a, b) => a.checkIn.localeCompare(b.checkIn) || a.roomType.localeCompare(b.roomType));
	(0, import_react.useEffect)(() => {
		if (!open) return;
		if (existing) {
			setRoomType(existing.roomType);
			setCheckIn(existing.checkIn);
			setCheckOut(existing.checkOut);
			setReason(existing.reason);
			return;
		}
		setRoomType("todas");
		setCheckIn(TODAY_ISO);
		setCheckOut(toISODate(addDays(parseISODate(TODAY_ISO), 1)));
		setReason("");
	}, [open, existing]);
	function resetForm() {
		setRoomType("todas");
		setCheckIn(TODAY_ISO);
		setCheckOut(toISODate(addDays(parseISODate(TODAY_ISO), 1)));
		setReason("");
	}
	async function onSubmit(event) {
		event.preventDefault();
		try {
			await create.mutateAsync({
				roomType,
				checkIn,
				checkOut,
				reason
			});
			toast.success("Venda fechada neste tipo e período.");
			resetForm();
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível fechar a venda.");
		}
	}
	async function onRelease(id) {
		try {
			await remove.mutateAsync(id);
			toast.success("Venda reaberta neste período.");
			if (existing?.id === id) resetForm();
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível reabrir.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(OnMapDialog, {
		open,
		onOpenChange,
		className: "max-w-md p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-xl font-medium",
					children: "Fechar venda"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Fecha o tipo no mapa e no site. Clique na lista para liberar."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
					className: "rounded-md p-1 text-muted-foreground hover:bg-secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "close-type",
							children: "Tipo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "close-type",
							className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
							value: roomType,
							onChange: (event) => setRoomType(event.target.value),
							children: TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: type,
								children: typeLabel(type)
							}, type))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "close-in",
								children: "De"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "close-in",
								type: "date",
								value: checkIn,
								onChange: (event) => setCheckIn(event.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "close-out",
								children: "Até (saída)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "close-out",
								type: "date",
								value: checkOut,
								onChange: (event) => setCheckOut(event.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "close-reason",
							children: "Motivo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "close-reason",
							maxLength: 80,
							value: reason,
							onChange: (event) => setReason(event.target.value),
							placeholder: "Manutenção da categoria, evento…"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: create.isPending,
						children: "Fechar venda"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 border-t border-border pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Datas fechadas"
				}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Nenhuma venda fechada."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 grid max-h-40 gap-1 overflow-y-auto",
					children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center justify-between gap-2 rounded-md px-2 py-1.5 text-left text-sm hover:bg-secondary",
						onClick: () => void onRelease(row.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							typeLabel(row.roomType),
							" · ",
							row.checkIn,
							" → ",
							row.checkOut,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-muted-foreground",
								children: row.reason
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-xs font-medium text-destructive",
							children: "Liberar"
						})]
					}) }, row.id))
				})]
			})
		]
	});
}
var DRAG_THRESHOLD = 8;
function useDragScroll(options) {
	const ref = (0, import_react.useRef)(null);
	const lockInteractive = options?.lockInteractive ?? true;
	(0, import_react.useEffect)(() => {
		const node = ref.current;
		if (!node) return;
		const scroller = node;
		let pending = false;
		let dragging = false;
		let moved = false;
		let startX = 0;
		let startY = 0;
		let scrollLeft = 0;
		let scrollTop = 0;
		let pointerId = null;
		function onDown(event) {
			if (event.pointerType === "mouse" && event.button !== 0) return;
			if (lockInteractive && event.target.closest("button, a, select, input, textarea, [role='button']")) return;
			pending = true;
			dragging = false;
			moved = false;
			pointerId = event.pointerId;
			scroller.dataset.dragged = "0";
			startX = event.clientX;
			startY = event.clientY;
			scrollLeft = scroller.scrollLeft;
			scrollTop = scroller.scrollTop;
		}
		function onMove(event) {
			if (!pending && !dragging) return;
			if (pointerId !== null && event.pointerId !== pointerId) return;
			const dx = event.clientX - startX;
			const dy = event.clientY - startY;
			if (!dragging) {
				if (Math.abs(dx) + Math.abs(dy) < DRAG_THRESHOLD) return;
				dragging = true;
				moved = true;
				scroller.dataset.dragged = "1";
				try {
					scroller.setPointerCapture(event.pointerId);
				} catch {}
				scroller.style.cursor = "grabbing";
				scroller.style.userSelect = "none";
			}
			scroller.scrollLeft = scrollLeft - dx;
			scroller.scrollTop = scrollTop - dy;
			event.preventDefault();
		}
		function onUp(event) {
			if (pointerId !== null && event.pointerId !== pointerId) return;
			pending = false;
			if (dragging) {
				dragging = false;
				scroller.style.cursor = "";
				scroller.style.userSelect = "";
				try {
					if (scroller.hasPointerCapture(event.pointerId)) scroller.releasePointerCapture(event.pointerId);
				} catch {}
			}
			scroller.dataset.dragged = moved ? "1" : "0";
			pointerId = null;
		}
		scroller.addEventListener("pointerdown", onDown);
		scroller.addEventListener("pointermove", onMove, { passive: false });
		scroller.addEventListener("pointerup", onUp);
		scroller.addEventListener("pointercancel", onUp);
		return () => {
			scroller.removeEventListener("pointerdown", onDown);
			scroller.removeEventListener("pointermove", onMove);
			scroller.removeEventListener("pointerup", onUp);
			scroller.removeEventListener("pointercancel", onUp);
		};
	}, [lockInteractive]);
	return { ref };
}
function clampIndex(value, min, max) {
	return Math.min(max, Math.max(min, value));
}
function barPlacement(span, start, days) {
	const startOffset = differenceInCalendarDays(parseISODate(span.checkIn), start);
	const nights = stayNights(span.checkIn, span.checkOut);
	const colStart = clampIndex(startOffset, 0, days);
	const colEnd = clampIndex(startOffset + nights, 0, days);
	return {
		colStart,
		colEnd,
		hidden: colEnd <= colStart
	};
}
function visibleOnMap(row) {
	return row.status !== "cancelada" && Boolean(row.guestName?.trim());
}
function assignLanes(items) {
	const sorted = [...items].sort((a, b) => a.checkIn.localeCompare(b.checkIn) || a.checkOut.localeCompare(b.checkOut) || a.id.localeCompare(b.id));
	const until = [];
	const laneOf = /* @__PURE__ */ new Map();
	for (const row of sorted) {
		let lane = until.findIndex((end) => end <= row.checkIn);
		if (lane < 0) {
			lane = until.length;
			until.push(row.checkOut);
		} else until[lane] = row.checkOut;
		laneOf.set(row.id, lane);
	}
	return {
		laneOf,
		laneCount: Math.max(1, until.length)
	};
}
function rowTrack(laneCount) {
	return `calc(var(--timeline-row-pad) * 2 + ${Math.max(1, laneCount)} * var(--timeline-lane))`;
}
function canDragStay(row) {
	return row.status === "pendente" || row.status === "confirmada" || row.status === "check-in";
}
function hitMapCell(clientX, clientY) {
	const cells = document.querySelectorAll("[data-map-cell]");
	for (const cell of cells) {
		const box = cell.getBoundingClientRect();
		if (clientX >= box.left && clientX < box.right && clientY >= box.top && clientY < box.bottom) return {
			roomId: cell.dataset.roomId ?? "",
			date: cell.dataset.date ?? ""
		};
	}
	return null;
}
function Timeline({ start, reservations, blocks, saleCloses = [], rooms, onSelect, onSelectBlock, onSelectClose, onEmptyCell, onMoveStay, selectedId = null, selectedBlockId = null }) {
	const days = Array.from({ length: 21 }, (_, i) => addDays(start, i));
	const rangeEnd = addDays(start, 21);
	const items = getReservationsOverlapping(start, rangeEnd, reservations).filter(visibleOnMap);
	const visibleBlocks = blocks.filter((row) => row.checkIn < format(rangeEnd, "yyyy-MM-dd") && row.checkOut > format(start, "yyyy-MM-dd"));
	const overbooked = findOverbookedIds(reservations);
	const { ref } = useDragScroll({ lockInteractive: true });
	const skipClick = (0, import_react.useRef)(false);
	const [ghost, setGhost] = (0, import_react.useState)(null);
	const layouts = rooms.map((room) => {
		const roomItems = items.filter((item) => item.roomId === room.id);
		const roomBlocks = visibleBlocks.filter((item) => item.roomId === room.id);
		return {
			room,
			roomItems,
			roomBlocks,
			...assignLanes([...roomItems, ...roomBlocks])
		};
	});
	(0, import_react.useEffect)(() => {
		if (!selectedId && !selectedBlockId) return;
		const root = ref.current;
		if (!root) return;
		const target = selectedBlockId ?? selectedId;
		if (!target) return;
		const escaped = typeof CSS !== "undefined" && typeof CSS.escape === "function" ? CSS.escape(target) : target.replace(/"/g, "");
		root.querySelector(`[data-stay-id="${escaped}"]`)?.scrollIntoView({
			block: "nearest",
			inline: "center",
			behavior: "smooth"
		});
	}, [
		selectedId,
		selectedBlockId,
		start
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "timeline-map min-w-0 overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			className: "timeline-scroll max-h-(--timeline-max-h) cursor-grab overflow-auto overscroll-x-contain",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative grid",
				style: {
					gridTemplateColumns: `var(--timeline-sidebar) repeat(21, var(--timeline-day))`,
					gridTemplateRows: `var(--timeline-head) ${layouts.map((row) => rowTrack(row.laneCount)).join(" ")}`,
					width: `calc(var(--timeline-sidebar) + 21 * var(--timeline-day))`
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sticky top-0 left-0 z-30 flex h-(--timeline-head) items-end bg-card px-3 py-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Quarto"
					}),
					days.map((day, index) => {
						const today = isSameDay(day, TODAY);
						const weekend = isWeekend(day);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn("sticky top-0 z-20 flex h-(--timeline-head) flex-col items-center justify-center border-l border-border bg-card", weekend && "bg-weekend", today && "bg-today"),
							style: {
								gridColumn: index + 2,
								gridRow: 1
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
								children: format(day, "EEE", { locale: ptBR }).replace(".", "")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mt-0.5 flex size-7 items-center justify-center rounded-full text-sm font-medium tabular-nums", today && "bg-primary text-primary-foreground"),
								children: format(day, "d")
							})]
						}, toKey(day));
					}),
					layouts.map((layout, roomIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sticky left-0 z-20 flex h-full min-h-0 flex-col justify-center gap-0.5 overflow-hidden border-t border-border bg-card px-2.5",
						style: {
							gridColumn: 1,
							gridRow: roomIndex + 2
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("size-2 shrink-0 rounded-full", HOUSEKEEPING_DOT[layout.room.housekeepingStatus]),
									title: HOUSEKEEPING_LABEL[layout.room.housekeepingStatus]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium tabular-nums",
									children: layout.room.number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden truncate text-xs text-muted-foreground sm:inline",
									children: layout.room.type
								})
							]
						})
					}, layout.room.id)),
					layouts.map((layout, roomIndex) => days.map((day, dayIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("min-h-0 border-t border-l border-border", isWeekend(day) && "bg-weekend/70", isSameDay(day, TODAY) && "bg-today/80", Boolean(saleCloseOnNight(saleCloses, layout.room.type, toKey(day))) && "timeline-closed-cell"),
						"data-map-cell": "",
						"data-room-id": layout.room.id,
						"data-date": toKey(day),
						style: {
							gridColumn: dayIndex + 2,
							gridRow: roomIndex + 2
						},
						onClick: () => {
							if (ref.current?.dataset.dragged === "1") return;
							const iso = toKey(day);
							const closed = saleCloseOnNight(saleCloses, layout.room.type, iso);
							if (closed) {
								onSelectClose?.(closed);
								return;
							}
							onEmptyCell(layout.room.id, iso);
						}
					}, `${layout.room.id}-${toKey(day)}`))),
					layouts.map((layout, roomIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 overflow-hidden pointer-events-none",
						style: {
							gridColumn: `2 / 23`,
							gridRow: roomIndex + 2
						},
						children: [layout.roomBlocks.map((block) => {
							const { colStart, colEnd, hidden } = barPlacement(block, start, 21);
							if (hidden) return null;
							const span = colEnd - colStart;
							const lane = layout.laneOf.get(block.id) ?? 0;
							const selected = selectedBlockId === block.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"data-stay-id": block.id,
								"aria-current": selected ? "true" : void 0,
								className: cn("timeline-block-bar pointer-events-auto absolute flex items-center overflow-hidden rounded-md px-2 text-left text-xs font-medium shadow-sm", selected && "ring-2 ring-primary ring-offset-1 ring-offset-card"),
								style: {
									left: `calc(${colStart} * var(--timeline-day) + 2px)`,
									width: `calc(${span} * var(--timeline-day) - 4px)`,
									top: `calc(var(--timeline-row-pad) + ${lane} * var(--timeline-lane))`,
									height: "calc(var(--timeline-lane) - 6px)",
									zIndex: selected ? 4 : 3
								},
								title: `Bloqueado · ${block.reason}`,
								onPointerDown: (event) => event.stopPropagation(),
								onClick: (event) => {
									event.stopPropagation();
									onSelectBlock(block);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block truncate",
									children: ["Bloqueado · ", block.reason]
								})
							}, block.id);
						}), layout.roomItems.map((reservation) => {
							const { colStart, colEnd, hidden } = barPlacement(reservation, start, 21);
							if (hidden) return null;
							const conflict = overbooked.has(reservation.id);
							const span = colEnd - colStart;
							const lane = layout.laneOf.get(reservation.id) ?? 0;
							const selected = selectedId === reservation.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"data-stay-id": reservation.id,
								"aria-current": selected ? "true" : void 0,
								onPointerDown: (event) => {
									event.stopPropagation();
									if (!onMoveStay || !canDragStay(reservation)) return;
									try {
										event.currentTarget.setPointerCapture(event.pointerId);
									} catch {}
									const originX = event.clientX;
									const originY = event.clientY;
									const name = reservation.guestName;
									const pointerId = event.pointerId;
									let moved = false;
									function onMove(move) {
										if (move.pointerId !== pointerId) return;
										if (!moved && Math.abs(move.clientX - originX) + Math.abs(move.clientY - originY) < 8) return;
										moved = true;
										skipClick.current = true;
										setGhost({
											name,
											x: move.clientX,
											y: move.clientY
										});
									}
									function onUp(up) {
										if (up.pointerId !== pointerId) return;
										window.removeEventListener("pointermove", onMove);
										window.removeEventListener("pointerup", onUp);
										window.removeEventListener("pointercancel", onUp);
										setGhost(null);
										if (!moved || !onMoveStay) return;
										const hit = hitMapCell(up.clientX, up.clientY);
										if (!hit?.roomId || !hit.date) return;
										if (hit.roomId === reservation.roomId && hit.date === reservation.checkIn) return;
										onMoveStay(reservation, hit.roomId, hit.date);
									}
									window.addEventListener("pointermove", onMove);
									window.addEventListener("pointerup", onUp);
									window.addEventListener("pointercancel", onUp);
								},
								onClick: (event) => {
									event.stopPropagation();
									if (skipClick.current) {
										skipClick.current = false;
										return;
									}
									onSelect(reservation);
								},
								className: cn("pointer-events-auto absolute flex items-center overflow-hidden rounded-md px-2 text-left text-xs font-medium shadow-sm", canDragStay(reservation) && "cursor-grab", STATUS_BAR[reservation.status], conflict && "ring-1 ring-destructive", selected && "ring-2 ring-primary ring-offset-1 ring-offset-card"),
								style: {
									left: `calc(${colStart} * var(--timeline-day) + 2px)`,
									width: `calc(${span} * var(--timeline-day) - 4px)`,
									top: `calc(var(--timeline-row-pad) + ${lane} * var(--timeline-lane))`,
									height: "calc(var(--timeline-lane) - 6px)",
									zIndex: selected ? 4 : reservation.status === "check-out" ? 1 : 2
								},
								title: conflict ? `CONFLITO / OVERBOOKING · ${reservation.guestName}` : `${reservation.guestName} · ${STATUS_LABEL[reservation.status]}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block truncate",
									children: [conflict ? "! " : "", reservation.guestName]
								})
							}, reservation.id);
						})]
					}, `${layout.room.id}-bars`))
				]
			})
		}), ghost ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pointer-events-none fixed z-50 rounded-md bg-primary px-2 py-1 text-xs font-medium text-primary-foreground shadow-[var(--shadow-border)]",
			style: {
				left: ghost.x + 8,
				top: ghost.y + 8
			},
			children: ghost.name
		}) : null]
	});
}
function toKey(day) {
	return format(day, "yyyy-MM-dd");
}
var calendarioRoute = getRouteApi("/calendario");
var LEGEND = [
	"pendente",
	"confirmada",
	"check-in",
	"check-out",
	"cancelada"
];
var LEGEND_DOT = {
	pendente: "bg-status-pending",
	confirmada: "bg-status-confirmed",
	"check-in": "bg-status-checkin",
	"check-out": "bg-status-checkout",
	cancelada: "bg-status-cancelled"
};
function CalendarPage() {
	const { reserva: reservaSearch } = calendarioRoute.useSearch();
	const [start, setStart] = (0, import_react.useState)(() => addDays(TODAY, -3));
	const [selectedId, setSelectedId] = (0, import_react.useState)(reservaSearch ?? null);
	const [selectedBlockId, setSelectedBlockId] = (0, import_react.useState)(null);
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const [createDraft, setCreateDraft] = (0, import_react.useState)(null);
	const [blockOpen, setBlockOpen] = (0, import_react.useState)(false);
	const [blockDraft, setBlockDraft] = (0, import_react.useState)(null);
	const [closeOpen, setCloseOpen] = (0, import_react.useState)(false);
	const [selectedCloseId, setSelectedCloseId] = (0, import_react.useState)(null);
	const { data: reservations = [] } = useReservations();
	const { data: rooms = [] } = useRooms();
	const { data: blocks = [] } = useBlocks();
	const { data: saleCloses = [] } = useSaleCloses();
	const patchStay = usePatchReservation();
	(0, import_react.useEffect)(() => {
		if (!reservaSearch) return;
		setSelectedId(reservaSearch);
		setSelectedBlockId(null);
		const reservation = reservations.find((row) => row.id === reservaSearch);
		if (reservation) setStart(addDays(parseISODate(reservation.checkIn), -1));
	}, [reservaSearch, reservations]);
	const selected = (0, import_react.useMemo)(() => reservations.find((row) => row.id === selectedId) ?? null, [reservations, selectedId]);
	const selectedBlock = (0, import_react.useMemo)(() => blocks.find((row) => row.id === selectedBlockId) ?? null, [blocks, selectedBlockId]);
	const selectedClose = (0, import_react.useMemo)(() => saleCloses.find((row) => row.id === selectedCloseId) ?? null, [saleCloses, selectedCloseId]);
	function focusStay(row) {
		setSelectedBlockId(null);
		setSelectedCloseId(null);
		setSelectedId(row.id);
		setStart(addDays(parseISODate(row.checkIn), -1));
	}
	function focusBlock(row) {
		setSelectedId(null);
		setSelectedCloseId(null);
		setSelectedBlockId(row.id);
		setBlockDraft(null);
		setBlockOpen(true);
	}
	function openNewStay(draft) {
		setSelectedId(null);
		setSelectedBlockId(null);
		setSelectedCloseId(null);
		setCreateDraft(draft ?? null);
		setCreateOpen(true);
	}
	function openNewBlock(draft) {
		setSelectedId(null);
		setSelectedBlockId(null);
		setSelectedCloseId(null);
		setBlockDraft(draft ?? null);
		setBlockOpen(true);
	}
	function focusClose(row) {
		setSelectedId(null);
		setSelectedBlockId(null);
		setSelectedCloseId(row.id);
		setCloseOpen(true);
	}
	async function moveStay(row, roomId, checkIn) {
		const checkOut = toISODate(addDays(parseISODate(checkIn), stayNights(row.checkIn, row.checkOut)));
		try {
			await patchStay.mutateAsync({
				id: row.id,
				roomId,
				checkIn,
				checkOut
			});
			toast.success(`${row.guestName} movido`);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível mover a reserva.");
		}
	}
	const rangeLabel = (0, import_react.useMemo)(() => {
		const end = addDays(start, 20);
		return `${format(start, "d MMM", { locale: ptBR })} – ${format(end, "d MMM yyyy", { locale: ptBR })}`;
	}, [start]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-[calc(100dvh-4rem)] flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-medium tracking-tight",
					children: "Mapa de reservas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground capitalize",
					children: rangeLabel
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => openNewStay(),
							children: "Nova reserva"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => openNewBlock(),
							children: "Bloquear quarto"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => {
								setSelectedCloseId(null);
								setCloseOpen(true);
							},
							children: "Fechar venda"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							"aria-label": "Semana anterior",
							onClick: () => setStart((current) => addDays(current, -7)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => setStart(addDays(TODAY, -3)),
							children: "Hoje"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "icon",
							"aria-label": "Próxima semana",
							onClick: () => setStart((current) => addDays(current, 7)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingBookingsAlert, {
				map: true,
				onSelect: focusStay
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground",
					children: [
						LEGEND.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "inline-flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2.5 rounded-full ${LEGEND_DOT[status]}` }), STATUS_LABEL[status]]
						}, status)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "inline-flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "timeline-block-swatch size-2.5 rounded-full" }), "Bloqueado"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "inline-flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "timeline-closed-swatch size-2.5 rounded-full border border-border" }), "Venda fechada"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground",
					children: HOUSEKEEPING_ORDER.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2.5 rounded-full ${HOUSEKEEPING_DOT[status]}` }), HOUSEKEEPING_LABEL[status]]
					}, status))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timeline, {
				start,
				reservations,
				blocks,
				saleCloses,
				rooms,
				selectedId,
				selectedBlockId,
				onSelect: focusStay,
				onSelectBlock: focusBlock,
				onSelectClose: focusClose,
				onMoveStay: moveStay,
				onEmptyCell: (roomId, date) => openNewStay({
					roomId,
					checkIn: date,
					checkOut: toISODate(addDays(parseISODate(date), 1))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Clique abre o pop-up. Arraste a faixa para outra data ou quarto. Célula vazia cria reserva. Hachura = venda fechada."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateReservationModal, {
				open: createOpen,
				onOpenChange: (open) => {
					setCreateOpen(open);
					if (!open) setCreateDraft(null);
				},
				draft: createDraft
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlockRoomModal, {
				open: blockOpen,
				onOpenChange: (open) => {
					setBlockOpen(open);
					if (!open) {
						setSelectedBlockId(null);
						setBlockDraft(null);
					}
				},
				draft: blockDraft,
				existing: selectedBlock
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseSaleModal, {
				open: closeOpen,
				onOpenChange: (open) => {
					setCloseOpen(open);
					if (!open) setSelectedCloseId(null);
				},
				existing: selectedClose
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckInModal, {
				reservation: selected,
				onOpenChange: (open) => {
					if (!open) setSelectedId(null);
				}
			})
		]
	});
}
var SplitComponent = CalendarPage;
//#endregion
export { SplitComponent as component };
