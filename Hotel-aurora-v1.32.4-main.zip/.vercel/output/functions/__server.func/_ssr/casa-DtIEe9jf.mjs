import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as HOUSEKEEPING_LABEL, i as HOUSEKEEPING_DOT, it as saleCloseOnNight, l as TODAY_ISO, o as HOUSEKEEPING_ORDER } from "./bookingStore-Bq0ubAXy.mjs";
import { S as ChevronRight, _ as House, m as Mail, t as X, w as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Pt as cn, i as Label, o as Button } from "./router-D2QglEY4.mjs";
import { t as Textarea } from "./textarea-CJRv6rNU.mjs";
import { a as useReservations } from "./useReservations-BEok-WZp.mjs";
import { i as useSetRoomNote, r as useRooms } from "./useRooms-DVLudIq6.mjs";
import { t as useBlocks } from "./useBlocks-Dt0MBuAT.mjs";
import { r as useSaleCloses } from "./useSaleCloses-BDBCA2UD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/casa-DtIEe9jf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Tela Casa: situação do hotel agora.
* Pode: casinha, cor, visto, seta entra/sai, recado curto, bolinha de limpeza.
* Proibido: mudar limpeza, folio, coração/bolo (depois).
* Lê: roomStore + reservas/bloqueios/fechamentos. Recado: frontDeskNote no cofre.
*/
var TONE_HOUSE = {
	livre: "text-muted-foreground",
	ocupado: "text-status-checkin",
	pendente: "text-status-pending",
	indisponivel: "text-destructive"
};
var TONE_CARD = {
	livre: "bg-card",
	ocupado: "bg-status-checkin/10",
	pendente: "bg-status-pending/10",
	indisponivel: "bg-destructive/10"
};
var TONE_LABEL = {
	livre: "Livre",
	ocupado: "Ocupado",
	pendente: "Pré-reserva",
	indisponivel: "Indisponível"
};
function stayTonight(roomId, reservations, today) {
	return reservations.find((row) => row.roomId === roomId && row.status !== "cancelada" && row.status !== "check-out" && row.checkIn <= today && row.checkOut > today);
}
function stayMoves(roomId, reservations, today) {
	const rows = reservations.filter((row) => row.roomId === roomId && row.status !== "cancelada");
	return {
		arriving: rows.some((row) => row.checkIn === today && row.status !== "check-out"),
		leaving: rows.some((row) => row.checkOut === today)
	};
}
function blockTonight(roomId, blocks, today) {
	return blocks.some((row) => row.roomId === roomId && row.checkIn <= today && row.checkOut > today);
}
function toneOf(room, reservations, blocks, saleCloses, today) {
	const stay = stayTonight(room.id, reservations, today);
	if (stay) {
		if (stay.status === "pendente") return {
			tone: "pendente",
			confirmed: false
		};
		return {
			tone: "ocupado",
			confirmed: true
		};
	}
	if (room.housekeepingStatus === "manutencao" || blockTonight(room.id, blocks, today) || Boolean(saleCloseOnNight(saleCloses, room.type, today))) return {
		tone: "indisponivel",
		confirmed: false
	};
	return {
		tone: "livre",
		confirmed: false
	};
}
function HouseMapView() {
	const { data: rooms = [] } = useRooms();
	const { data: reservations = [] } = useReservations();
	const { data: blocks = [] } = useBlocks();
	const { data: saleCloses = [] } = useSaleCloses();
	const setNote = useSetRoomNote();
	const [noteRoomId, setNoteRoomId] = (0, import_react.useState)(null);
	const [noteDraft, setNoteDraft] = (0, import_react.useState)("");
	const sorted = [...rooms].sort((a, b) => a.number.localeCompare(b.number, "pt", { numeric: true }));
	const noteRoom = rooms.find((row) => row.id === noteRoomId) ?? null;
	(0, import_react.useEffect)(() => {
		if (!noteRoom) return;
		setNoteDraft(noteRoom.frontDeskNote ?? "");
	}, [noteRoom?.id, noteRoom?.frontDeskNote]);
	async function saveNote(event) {
		event.preventDefault();
		if (!noteRoom) return;
		try {
			await setNote.mutateAsync({
				id: noteRoom.id,
				note: noteDraft
			});
			toast.success(noteDraft.trim() ? `Recado no ${noteRoom.number}` : `Recado do ${noteRoom.number} apagado`);
			setNoteRoomId(null);
		} catch {
			toast.error("Não foi possível gravar o recado.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-medium tracking-tight",
				children: "Casa"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Como está cada quarto agora. A camareira controla a limpeza na aba Limpeza."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground",
				children: [
					Object.keys(TONE_LABEL).map((tone) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {
							className: cn("size-3.5", TONE_HOUSE[tone]),
							strokeWidth: 2,
							"aria-hidden": true
						}), TONE_LABEL[tone]]
					}, tone)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-3.5 text-status-checkin",
							strokeWidth: 2.5,
							"aria-hidden": true
						}), "Confirmada"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "inline-flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
								className: "size-3.5",
								strokeWidth: 2.5,
								"aria-hidden": true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {
								className: "size-3.5 text-muted-foreground",
								strokeWidth: 2,
								"aria-hidden": true
							}),
							"Entra hoje"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "inline-flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {
								className: "size-3.5 text-muted-foreground",
								strokeWidth: 2,
								"aria-hidden": true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
								className: "size-3.5",
								strokeWidth: 2.5,
								"aria-hidden": true
							}),
							"Sai hoje"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
							className: "size-3.5",
							strokeWidth: 2,
							"aria-hidden": true
						}), "Recado"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-wrap gap-x-4 gap-y-2 text-xs text-muted-foreground",
				children: HOUSEKEEPING_ORDER.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "inline-flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-full", HOUSEKEEPING_DOT[status]) }), HOUSEKEEPING_LABEL[status]]
				}, status))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5",
				children: sorted.map((room) => {
					const { tone, confirmed } = toneOf(room, reservations, blocks, saleCloses, TODAY_ISO);
					const { arriving, leaving } = stayMoves(room.id, reservations, TODAY_ISO);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: cn("relative flex flex-col items-center gap-2 rounded-xl border border-border px-3 py-4", TONE_CARD[tone]),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("absolute top-2.5 right-2.5 size-2.5 rounded-full", HOUSEKEEPING_DOT[room.housekeepingStatus]),
								title: HOUSEKEEPING_LABEL[room.housekeepingStatus]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("absolute top-1.5 left-1.5 rounded-md p-1", room.frontDeskNote ? "text-foreground" : "text-muted-foreground/50 hover:text-foreground"),
								"aria-label": room.frontDeskNote ? `Recado: ${room.frontDeskNote}` : "Adicionar recado",
								onClick: () => setNoteRoomId(room.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									className: "size-4",
									strokeWidth: room.frontDeskNote ? 2.4 : 1.75
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-0.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
										className: cn("size-5 shrink-0", arriving ? "text-foreground" : "invisible"),
										strokeWidth: 2.5,
										"aria-label": arriving ? "Entra hoje" : void 0
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(House, {
											className: cn("size-10", TONE_HOUSE[tone]),
											strokeWidth: 1.5,
											"aria-hidden": true
										}), confirmed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "absolute -right-1 -bottom-1 size-4 text-status-checkin",
											strokeWidth: 3,
											"aria-label": "Reserva confirmada"
										}) : null]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
										className: cn("size-5 shrink-0", leaving ? "text-foreground" : "invisible"),
										strokeWidth: 2.5,
										"aria-label": leaving ? "Sai hoje" : void 0
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl font-medium leading-none",
								children: room.number
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: room.type
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: TONE_LABEL[tone]
							}),
							room.frontDeskNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "line-clamp-2 text-center text-[11px] text-foreground",
								children: room.frontDeskNote
							}) : null
						]
					}) }, room.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: Boolean(noteRoom),
				onOpenChange: (open) => {
					if (!open) setNoteRoomId(null);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-[60] bg-foreground/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					onOpenAutoFocus: (event) => event.preventDefault(),
					className: "fixed top-1/2 left-1/2 z-[70] w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-card p-5 shadow-lg",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
							className: "font-display text-xl font-medium tracking-tight",
							children: ["Recado · ", noteRoom?.number]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Texto curto para a recepção. Coração e bolo ficam para depois."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
							className: "absolute top-4 right-4 opacity-70 hover:opacity-100",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "sr-only",
								children: "Fechar"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: (event) => void saveNote(event),
							className: "mt-4 grid gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "house-note",
										children: "Recado"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										id: "house-note",
										maxLength: 80,
										value: noteDraft,
										onChange: (event) => setNoteDraft(event.target.value),
										placeholder: "Berço, aniversário, chega tarde…"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: [noteDraft.length, "/80"]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									disabled: setNote.isPending,
									children: "Salvar"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									disabled: setNote.isPending || !noteRoom?.frontDeskNote,
									onClick: () => {
										if (!noteRoom) return;
										setNote.mutateAsync({
											id: noteRoom.id,
											note: ""
										}).then(() => {
											toast.success(`Recado do ${noteRoom.number} apagado`);
											setNoteRoomId(null);
										});
									},
									children: "Apagar"
								})]
							})]
						})
					]
				})] })
			})
		]
	});
}
var SplitComponent = HouseMapView;
//#endregion
export { SplitComponent as component };
