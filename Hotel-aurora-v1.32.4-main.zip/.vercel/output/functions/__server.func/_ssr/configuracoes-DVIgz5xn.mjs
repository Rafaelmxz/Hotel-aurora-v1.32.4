import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { y as addDays } from "../_libs/date-fns.mjs";
import { E as findConflicts, G as parseISODate, T as findBlockConflicts, f as alignCancellationPolicy, l as TODAY_ISO, ut as toISODate } from "./bookingStore-Bq0ubAXy.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Input, dt as occupancyOfType, i as Label, m as useSaveProperty, o as Button, p as useProperty } from "./router-D2QglEY4.mjs";
import { n as listVoucherEmailsFn } from "./api-iTCU0mCO.mjs";
import { t as Textarea } from "./textarea-CJRv6rNU.mjs";
import { a as useReservations } from "./useReservations-BEok-WZp.mjs";
import { r as useRooms } from "./useRooms-DVLudIq6.mjs";
import { n as useSaveRoomTypes, t as useRoomTypes } from "./useRoomTypes-B7WZBIgo.mjs";
import { n as useCreateBlock, r as useRemoveBlock, t as useBlocks } from "./useBlocks-Dt0MBuAT.mjs";
import { n as useRemoveSaleClose, r as useSaleCloses, t as useCreateSaleClose } from "./useSaleCloses-BDBCA2UD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/configuracoes-DVIgz5xn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EmailOutbox() {
	const { data = [], isLoading, refetch, isFetching, isError } = useQuery({
		queryKey: ["hotel-email-outbox"],
		queryFn: () => listVoucherEmailsFn(),
		staleTime: 1e4
	});
	const [openId, setOpenId] = (0, import_react.useState)(null);
	const open = data.find((row) => row.id === openId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "grid gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "E-mails enviados"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Cópia de cada voucher. Se o envio externo não estiver ligado, o recado fica só nesta caixa do hotel."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					disabled: isFetching,
					onClick: () => void refetch(),
					children: "Atualizar"
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Carregando caixa…"
			}) : isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Não foi possível abrir a caixa de e-mails."
			}) : data.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Nenhum voucher enviado ainda."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border",
				children: data.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "py-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "w-full text-left",
						onClick: () => setOpenId(row.id === openId ? null : row.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: row.subject
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								"Para ",
								row.to_email,
								row.delivered ? " · entregue" : " · na caixa do hotel"
							]
						})]
					})
				}, row.id))
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				title: open.subject,
				srcDoc: open.html,
				className: "h-[28rem] w-full rounded-lg border border-border bg-background"
			}) : null
		]
	});
}
function RoomTypeEditor() {
	const { data } = useRoomTypes();
	const save = useSaveRoomTypes();
	const [rows, setRows] = (0, import_react.useState)(data);
	(0, import_react.useEffect)(() => {
		setRows(data);
	}, [data]);
	function patch(type, next) {
		setRows((current) => current.map((row) => row.type === type ? {
			...row,
			...next
		} : row));
	}
	async function onSubmit(event) {
		event.preventDefault();
		try {
			await save.mutateAsync(rows);
			toast.success("Tipos de quarto salvos");
		} catch {
			toast.error("Não foi possível salvar os tipos.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		className: "grid gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl font-medium tracking-tight",
				children: "Tipos de quarto"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Foto, texto, comodidades e ocupação. Vale no site. Não muda o preço."
			})] }),
			rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
				className: "grid gap-3 rounded-lg border border-border p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "px-1 text-sm font-medium",
						children: row.type
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-[8rem_1fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: row.photo,
							alt: "",
							className: "h-24 w-full rounded-md object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Foto (URL)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: row.photo,
								onChange: (event) => patch(row.type, { photo: event.target.value })
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Descrição" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 2,
							value: row.description,
							onChange: (event) => patch(row.type, { description: event.target.value })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Comodidades (uma por linha)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							rows: 3,
							value: row.amenities.join("\n"),
							onChange: (event) => patch(row.type, { amenities: event.target.value.split("\n").map((item) => item.trim()) })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Adultos" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "numeric",
								value: String(row.maxAdults),
								onChange: (event) => patch(row.type, { maxAdults: Number(event.target.value) || 1 })
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Crianças" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "numeric",
								value: String(row.maxChildren),
								onChange: (event) => patch(row.type, { maxChildren: Number(event.target.value) || 0 })
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"Até ",
							occupancyOfType(row),
							" pessoas no tipo."
						]
					})
				]
			}, row.type)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "submit",
				className: "self-start",
				disabled: save.isPending,
				children: "Salvar tipos de quarto"
			})
		]
	});
}
/**
* Cadastro de bloqueio e fechamento de venda na aba Hotel.
* Pode: criar, listar, desbloquear quarto, reabrir venda.
* Proibido: reserva, hóspede, folio, Pix, preço, OTA, Experiências.
* Grava: blockStore e saleCloseStore (cofre).
* Mapa e site só leem o resultado.
*/
var TYPES = [
	"todas",
	"Standard",
	"Luxo",
	"Suíte"
];
function periodLabel(checkIn, checkOut) {
	return `${checkIn} → ${checkOut}`;
}
function InventoryHoldsPanel() {
	const { data: rooms = [] } = useRooms();
	const { data: reservations = [] } = useReservations();
	const { data: blocks = [] } = useBlocks();
	const { data: saleCloses = [] } = useSaleCloses();
	const createBlock = useCreateBlock();
	const removeBlock = useRemoveBlock();
	const createClose = useCreateSaleClose();
	const removeClose = useRemoveSaleClose();
	const [roomId, setRoomId] = (0, import_react.useState)(rooms[0]?.id ?? "");
	const [blockIn, setBlockIn] = (0, import_react.useState)(TODAY_ISO);
	const [blockOut, setBlockOut] = (0, import_react.useState)(toISODate(addDays(parseISODate(TODAY_ISO), 1)));
	const [blockReason, setBlockReason] = (0, import_react.useState)("");
	const [roomType, setRoomType] = (0, import_react.useState)("todas");
	const [closeIn, setCloseIn] = (0, import_react.useState)(TODAY_ISO);
	const [closeOut, setCloseOut] = (0, import_react.useState)(toISODate(addDays(parseISODate(TODAY_ISO), 1)));
	const [closeReason, setCloseReason] = (0, import_react.useState)("");
	const selectedRoomId = roomId || rooms[0]?.id || "";
	const stayHits = (0, import_react.useMemo)(() => findConflicts(reservations, selectedRoomId, blockIn, blockOut), [
		reservations,
		selectedRoomId,
		blockIn,
		blockOut
	]);
	const blockHits = (0, import_react.useMemo)(() => findBlockConflicts(blocks, selectedRoomId, blockIn, blockOut), [
		blocks,
		selectedRoomId,
		blockIn,
		blockOut
	]);
	const blockBusy = stayHits.length > 0 || blockHits.length > 0;
	async function onBlock(event) {
		event.preventDefault();
		if (blockBusy) {
			toast.error("Este quarto já está ocupado ou bloqueado neste período.");
			return;
		}
		try {
			await createBlock.mutateAsync({
				roomId: selectedRoomId,
				checkIn: blockIn,
				checkOut: blockOut,
				reason: blockReason
			});
			setBlockReason("");
			toast.success("Quarto bloqueado. Some no mapa e no site.");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível bloquear.");
		}
	}
	async function onCloseSale(event) {
		event.preventDefault();
		try {
			await createClose.mutateAsync({
				roomType,
				checkIn: closeIn,
				checkOut: closeOut,
				reason: closeReason
			});
			setCloseReason("");
			toast.success("Venda fechada neste tipo e período.");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível fechar a venda.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Bloqueio de quarto"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Tira um quarto da venda. Não cria reserva, hóspede nem conta."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3",
					onSubmit: onBlock,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "hotel-block-room",
								children: "Quarto"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "hotel-block-room",
								className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
								value: selectedRoomId,
								onChange: (event) => setRoomId(event.target.value),
								children: rooms.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: room.id,
									children: [
										room.number,
										" · ",
										room.type
									]
								}, room.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "hotel-block-in",
									children: "De"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "hotel-block-in",
									type: "date",
									value: blockIn,
									onChange: (event) => setBlockIn(event.target.value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "hotel-block-out",
									children: "Até (saída)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "hotel-block-out",
									type: "date",
									value: blockOut,
									onChange: (event) => setBlockOut(event.target.value)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "hotel-block-reason",
								children: "Motivo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "hotel-block-reason",
								maxLength: 80,
								value: blockReason,
								placeholder: "Manutenção, evento, uso da casa…",
								onChange: (event) => setBlockReason(event.target.value)
							})]
						}),
						blockBusy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: "Período cruzado com reserva ou outro bloqueio."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "self-start",
							disabled: createBlock.isPending || blockBusy,
							children: "Bloquear quarto"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: blocks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-muted-foreground",
						children: "Nenhum quarto bloqueado."
					}) : blocks.map((row) => {
						const room = rooms.find((item) => item.id === row.roomId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border px-3 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: room ? `${room.number} · ${room.type}` : row.roomId
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									periodLabel(row.checkIn, row.checkOut),
									" · ",
									row.reason
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								disabled: removeBlock.isPending,
								onClick: () => {
									removeBlock.mutateAsync(row.id).then(() => toast.success("Quarto desbloqueado.")).catch((error) => toast.error(error instanceof Error ? error.message : "Não foi possível desbloquear."));
								},
								children: "Desbloquear"
							})]
						}, row.id);
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Fechar venda por data"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Fecha o tipo no mapa e no site. Não muda preço e não cria reserva."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-3",
					onSubmit: onCloseSale,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "hotel-close-type",
								children: "Tipo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								id: "hotel-close-type",
								className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
								value: roomType,
								onChange: (event) => setRoomType(event.target.value),
								children: TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: type,
									children: type === "todas" ? "Todos os tipos" : type
								}, type))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "hotel-close-in",
									children: "De"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "hotel-close-in",
									type: "date",
									value: closeIn,
									onChange: (event) => setCloseIn(event.target.value)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "hotel-close-out",
									children: "Até (saída)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "hotel-close-out",
									type: "date",
									value: closeOut,
									onChange: (event) => setCloseOut(event.target.value)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "hotel-close-reason",
								children: "Motivo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "hotel-close-reason",
								maxLength: 80,
								value: closeReason,
								placeholder: "Manutenção da categoria, evento…",
								onChange: (event) => setCloseReason(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "self-start",
							disabled: createClose.isPending,
							children: "Fechar venda"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: saleCloses.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-muted-foreground",
						children: "Nenhuma venda fechada."
					}) : saleCloses.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center justify-between gap-2 rounded-lg border border-border px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: row.roomType === "todas" ? "Todos os tipos" : row.roomType
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								periodLabel(row.checkIn, row.checkOut),
								" · ",
								row.reason
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							disabled: removeClose.isPending,
							onClick: () => {
								removeClose.mutateAsync(row.id).then(() => toast.success("Venda reaberta.")).catch((error) => toast.error(error instanceof Error ? error.message : "Não foi possível reabrir."));
							},
							children: "Reabrir venda"
						})]
					}, row.id))
				})
			]
		})]
	});
}
function HotelSettingsView() {
	const { data } = useProperty();
	const save = useSaveProperty();
	const [form, setForm] = (0, import_react.useState)(data);
	(0, import_react.useEffect)(() => {
		setForm(data);
	}, [data]);
	function patch(key, value) {
		setForm((current) => ({
			...current,
			[key]: value
		}));
	}
	async function onSubmit(event) {
		event.preventDefault();
		try {
			await save.mutateAsync(form);
			toast.success("Configurações da propriedade salvas");
		} catch {
			toast.error("Não foi possível salvar.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "flex flex-col gap-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
							children: "Propriedade"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl font-medium tracking-tight",
							children: "Hotel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Dados do hotel, branding e regras operacionais do estabelecimento."
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl font-medium tracking-tight",
								children: "Perfil"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "hotel-name",
									children: "Nome do estabelecimento"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "hotel-name",
									required: true,
									value: form.name,
									onChange: (event) => patch("name", event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "hotel-logo",
									children: "Logo / avatar (URL)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "hotel-logo",
									value: form.logoUrl,
									placeholder: "https://...",
									onChange: (event) => patch("logoUrl", event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "hotel-cnpj",
										children: "CNPJ"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "hotel-cnpj",
										value: form.cnpj,
										onChange: (event) => patch("cnpj", event.target.value)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "hotel-phone",
										children: "Telefone / WhatsApp"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "hotel-phone",
										value: form.phone,
										onChange: (event) => patch("phone", event.target.value)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "hotel-address",
									children: "Endereço completo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "hotel-address",
									value: form.address,
									onChange: (event) => patch("address", event.target.value)
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl font-medium tracking-tight",
								children: "Recebimento"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "pix-key",
										children: "Chave Pix oficial"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "pix-key",
										value: form.pixKey,
										onChange: (event) => patch("pixKey", event.target.value)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "E-mail, CPF, CNPJ, telefone ou chave aleatória. O site monta o QR com essa chave e o valor do sinal."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "pix-payee",
									children: "Favorecido"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "pix-payee",
									value: form.pixPayee,
									onChange: (event) => patch("pixPayee", event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "pix-info",
									children: "Instruções de transferência"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "pix-info",
									value: form.transferInstructions,
									onChange: (event) => patch("transferInstructions", event.target.value)
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl font-medium tracking-tight",
								children: "Horários e cancelamento"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "Vale no site, no voucher e na ficha da reserva. Não muda preço."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "check-in-time",
										children: "Check-in"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "check-in-time",
										type: "time",
										value: form.checkInTime,
										onChange: (event) => patch("checkInTime", event.target.value)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "check-out-time",
										children: "Check-out"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "check-out-time",
										type: "time",
										value: form.checkOutTime,
										onChange: (event) => patch("checkOutTime", event.target.value)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "late",
										children: "Tolerância na saída (minutos)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "late",
										inputMode: "numeric",
										value: String(form.lateCheckoutMinutes),
										onChange: (event) => patch("lateCheckoutMinutes", Number(event.target.value) || 0)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
										htmlFor: "cancel-hours",
										children: "Cancelamento gratuito até (horas antes)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "cancel-hours",
										inputMode: "numeric",
										value: String(form.cancelFreeHours),
										onChange: (event) => {
											const hours = Number(event.target.value) || 0;
											setForm((current) => ({
												...current,
												cancelFreeHours: hours,
												cancellationPolicy: alignCancellationPolicy(current.cancellationPolicy, hours)
											}));
										}
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "cancel-policy",
									children: "Texto da regra (hóspede)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "cancel-policy",
									rows: 3,
									maxLength: 400,
									value: form.cancellationPolicy,
									onChange: (event) => patch("cancellationPolicy", event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "overbook",
									children: "Política de overbooking"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "overbook",
									className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
									value: form.overbookingMode,
									onChange: (event) => patch("overbookingMode", event.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "bloquear",
										children: "Bloquear conflito (recomendado)"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "alertar",
										children: "Apenas alertar"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "deposit",
									children: "Sinal de pré-reserva"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "deposit",
									className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
									value: String(form.depositPercent),
									onChange: (event) => patch("depositPercent", Number(event.target.value)),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "30",
											children: "30%"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "50",
											children: "50%"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "100",
											children: "100%"
										})
									]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "self-start",
						disabled: save.isPending,
						children: "Salvar propriedade"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InventoryHoldsPanel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomTypeEditor, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailOutbox, {})
		]
	});
}
var SplitComponent = HotelSettingsView;
//#endregion
export { SplitComponent as component };
