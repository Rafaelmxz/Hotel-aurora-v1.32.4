import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { D as requiresPin, _ as ROLE_LABEL, a as Input, c as useInviteStaff, d as useStaff, f as useStaffSession, i as Label, l as usePatchStaff, o as Button, u as useRemoveStaff } from "./router-D2QglEY4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/equipe-CQrGGPgh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ROLES = [
	"admin",
	"gerente",
	"recepcionista",
	"governanca",
	"financeiro"
];
function UserManagementView() {
	const { data: users = [] } = useStaff();
	const { data: session } = useStaffSession();
	const invite = useInviteStaff();
	const patch = usePatchStaff();
	const remove = useRemoveStaff();
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("recepcionista");
	async function onInvite(event) {
		event.preventDefault();
		try {
			await invite.mutateAsync({
				name,
				email,
				role
			});
			toast.success(`Convite enviado · ${name}`);
			setName("");
			setEmail("");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível convidar.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Equipe"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "Usuários e permissões"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"Sessão atual: ",
						session.name,
						" · ",
						ROLE_LABEL[session.role],
						". Quem entra com o mesmo e-mail assume este cargo, sem PIN."
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: onInvite,
				className: "grid gap-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)] sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:col-span-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nome" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: name,
							onChange: (event) => setName(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:col-span-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "E-mail" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							type: "email",
							autoComplete: "email",
							inputMode: "email",
							placeholder: "nome@empresa.com",
							value: email,
							onChange: (event) => setEmail(event.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Cargo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
							value: role,
							onChange: (event) => setRole(event.target.value),
							children: ROLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: ROLE_LABEL[item]
							}, item))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "self-end",
						disabled: invite.isPending,
						children: "Convidar"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]",
				children: users.map((user) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-3 px-5 py-4 sm:grid-cols-[1fr_12rem_8rem_7rem_auto] sm:items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: user.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: user.email
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "h-10 rounded-md border border-input bg-card px-2 text-sm",
							value: user.role,
							onChange: (event) => void patch.mutateAsync({
								id: user.id,
								role: event.target.value
							}).catch((error) => toast.error(error instanceof Error ? error.message : "Não foi possível alterar o cargo.")),
							children: ROLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: ROLE_LABEL[item]
							}, item))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-10 rounded-md border border-input bg-card px-2 text-sm",
							value: user.status,
							onChange: (event) => void patch.mutateAsync({
								id: user.id,
								status: event.target.value
							}).catch((error) => toast.error(error instanceof Error ? error.message : "Não foi possível alterar o status.")),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "ativo",
								children: "Ativo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "inativo",
								children: "Inativo"
							})]
						}),
						requiresPin(user.role) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "h-10 rounded-md border border-input bg-card px-2 text-sm tabular-nums",
							inputMode: "numeric",
							maxLength: 4,
							placeholder: user.pin ? "PIN ••••" : "PIN 4 dígitos",
							onBlur: (event) => {
								const pin = event.target.value.replace(/\D/g, "").slice(0, 4);
								if (pin.length !== 4) return;
								patch.mutateAsync({
									id: user.id,
									pin
								}).then(() => {
									toast.success(`PIN atualizado · ${user.name}`);
									event.target.value = "";
								});
							}
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "self-center text-xs text-muted-foreground",
							children: "sem PIN"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							className: "h-10 justify-self-start text-destructive hover:text-destructive sm:justify-self-end",
							disabled: remove.isPending || user.id === session.id,
							onClick: () => {
								if (user.id === session.id) {
									toast.error("Não é possível excluir quem está na sessão agora.");
									return;
								}
								if (!window.confirm(`Excluir ${user.name} da equipe?`)) return;
								remove.mutateAsync(user.id).then(() => toast.success(`${user.name} foi excluído da equipe.`)).catch((error) => toast.error(error instanceof Error ? error.message : "Não foi possível excluir."));
							},
							children: "Excluir"
						})
					]
				}, user.id))
			})
		]
	});
}
var SplitComponent = UserManagementView;
//#endregion
export { SplitComponent as component };
