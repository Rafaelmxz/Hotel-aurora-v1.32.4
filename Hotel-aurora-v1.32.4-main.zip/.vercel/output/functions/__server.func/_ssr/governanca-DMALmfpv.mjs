import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as format } from "../_libs/date-fns.mjs";
import { a as HOUSEKEEPING_LABEL, i as HOUSEKEEPING_DOT, l as TODAY_ISO, o as HOUSEKEEPING_ORDER } from "./bookingStore-Bq0ubAXy.mjs";
import { a as TriangleAlert, c as Sparkles, n as Wrench, w as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Pt as cn, o as Button } from "./router-D2QglEY4.mjs";
import { t as Textarea } from "./textarea-CJRv6rNU.mjs";
import { a as useReservations } from "./useReservations-BEok-WZp.mjs";
import { n as usePatchHousekeeping, r as useRooms } from "./useRooms-DVLudIq6.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/governanca-DMALmfpv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	"todos",
	"sujo",
	"em_limpeza",
	"limpo",
	"manutencao"
];
var FILTER_LABEL = {
	todos: "Todos",
	sujo: "Sujo",
	em_limpeza: "Em limpeza",
	limpo: "Limpo",
	manutencao: "Manutenção"
};
function HousekeepingView() {
	const { data: rooms = [] } = useRooms();
	const { data: reservations = [] } = useReservations();
	const patch = usePatchHousekeeping();
	const [filter, setFilter] = (0, import_react.useState)("sujo");
	const [noteRoomId, setNoteRoomId] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)("");
	const checkInToday = (0, import_react.useMemo)(() => {
		const set = /* @__PURE__ */ new Set();
		for (const reservation of reservations) if (reservation.checkIn === TODAY_ISO && reservation.status !== "cancelada" && reservation.status !== "check-out") set.add(reservation.roomId);
		return set;
	}, [reservations]);
	const counts = (0, import_react.useMemo)(() => {
		const next = {
			sujo: 0,
			em_limpeza: 0,
			limpo: 0,
			manutencao: 0
		};
		for (const room of rooms) next[room.housekeepingStatus] += 1;
		return next;
	}, [rooms]);
	const visible = rooms.filter((room) => filter === "todos" || room.housekeepingStatus === filter);
	async function setStatus(room, housekeepingStatus, extraNote) {
		try {
			await patch.mutateAsync({
				id: room.id,
				housekeepingStatus,
				note: extraNote
			});
			toast.success(`Quarto ${room.number} · ${HOUSEKEEPING_LABEL[housekeepingStatus]}`);
			setNoteRoomId(null);
			setNote("");
		} catch {
			toast.error("Não foi possível atualizar o quarto.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Governança"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-medium tracking-tight",
						children: "Limpeza de quartos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Toque uma vez para avançar o status. O mapa da recepção atualiza na hora."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky top-[3.75rem] z-20 -mx-4 overflow-x-auto bg-background/90 px-4 py-2 backdrop-blur-sm sm:static sm:mx-0 sm:overflow-visible sm:bg-transparent sm:px-0 sm:py-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-w-max gap-2 sm:flex-wrap",
					children: FILTERS.map((item) => {
						const count = item === "todos" ? rooms.length : counts[item];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setFilter(item),
							className: cn("inline-flex h-11 items-center gap-2 rounded-full px-4 text-sm font-medium", filter === item ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"),
							children: [
								item !== "todos" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2.5 rounded-full", HOUSEKEEPING_DOT[item]) }) : null,
								FILTER_LABEL[item],
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums opacity-80",
									children: count
								})
							]
						}, item);
					})
				})
			}),
			visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-card px-5 py-8 text-center text-sm text-muted-foreground shadow-[var(--shadow-border)]",
				children: "Nenhum quarto neste status."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
				children: visible.map((room) => {
					const priority = checkInToday.has(room.id);
					const status = room.housekeepingStatus;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col gap-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-3xl font-medium tracking-tight tabular-nums",
									children: room.number
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: room.type
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1 text-xs font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", HOUSEKEEPING_DOT[status]) }), HOUSEKEEPING_LABEL[status]]
								})]
							}),
							priority ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "inline-flex items-center gap-2 rounded-lg bg-status-pending/10 px-3 py-2 text-sm font-medium text-status-pending",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4" }), "Check-in previsto hoje"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "Sem chegada hoje"
							}),
							room.housekeepingNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: room.housekeepingNote
							}) : null,
							room.cleaningStartedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: ["Limpeza desde ", format(new Date(room.cleaningStartedAt), "HH:mm")]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-auto grid gap-2",
								children: [
									status === "sujo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										className: "h-12",
										disabled: patch.isPending,
										onClick: () => setStatus(room, "em_limpeza"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), "Iniciar limpeza"]
									}) : null,
									status === "em_limpeza" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										className: "h-12",
										disabled: patch.isPending,
										onClick: () => setStatus(room, "limpo"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), "Marcar limpo"]
									}) : null,
									status === "manutencao" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "h-12",
										disabled: patch.isPending,
										onClick: () => setStatus(room, "limpo"),
										children: "Liberar quarto"
									}) : null,
									status !== "manutencao" ? noteRoomId === room.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
											value: note,
											onChange: (event) => setNote(event.target.value),
											placeholder: "Ex.: ar-condicionado com defeito"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											variant: "outline",
											className: "h-11",
											disabled: patch.isPending,
											onClick: () => setStatus(room, "manutencao", note.trim() || "Manutenção"),
											children: "Confirmar manutenção"
										})]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "outline",
										className: "h-11",
										onClick: () => {
											setNoteRoomId(room.id);
											setNote(room.housekeepingNote ?? "");
										},
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "size-4" }), "Manutenção"]
									}) : null
								]
							})
						]
					}, room.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: ["Status: ", HOUSEKEEPING_ORDER.map((item) => HOUSEKEEPING_LABEL[item]).join(" · ")]
			})
		]
	});
}
var SplitComponent = HousekeepingView;
//#endregion
export { SplitComponent as component };
