import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { O as formatCurrency } from "./bookingStore-Bq0ubAXy.mjs";
import { Z as getGuestStats, a as Input, jt as searchGuests } from "./router-D2QglEY4.mjs";
import { r as useGuests } from "./useGuests-BJjZTm3Q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hospedes-BUExBgWu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GuestListView() {
	const { data: guests = [] } = useGuests();
	const [query, setQuery] = (0, import_react.useState)("");
	const rows = (0, import_react.useMemo)(() => {
		return (query.trim() ? searchGuests(query) : guests).map((guest) => getGuestStats(guest));
	}, [guests, query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Fichas"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "Hóspedes"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Histórico, preferências e valor de vida (LTV)."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "Buscar por nome ou CPF"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]",
				children: rows.map(({ guest, ltv, stayCount }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/hospedes/$guestId",
					params: { guestId: guest.id },
					className: "flex flex-wrap items-center justify-between gap-3 px-5 py-4 hover:bg-secondary/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: guest.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							guest.cpf,
							" · ",
							stayCount,
							" estadias",
							guest.tags.length ? ` · ${guest.tags.join(", ")}` : ""
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tabular-nums text-sm font-medium",
						children: formatCurrency(ltv)
					})]
				}) }, guest.id))
			})
		]
	});
}
var SplitComponent = GuestListView;
//#endregion
export { SplitComponent as component };
