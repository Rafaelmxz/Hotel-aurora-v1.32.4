import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { O as formatCurrency, et as roomById, k as formatStayRange } from "./bookingStore-Bq0ubAXy.mjs";
import { n as Route$1 } from "./router-D2QglEY4.mjs";
import { r as STATUS_LABEL } from "./status-lXSun_aS.mjs";
import { t as useGuestProfile } from "./useGuests-BJjZTm3Q.mjs";
import { t as FolioStatement } from "./FolioStatement-D_wrLK-R.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hospedes._guestId-UfUiVyxF.js
var import_jsx_runtime = require_jsx_runtime();
function GuestProfileView({ guestId }) {
	const { data } = useGuestProfile(guestId);
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Hóspede não encontrado."
	});
	const { guest, stays, ltv, stayCount } = data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/hospedes",
						className: "text-muted-foreground hover:text-foreground",
						children: "Hóspedes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: " / "
					}),
					guest.name
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Ficha"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-medium tracking-tight",
						children: guest.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							guest.email,
							" · ",
							guest.phone,
							" · CPF ",
							guest.cpf
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: guest.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-secondary px-3 py-1 text-xs font-medium",
							children: tag
						}, tag))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display mt-4 text-2xl font-medium tabular-nums",
						children: formatCurrency(ltv)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground uppercase",
						children: [
							"LTV · ",
							stayCount,
							" estadias"
						]
					})
				]
			}),
			guest.preferences.length > 0 || guest.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium tracking-tight",
						children: "Preferências"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 list-disc space-y-1 pl-5 text-sm",
						children: guest.preferences.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
					}),
					guest.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm",
						children: guest.notes
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-card shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display px-5 pt-5 text-xl font-medium tracking-tight",
					children: "Histórico de estadias"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-2 divide-y divide-border",
					children: stays.map((stay) => {
						const room = roomById(stay.reservation.roomId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "px-5 py-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: formatStayRange(stay.reservation.checkIn, stay.reservation.checkOut)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mb-3 text-sm text-muted-foreground",
									children: [
										"Quarto ",
										room?.number ?? "—",
										" · ",
										STATUS_LABEL[stay.reservation.status]
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolioStatement, {
									linhas: stay.folio.linhas,
									totais: stay.folio.totais
								})
							]
						}, stay.reservation.id);
					})
				})]
			})
		]
	});
}
function GuestProfilePage() {
	const { guestId } = Route$1.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GuestProfileView, { guestId });
}
//#endregion
export { GuestProfilePage as component };
