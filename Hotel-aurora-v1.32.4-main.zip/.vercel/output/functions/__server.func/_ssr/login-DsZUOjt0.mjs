import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Navigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as signIn, t as authClient } from "./client-CVqXY6bk.mjs";
import { t as GROK_PROVIDERS } from "./server-DhL3ZIaK.mjs";
import { Pt as cn, a as Input, h as Logo, i as Label, o as Button, r as useCurrentUserState } from "./router-D2QglEY4.mjs";
import { t as Root } from "../_libs/radix-ui__react-separator.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DsZUOjt0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Separator({ className, orientation = "horizontal", decorative = true, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
		"data-slot": "separator",
		decorative,
		orientation,
		className: cn("shrink-0 bg-border data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px", className),
		...props
	});
}
function authErrorMessage(message) {
	const text = message ?? "";
	if (/already exists/i.test(text)) return "Já existe uma conta com este e-mail.";
	if (/invalid email or password/i.test(text) || /invalid credentials/i.test(text)) return "E-mail ou senha inválidos.";
	if (/password/i.test(text)) return "A senha deve ter pelo menos 8 caracteres.";
	if (/invalid email/i.test(text)) return "Informe um e-mail válido, no formato nome@dominio.com.";
	return "Não foi possível entrar. Tente de novo.";
}
function LoginShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid min-h-dvh bg-background lg:grid-cols-[minmax(0,1fr)_28rem]",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative hidden flex-col justify-between bg-primary px-10 py-12 text-primary-foreground lg:flex",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid size-10 place-items-center rounded-lg bg-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className: "size-8" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl font-medium tracking-tight",
						children: "Hotel Aurora"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-wide uppercase opacity-80",
						children: "Gestão hoteleira"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-md space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl font-medium tracking-tight",
						children: "A recepção entra com a própria conta."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm leading-relaxed opacity-85",
						children: "O primeiro acesso vira administrador do hotel. Os próximos entram como recepção. Cargos e PIN continuam na Equipe."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs opacity-70",
					children: "PIN de elevação demo: 1234"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "grid place-items-center px-4 py-10 sm:px-8",
			children
		})]
	});
}
function LoginView() {
	const { user } = useCurrentUserState();
	const [mode, setMode] = (0, import_react.useState)("entrar");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	async function onSubmit(event) {
		event.preventDefault();
		setError("");
		setBusy(true);
		try {
			if (mode === "criar") {
				const { error: signUpError } = await authClient.signUp.email({
					email,
					password,
					name: name.trim() || email.split("@")[0] || "Equipe"
				});
				if (signUpError) throw new Error(signUpError.message);
			} else {
				const { error: signInError } = await authClient.signIn.email({
					email,
					password
				});
				if (signInError) throw new Error(signInError.message);
			}
			await authClient.getSession();
			window.location.href = "/";
		} catch (err) {
			setError(authErrorMessage(err instanceof Error ? err.message : void 0));
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-sm space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Hotel Aurora"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-wide text-muted-foreground uppercase",
					children: "Área da equipe"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl font-medium tracking-tight",
				children: mode === "entrar" ? "Entrar na recepção" : "Criar conta da equipe"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: mode === "entrar" ? "Use o e-mail da equipe ou continue com Google ou X." : "A conta fica ligada ao cargo. Sem PIN para o próprio e-mail."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "grid gap-3",
					children: [
						mode === "criar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "login-name",
								children: "Nome"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "login-name",
								required: true,
								autoComplete: "name",
								value: name,
								onChange: (event) => setName(event.target.value)
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "login-email",
								children: "E-mail"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "login-email",
								required: true,
								type: "email",
								autoComplete: "email",
								inputMode: "email",
								placeholder: "nome@empresa.com",
								value: email,
								onChange: (event) => setEmail(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "login-password",
								children: "Senha"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "login-password",
								required: true,
								type: "password",
								autoComplete: mode === "criar" ? "new-password" : "current-password",
								minLength: 8,
								value: password,
								onChange: (event) => setPassword(event.target.value)
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "h-11",
							disabled: busy,
							children: busy ? "Aguarde…" : mode === "entrar" ? "Entrar" : "Criar conta"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-sm text-muted-foreground underline-offset-4 hover:underline",
					onClick: () => {
						setMode(mode === "entrar" ? "criar" : "entrar");
						setError("");
					},
					children: mode === "entrar" ? "Criar conta da equipe" : "Já tenho conta · Entrar"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "flex-1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs tracking-wide text-muted-foreground uppercase",
							children: "ou"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "flex-1" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2",
					children: GROK_PROVIDERS.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						className: "h-11",
						disabled: busy,
						onClick: () => {
							setBusy(true);
							signIn(provider.providerId, { callbackURL: "/" }).catch((err) => {
								setError(authErrorMessage(err instanceof Error ? err.message : void 0));
								setBusy(false);
							});
						},
						children: ["Continuar com ", provider.label]
					}, provider.providerId))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-center text-sm text-muted-foreground",
				children: [
					"Hóspede?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/reservar",
						className: "underline underline-offset-4",
						children: "Reserve sua estadia"
					})
				]
			})
		]
	}) });
}
var SplitComponent = LoginView;
//#endregion
export { SplitComponent as component };
