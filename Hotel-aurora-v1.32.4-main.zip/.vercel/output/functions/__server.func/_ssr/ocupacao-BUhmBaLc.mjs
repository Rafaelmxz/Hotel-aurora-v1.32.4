import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as format, n as parseISO, t as ptBR, y as addDays } from "../_libs/date-fns.mjs";
import { I as isStayActiveOn, c as TODAY, l as TODAY_ISO, nt as rooms } from "./bookingStore-Bq0ubAXy.mjs";
import { Pt as cn, a as Input, o as Button } from "./router-D2QglEY4.mjs";
import { a as useReservations } from "./useReservations-BEok-WZp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ocupacao-BUhmBaLc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TYPES = [
	"Standard",
	"Luxo",
	"Suíte"
];
var DAYS = 14;
function toISO(date) {
	return format(date, "yyyy-MM-dd");
}
function OccupancyView() {
	const { data: reservations = [] } = useReservations();
	const [startIso, setStartIso] = (0, import_react.useState)(TODAY_ISO);
	const start = parseISO(startIso);
	const columns = (0, import_react.useMemo)(() => Array.from({ length: DAYS }, (_, index) => addDays(start, index)), [start]);
	const inventory = (0, import_react.useMemo)(() => {
		const byType = {
			Standard: 0,
			Luxo: 0,
			Suíte: 0
		};
		for (const room of rooms) byType[room.type] += 1;
		return byType;
	}, []);
	const matrix = (0, import_react.useMemo)(() => {
		return columns.map((day) => {
			const occupiedIds = new Set(reservations.filter((row) => isStayActiveOn(row, day)).map((row) => row.roomId));
			const byType = {
				Standard: 0,
				Luxo: 0,
				Suíte: 0
			};
			for (const room of rooms) if (!occupiedIds.has(room.id)) byType[room.type] += 1;
			const free = rooms.length - occupiedIds.size;
			return {
				day,
				occupancy: Math.round(occupiedIds.size / rooms.length * 100),
				free,
				byType
			};
		});
	}, [columns, reservations]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Disponibilidade"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "Ocupação 14 dias"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => setStartIso(toISO(addDays(start, -14))),
							children: "← 14 dias"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							className: "w-[11.5rem]",
							value: startIso,
							onChange: (event) => setStartIso(event.target.value || TODAY_ISO)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => setStartIso(toISO(addDays(start, DAYS))),
							children: "14 dias →"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => setStartIso(TODAY_ISO),
							children: "Hoje"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-xl bg-card shadow-[var(--shadow-border)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[56rem] border-collapse text-center text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "bg-secondary text-xs tracking-wide text-muted-foreground uppercase",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "sticky left-0 z-10 bg-secondary px-3 py-3 text-left font-medium",
							children: "Categoria"
						}), matrix.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
							className: "px-2 py-3 font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "capitalize",
								children: format(col.day, "EEE d", { locale: ptBR })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("mt-1 text-[11px] normal-case", col.free === 0 ? "font-semibold text-destructive" : ""),
								children: [
									col.occupancy,
									"% · ",
									col.free,
									" livre",
									col.free === 1 ? "" : "s"
								]
							})]
						}, toISO(col.day)))]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
							className: "sticky left-0 z-10 bg-card px-3 py-3 text-left font-medium",
							children: [type, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs font-normal text-muted-foreground",
								children: [inventory[type], " quartos"]
							})]
						}), matrix.map((col) => {
							const free = col.byType[type];
							const soldOut = free === 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-2 py-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("inline-flex min-w-9 items-center justify-center rounded-md px-2 py-1 text-sm font-medium tabular-nums", soldOut ? "bg-destructive text-white" : "bg-secondary text-foreground"),
									children: soldOut ? "0" : free
								})
							}, `${type}-${toISO(col.day)}`);
						})]
					}, type)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					"Cada célula mostra vagas livres na categoria. Vermelho = lotado (0 vagas). Data de referência: ",
					format(TODAY, "dd/MM/yyyy"),
					"."
				]
			})
		]
	});
}
var SplitComponent = OccupancyView;
//#endregion
export { SplitComponent as component };
