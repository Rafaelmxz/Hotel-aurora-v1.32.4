//#region node_modules/.nitro/vite/services/ssr/assets/ofertas-D1DgnoHx.js
var SplitComponent = () => null;
//#endregion
export { SplitComponent as component };
