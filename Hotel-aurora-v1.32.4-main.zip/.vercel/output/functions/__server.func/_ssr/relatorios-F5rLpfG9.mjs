import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as startOfYear, d as max, f as addYears, i as format, o as startOfMonth, p as differenceInCalendarDays, t as ptBR, u as min, v as addMonths } from "../_libs/date-fns.mjs";
import { G as parseISODate, O as formatCurrency, lt as stayNights, nt as rooms } from "./bookingStore-Bq0ubAXy.mjs";
import { d as Printer } from "../_libs/lucide-react.mjs";
import { $ as listAllConsumos, M as METODO_PAGAMENTO_LABEL, Pt as cn, et as listAllPagamentos, o as Button, p as useProperty } from "./router-D2QglEY4.mjs";
import { n as CardContent, t as Card } from "./card-C5pfQ1_E.mjs";
import { a as useReservations } from "./useReservations-BEok-WZp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/relatorios-F5rLpfG9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function overlapNights(aStart, aEnd, bStart, bEnd) {
	const start = max([aStart, bStart]);
	const end = min([aEnd, bEnd]);
	const nights = differenceInCalendarDays(end, start);
	return nights > 0 ? nights : 0;
}
function periodRange(mode, cursor) {
	if (mode === "year") {
		const start = startOfYear(cursor);
		return {
			start,
			end: addYears(start, 1)
		};
	}
	const start = startOfMonth(cursor);
	return {
		start,
		end: addMonths(start, 1)
	};
}
function previousRange(mode, cursor) {
	return periodRange(mode, mode === "year" ? addYears(cursor, -1) : addMonths(cursor, -1));
}
function computeKpis(reservations, start, end) {
	const days = Math.max(1, differenceInCalendarDays(end, start));
	const availableNights = rooms.length * days;
	let occupiedNights = 0;
	let roomRevenue = 0;
	for (const reservation of reservations) {
		if (reservation.status === "cancelada") continue;
		const overlap = overlapNights(parseISODate(reservation.checkIn), parseISODate(reservation.checkOut), start, end);
		if (overlap <= 0) continue;
		occupiedNights += overlap;
		const nights = stayNights(reservation.checkIn, reservation.checkOut);
		roomRevenue += nights > 0 ? reservation.totalAmount * overlap / nights : 0;
	}
	const adr = occupiedNights > 0 ? roomRevenue / occupiedNights : 0;
	return {
		occupancy: availableNights > 0 ? occupiedNights / availableNights * 100 : 0,
		adr,
		revpar: availableNights > 0 ? roomRevenue / availableNights : 0,
		occupiedNights,
		availableNights,
		roomRevenue
	};
}
function inRange(iso, start, end) {
	const day = parseISODate(iso);
	return day >= start && day < end;
}
function computeDre(reservations, start, end) {
	const kpis = computeKpis(reservations, start, end);
	const extras = listAllConsumos().filter((item) => inRange(item.data_lancamento, start, end)).reduce((sum, item) => sum + item.valor * item.quantidade, 0);
	const byMethod = {
		pix: 0,
		cartao_credito: 0,
		cartao_debito: 0,
		dinheiro: 0
	};
	let received = 0;
	for (const payment of listAllPagamentos()) {
		if (!inRange(payment.data_pagamento, start, end)) continue;
		byMethod[payment.metodo] += payment.valor;
		received += payment.valor;
	}
	return {
		roomRevenue: kpis.roomRevenue,
		extras,
		gross: kpis.roomRevenue + extras,
		byMethod,
		received
	};
}
function buildPeriodReport(reservations, start, end) {
	return {
		start,
		end,
		kpis: computeKpis(reservations, start, end),
		dre: computeDre(reservations, start, end)
	};
}
function delta(current, previous) {
	if (previous === 0) return current === 0 ? 0 : 100;
	return (current - previous) / previous * 100;
}
var METHODS = [
	"pix",
	"cartao_credito",
	"cartao_debito",
	"dinheiro"
];
function pct(value) {
	return `${value >= 0 ? "+" : ""}${value.toFixed(1)}%`;
}
function ReportsView() {
	const { data: reservations = [] } = useReservations();
	const { data: property } = useProperty();
	const [mode, setMode] = (0, import_react.useState)("month");
	const [cursor, setCursor] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const currentRange = periodRange(mode, cursor);
	const prevRange = previousRange(mode, cursor);
	const current = (0, import_react.useMemo)(() => buildPeriodReport(reservations, currentRange.start, currentRange.end), [
		reservations,
		currentRange.start,
		currentRange.end
	]);
	const previous = (0, import_react.useMemo)(() => buildPeriodReport(reservations, prevRange.start, prevRange.end), [
		reservations,
		prevRange.start,
		prevRange.end
	]);
	const periodLabel = mode === "year" ? format(currentRange.start, "yyyy") : format(currentRange.start, "MMMM yyyy", { locale: ptBR });
	const kpis = [
		{
			key: "occ",
			label: "Taxa de ocupação",
			value: `${current.kpis.occupancy.toFixed(1)}%`,
			hint: `${current.kpis.occupiedNights} de ${current.kpis.availableNights} noites-quarto`,
			change: delta(current.kpis.occupancy, previous.kpis.occupancy)
		},
		{
			key: "adr",
			label: "ADR / diária média",
			value: formatCurrency(current.kpis.adr),
			hint: "Receita de diárias / quartos vendidos",
			change: delta(current.kpis.adr, previous.kpis.adr)
		},
		{
			key: "revpar",
			label: "RevPAR",
			value: formatCurrency(current.kpis.revpar),
			hint: "Receita de diárias / quartos disponíveis",
			change: delta(current.kpis.revpar, previous.kpis.revpar)
		}
	];
	function exportCsv() {
		const csv = [
			[
				"Relatório",
				property.name,
				periodLabel
			],
			[
				"Indicador",
				"Atual",
				"Anterior",
				"Variação"
			],
			[
				"Ocupação %",
				current.kpis.occupancy.toFixed(1),
				previous.kpis.occupancy.toFixed(1),
				pct(delta(current.kpis.occupancy, previous.kpis.occupancy))
			],
			[
				"ADR",
				String(Math.round(current.kpis.adr)),
				String(Math.round(previous.kpis.adr)),
				pct(delta(current.kpis.adr, previous.kpis.adr))
			],
			[
				"RevPAR",
				String(Math.round(current.kpis.revpar)),
				String(Math.round(previous.kpis.revpar)),
				pct(delta(current.kpis.revpar, previous.kpis.revpar))
			],
			[
				"Receita diárias",
				String(Math.round(current.dre.roomRevenue)),
				String(Math.round(previous.dre.roomRevenue))
			],
			[
				"Consumos",
				String(Math.round(current.dre.extras)),
				String(Math.round(previous.dre.extras))
			],
			[
				"Receita bruta",
				String(Math.round(current.dre.gross)),
				String(Math.round(previous.dre.gross)),
				pct(delta(current.dre.gross, previous.dre.gross))
			],
			...METHODS.map((method) => [
				METODO_PAGAMENTO_LABEL[method],
				String(Math.round(current.dre.byMethod[method])),
				String(Math.round(previous.dre.byMethod[method]))
			])
		].map((row) => row.join(";")).join("\n");
		const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
		const url = URL.createObjectURL(blob);
		const link = document.createElement("a");
		link.href = url;
		link.download = `relatorio-${format(currentRange.start, "yyyy-MM")}.csv`;
		link.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Relatórios gerenciais"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-medium tracking-tight capitalize",
						children: periodLabel
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Ocupação, ADR, RevPAR e DRE simplificado."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex rounded-full bg-secondary p-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("h-9 rounded-full px-3 text-sm font-medium", mode === "month" ? "bg-card shadow-[var(--shadow-border)]" : "text-muted-foreground"),
								onClick: () => setMode("month"),
								children: "Mensal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("h-9 rounded-full px-3 text-sm font-medium", mode === "year" ? "bg-card shadow-[var(--shadow-border)]" : "text-muted-foreground"),
								onClick: () => setMode("year"),
								children: "Anual"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: mode === "year" ? "number" : "month",
							className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
							value: mode === "year" ? String(cursor.getFullYear()) : format(cursor, "yyyy-MM"),
							onChange: (event) => {
								const value = event.target.value;
								if (mode === "year") setCursor(new Date(Number(value), 0, 1));
								else {
									const [year, month] = value.split("-").map(Number);
									setCursor(new Date(year, (month ?? 1) - 1, 1));
								}
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: exportCsv,
							children: "CSV"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => window.print(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Imprimir / PDF"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: kpis.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: item.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display mt-2 text-3xl font-medium tracking-tight tabular-nums",
						children: item.value
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: item.hint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: cn("mt-2 text-sm tabular-nums", item.change >= 0 ? "text-status-checkout" : "text-status-pending"),
						children: [pct(item.change), " vs período anterior"]
					})
				] }) }, item.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium tracking-tight",
						children: "DRE simplificado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid gap-2 text-sm sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: "Receita de diárias"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums sm:text-right",
								children: formatCurrency(current.dre.roomRevenue)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: "Consumos / extras"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums sm:text-right",
								children: formatCurrency(current.dre.extras)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "font-medium",
								children: "Receita bruta"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-medium tabular-nums sm:text-right",
								children: formatCurrency(current.dre.gross)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: "Receita bruta anterior"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums sm:text-right",
								children: formatCurrency(previous.dre.gross)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: "Variação"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "tabular-nums sm:text-right",
								children: pct(delta(current.dre.gross, previous.dre.gross))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-6 text-sm font-medium",
						children: "Formas de recebimento"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 divide-y divide-border",
						children: [METHODS.map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: METODO_PAGAMENTO_LABEL[method] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: formatCurrency(current.dre.byMethod[method])
							})]
						}, method)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between py-2 text-sm font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total recebido" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: formatCurrency(current.dre.received)
							})]
						})]
					})
				]
			})
		]
	});
}
var SplitComponent = ReportsView;
//#endregion
export { SplitComponent as component };
