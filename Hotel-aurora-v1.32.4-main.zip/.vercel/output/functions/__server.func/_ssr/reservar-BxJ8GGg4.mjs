import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { y as addDays } from "../_libs/date-fns.mjs";
import { G as parseISODate, J as quoteExtras, O as formatCurrency, l as TODAY_ISO, lt as stayNights, n as EXTRA_UNIT_LABEL, nt as rooms, ut as toISODate, w as extraQuantity, y as availableRoomsByType } from "./bookingStore-Bq0ubAXy.mjs";
import { w as Check } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { G as extraStory, Mt as typeFitsParty, Pt as cn, Y as getFolio, a as Input, dt as occupancyOfType, i as Label, o as Button, p as useProperty, vt as quoteStay } from "./router-D2QglEY4.mjs";
import { a as useReservations, n as useCreatePublicReservation } from "./useReservations-BEok-WZp.mjs";
import { r as useRooms } from "./useRooms-DVLudIq6.mjs";
import { t as useRoomTypes } from "./useRoomTypes-B7WZBIgo.mjs";
import { t as useBlocks } from "./useBlocks-Dt0MBuAT.mjs";
import { r as useSaleCloses } from "./useSaleCloses-BDBCA2UD.mjs";
import { i as pixTxid, n as StayVoucher, r as pixNote, t as PixCharge } from "./StayVoucher-BMRYBVTZ.mjs";
import { t as useBookingConfig } from "./useBookingEngine-1wAIPgj0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reservar-BxJ8GGg4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Motor público: quarto → extras → dados.
* Pode: lista vertical, banner que encolhe, experiências à parte.
* Proibido: clonar HSystem, tarifário extra, OTA, mudar ouro/Pix.
* Preço: quoteStay da grelha (C1). Criança conta no tipo (2+1), não na capacidade do quarto.
*/
function nextNight(iso) {
	return toISODate(addDays(parseISODate(iso), 1));
}
function occupancyGridLabel(adults, children) {
	return `Tarifa da grelha · ${adults <= 4 ? `${adults} ADL` : `4 ADL + ${adults - 4} extra`}${children <= 0 ? "" : children <= 2 ? ` · ${children} CHD` : ` · 2 CHD + ${children - 2} extra`}`;
}
function ExperienceCards({ extras, extraIds, nights, guests, searched, onToggle }) {
	if (!extras.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-xl border border-border bg-card p-5 text-sm text-muted-foreground",
		children: "Nenhuma experiência extra neste momento. Pode continuar a reserva."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-4",
		children: extras.map((item) => {
			const story = extraStory(item.id);
			const picked = extraIds.includes(item.id);
			const qty = extraQuantity(item, nights, guests);
			const stayTotal = item.price * qty;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: cn("grid overflow-hidden rounded-xl border border-border bg-card sm:grid-cols-[10rem_1fr]", picked && "ring-2 ring-primary"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: story.photo,
					alt: "",
					className: "h-36 w-full object-cover sm:h-full"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-medium",
								children: item.name
							}), picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex shrink-0 items-center gap-1 rounded-full bg-accent px-2 py-0.5 text-xs font-medium text-accent-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }), "Incluída"]
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: story.blurb
						}),
						story.included ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: story.included
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [
								formatCurrency(item.price),
								" ",
								EXTRA_UNIT_LABEL[item.unit],
								searched ? qty > 1 ? ` · ${qty} × ${formatCurrency(item.price)} = ${formatCurrency(stayTotal)} nesta estadia` : ` · ${formatCurrency(stayTotal)} nesta estadia` : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: picked ? "outline" : "default",
							className: "justify-self-start",
							onClick: () => onToggle(item.id),
							children: picked ? "Remover" : "Incluir"
						})
					]
				})]
			}, item.id);
		})
	});
}
function PublicShowcaseView() {
	const { data: config } = useBookingConfig();
	const { data: property } = useProperty();
	const { data: reservations = [] } = useReservations();
	const { data: roomList = [] } = useRooms();
	const { data: types = [] } = useRoomTypes();
	const { data: blocks = [] } = useBlocks();
	const { data: saleCloses = [] } = useSaleCloses();
	const create = useCreatePublicReservation();
	const [checkIn, setCheckIn] = (0, import_react.useState)(TODAY_ISO);
	const [checkOut, setCheckOut] = (0, import_react.useState)(() => nextNight(TODAY_ISO));
	const [adults, setAdults] = (0, import_react.useState)(2);
	const [children, setChildren] = (0, import_react.useState)(0);
	const [searched, setSearched] = (0, import_react.useState)(true);
	const [step, setStep] = (0, import_react.useState)("vitrine");
	const [roomType, setRoomType] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [payMode, setPayMode] = (0, import_react.useState)("pix");
	const [extraIds, setExtraIds] = (0, import_react.useState)([]);
	const [voucher, setVoucher] = (0, import_react.useState)(null);
	const occupancy = adults + children;
	const periodOk = Boolean(checkIn && checkOut && checkOut > checkIn);
	const nights = periodOk ? stayNights(checkIn, checkOut) : 1;
	const available = (0, import_react.useMemo)(() => periodOk ? availableRoomsByType(reservations, checkIn, checkOut, roomList.length ? roomList : rooms, blocks, saleCloses) : {}, [
		periodOk,
		reservations,
		checkIn,
		checkOut,
		roomList,
		blocks,
		saleCloses
	]);
	const catalog = types.map((item) => {
		const free = typeFitsParty(item, adults, children) ? available[item.type] ?? [] : [];
		const quote = periodOk ? quoteStay(item.type, checkIn, checkOut, {
			adults,
			children,
			segment: "site"
		}) : null;
		return {
			...item,
			free: free.length,
			quote,
			rooms: free,
			capacity: occupancyOfType(item)
		};
	});
	const selected = catalog.find((item) => item.type === roomType);
	const quote = roomType && periodOk ? quoteStay(roomType, checkIn, checkOut, {
		adults,
		children,
		pix: payMode === "pix",
		segment: "site"
	}) : null;
	const extrasQuote = quoteExtras(config.extras ?? [], extraIds, quote?.nights ?? nights, occupancy);
	const extrasTotal = extrasQuote.total;
	const stayTotal = (quote?.total ?? 0) + extrasTotal;
	const deposit = stayTotal ? Math.round(stayTotal * (config.depositPercent / 100)) : 0;
	const pixSeed = `${roomType}-${checkIn}-${checkOut}-${deposit}-${extraIds.join(",")}`;
	const extraCatalog = (config.extras ?? []).filter((item) => item.enabled);
	function onSearch(event) {
		event.preventDefault();
		if (!periodOk) {
			toast.error("Informe um período válido de check-in e check-out.");
			return;
		}
		setSearched(true);
		setVoucher(null);
		if (step === "extras" || step === "pagamento") {
			const item = catalog.find((row) => row.type === roomType);
			if (!item || item.free === 0) {
				toast.warning("Esta categoria não está livre nestas datas. Escolha outro quarto.");
				setStep("vitrine");
			}
			return;
		}
		setStep("vitrine");
		if (!catalog.some((item) => item.free > 0)) toast.warning("Não há quartos livres para essas datas e ocupação.");
	}
	function chooseType(type) {
		const item = catalog.find((row) => row.type === type);
		if (searched && (!item || item.free === 0)) {
			toast.error("Esta categoria não está disponível no período.");
			return;
		}
		if (!searched) {
			toast.error("Busque a disponibilidade primeiro.");
			return;
		}
		setRoomType(type);
		setStep("extras");
	}
	function resetToVitrine() {
		setName("");
		setEmail("");
		setVoucher(null);
		setExtraIds([]);
		setStep("vitrine");
	}
	function toggleExtra(id) {
		setExtraIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
	}
	async function onSubmit(event) {
		event.preventDefault();
		const room = selected?.rooms[0];
		if (!room || !roomType) {
			toast.error("Nenhum quarto livre nesta categoria.");
			return;
		}
		if (payMode === "pix" && deposit < 1) {
			toast.error("Não há valor de sinal para gerar o Pix.");
			return;
		}
		const liveQuote = roomType && checkIn && checkOut ? quoteStay(roomType, checkIn, checkOut, {
			adults,
			children,
			pix: payMode === "pix",
			segment: "site"
		}) : quote;
		const liveExtras = quoteExtras(config.extras ?? [], extraIds, liveQuote?.nights ?? nights, occupancy);
		const liveStay = (liveQuote?.total ?? 0) + liveExtras.total;
		const depositPaid = payMode === "pix" && liveStay > 0 ? Math.max(1, Math.round(liveStay * (config.depositPercent / 100))) : 0;
		const txid = pixTxid(pixSeed);
		try {
			const created = await create.mutateAsync({
				roomId: room.id,
				guestName: name,
				guestEmail: email,
				checkIn,
				checkOut,
				guests: occupancy,
				adults,
				children,
				payMode,
				extras: liveExtras.lines.map((line) => ({
					id: line.id,
					name: line.name,
					unitPrice: line.unitPrice,
					quantity: line.quantity
				})),
				deposit: payMode === "pix" ? {
					valor: depositPaid,
					comprovante: `Pix ${txid}`
				} : void 0,
				notes: [
					phone ? `Tel: ${phone}` : "",
					`${adults} adulto(s)` + (children ? ` · ${children} criança(s)` : ""),
					liveExtras.lines.length ? `Experiências: ${liveExtras.lines.map((line) => line.name).join(", ")}` : "",
					payMode === "pix" ? `${pixNote(pixSeed, config.depositPercent)}${liveQuote?.appliedOffers.length ? ` · ofertas: ${liveQuote.appliedOffers.map((item) => item.name).join(", ")}` : ""}` : "Pagamento no check-in"
				].filter(Boolean).join(" · ")
			});
			const folio = getFolio(created.id);
			setVoucher({
				reservation: created,
				roomLabel: `Quarto ${room.number} · ${room.type}`,
				totais: folio.totais
			});
			setStep("voucher");
			toast.success(payMode === "pix" ? `Reserva confirmada no quarto ${room.number}. Voucher enviado para ${email}.` : `Pré-reserva no quarto ${room.number}. Voucher enviado para ${email}.`);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível concluir a pré-reserva.");
		}
	}
	const searchBar = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
		onSubmit: onSearch,
		className: "border-b border-border bg-background/95 px-4 py-3 backdrop-blur-sm sm:px-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-5xl gap-2 sm:grid-cols-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Check-in"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						required: true,
						min: TODAY_ISO,
						value: checkIn,
						onChange: (event) => {
							const next = event.target.value >= TODAY_ISO ? event.target.value : TODAY_ISO;
							setCheckIn(next);
							setCheckOut(nextNight(next));
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Check-out"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "date",
						required: true,
						min: nextNight(checkIn),
						value: checkOut,
						onChange: (event) => {
							const min = nextNight(checkIn);
							setCheckOut(event.target.value > checkIn ? event.target.value : min);
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Adultos"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "text",
						inputMode: "numeric",
						value: String(adults).padStart(2, "0"),
						onKeyDown: (event) => {
							if (event.key === "ArrowUp") {
								event.preventDefault();
								setAdults((current) => Math.min(6, current + 1));
							}
							if (event.key === "ArrowDown") {
								event.preventDefault();
								setAdults((current) => Math.max(1, current - 1));
							}
						},
						onChange: (event) => {
							const digits = event.target.value.replace(/\D/g, "");
							if (!digits) {
								setAdults(1);
								return;
							}
							const padded = String(adults).padStart(2, "0");
							const next = digits.startsWith(padded) ? Number(digits.slice(padded.length) || padded) : Number(digits);
							setAdults(Math.min(6, Math.max(1, next)));
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-xs",
						children: "Crianças"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "number",
						min: 0,
						max: 4,
						value: children,
						onChange: (event) => setChildren(Math.max(0, Number(event.target.value) || 0))
					})]
				}),
				step === "vitrine" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "self-end",
					children: "Buscar"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "self-end pb-2 text-xs text-muted-foreground",
					children: "Datas atualizam o preço nesta tela."
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "-mx-4 flex min-w-0 flex-col sm:-mx-6",
		children: [
			step === "vitrine" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: config.photos[0],
				alt: "",
				className: "h-44 w-full object-cover sm:h-52"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky top-[3.6rem] z-30 bg-background",
				children: searchBar
			}),
			step === "voucher" && voucher ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-6 w-full max-w-xl px-4 pb-10 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StayVoucher, {
					reservation: voucher.reservation,
					roomLabel: voucher.roomLabel,
					hotelName: property.name,
					address: property.address,
					phone: property.phone,
					checkInTime: property.checkInTime,
					checkOutTime: property.checkOutTime,
					cancellationPolicy: property.cancellationPolicy,
					totais: voucher.totais,
					heading: voucher.reservation.status === "pendente" ? "Pré-reserva enviada" : "Reserva confirmada",
					emailedTo: voucher.reservation.guestEmail
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					className: "no-print mt-3 w-full",
					onClick: resetToVitrine,
					children: "Nova reserva"
				})]
			}) : step === "extras" && selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-6 w-full max-w-2xl px-4 pb-10 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mb-4 text-sm underline",
						onClick: () => setStep("vitrine"),
						children: "← Voltar aos quartos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-medium tracking-tight",
						children: "Experiências"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							selected.type,
							" · ",
							quote?.nights,
							" noites · diárias ",
							formatCurrency(quote?.total ?? 0),
							extrasTotal > 0 ? ` · extras ${formatCurrency(extrasTotal)}` : "",
							" · ",
							occupancyGridLabel(adults, children)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceCards, {
							extras: extraCatalog,
							extraIds,
							nights,
							guests: occupancy,
							searched,
							onToggle: toggleExtra
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						className: "mt-5 w-full",
						onClick: () => setStep("pagamento"),
						children: "Continuar"
					})
				]
			}) : step === "pagamento" && selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "mx-auto mt-6 w-full max-w-xl px-4 pb-10 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mb-4 text-sm underline",
						onClick: () => setStep("extras"),
						children: "← Voltar às experiências"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: selected.photo,
						alt: "",
						className: "mb-4 h-48 w-full rounded-xl object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-medium tracking-tight",
						children: selected.type
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							occupancy,
							" hóspede(s) · ",
							quote?.nights,
							" noites · diárias ",
							formatCurrency(quote?.total ?? 0),
							extrasTotal > 0 ? ` · experiências ${formatCurrency(extrasTotal)}` : "",
							payMode === "pix" ? ` · sinal ${formatCurrency(deposit)}` : "",
							" · ",
							occupancyGridLabel(adults, children)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: [
							"Check-in ",
							property.checkInTime,
							" · Check-out ",
							property.checkOutTime,
							". ",
							property.cancellationPolicy
						]
					}),
					quote && quote.offerDiscountTotal > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-emerald-700",
						children: [
							"Oferta ",
							quote.appliedOffers.map((item) => item.name).join(", "),
							": −",
							formatCurrency(quote.offerDiscountTotal),
							payMode === "pix" ? " (Pix aplicado)" : ""
						]
					}) : payMode === "checkin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Selecione Pix para aplicar regras exclusivas de pagamento."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nome" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									value: name,
									onChange: (event) => setName(event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "E-mail" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									type: "email",
									value: email,
									onChange: (event) => setEmail(event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Telefone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: phone,
									onChange: (event) => setPhone(event.target.value)
								})]
							}),
							extrasQuote.lines.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid gap-1 text-sm",
								children: extrasQuote.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [line.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-xs text-muted-foreground",
										children: [
											line.quantity,
											" × ",
											formatCurrency(line.unitPrice)
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: formatCurrency(line.total)
									})]
								}, line.id))
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
								className: "grid gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
										className: "text-sm font-medium",
										children: "Pagamento do sinal"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "radio",
											checked: payMode === "pix",
											onChange: () => setPayMode("pix")
										}), "Pix agora"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "radio",
											checked: payMode === "checkin",
											onChange: () => setPayMode("checkin")
										}), "Pagar no check-in"]
									})
								]
							}),
							payMode === "pix" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixCharge, {
								amount: deposit,
								pixKey: property.pixKey,
								payee: property.pixPayee || property.name,
								address: property.address,
								seed: pixSeed,
								description: `Sinal ${property.name}`
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Pague no app do banco. Só confirme depois que o Pix concluir."
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "A recepção confirma a pré-reserva. O pagamento entra na conta na chegada."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: create.isPending || selected.free === 0,
								children: payMode === "pix" ? "Já paguei o Pix" : "Enviar pré-reserva"
							})
						]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto w-full max-w-3xl px-4 py-6 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-medium tracking-tight",
						children: property.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [property.address, property.phone ? ` · ${property.phone}` : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							"Check-in ",
							property.checkInTime,
							" · Check-out ",
							property.checkOutTime
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display mt-8 text-xl font-medium tracking-tight",
						children: "Quartos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 grid gap-4",
						children: catalog.map((item) => {
							const overCapacity = !typeFitsParty(item, adults, children);
							const soldOut = searched && item.free === 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "grid overflow-hidden rounded-xl border border-border bg-card sm:grid-cols-[12rem_1fr]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: item.photo,
									alt: "",
									className: "h-40 w-full object-cover sm:h-full"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2 p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-display text-xl font-medium",
											children: item.type
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm",
											children: item.description
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												"Incluso: ",
												item.amenities.join(" · "),
												" · até ",
												item.maxAdults,
												" adulto(s)",
												item.maxChildren ? ` e ${item.maxChildren} criança(s)` : ""
											]
										}),
										overCapacity ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "rounded-md border-2 border-destructive bg-destructive/15 px-3 py-2 text-sm font-semibold text-destructive",
											children: "Capacidade excedida — este quarto não cabe neste grupo."
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid gap-0.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "font-display text-2xl font-medium tabular-nums",
													children: [formatCurrency(item.quote?.averageNight ?? 0), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "ml-1 text-sm font-normal text-muted-foreground",
														children: "/ noite"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-sm",
													children: [
														item.quote?.nights ?? nights,
														" noite(s) · ",
														formatCurrency(item.quote?.total ?? 0)
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-xs text-muted-foreground",
													children: occupancyGridLabel(adults, children)
												}),
												periodOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: item.free === 0 ? "text-sm font-medium text-destructive" : "text-sm font-medium",
													children: item.free === 0 ? "Esgotado neste período" : item.free === 1 ? "1 quarto livre" : `${item.free} quartos livres`
												}) : null
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											className: "justify-self-start",
											variant: soldOut || overCapacity ? "outline" : "default",
											disabled: soldOut || overCapacity,
											onClick: () => chooseType(item.type),
											children: overCapacity ? "Capacidade excedida" : soldOut ? "Indisponível" : "Continuar"
										})
									]
								})]
							}) }, item.type);
						})
					})
				]
			})
		]
	});
}
var SplitComponent = PublicShowcaseView;
//#endregion
export { SplitComponent as component };
