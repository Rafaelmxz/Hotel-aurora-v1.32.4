import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { O as formatCurrency, et as roomById, l as TODAY_ISO, lt as stayNights } from "./bookingStore-Bq0ubAXy.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { Y as getFolio, a as Input, et as listAllPagamentos, i as Label, o as Button, rt as listGuests } from "./router-D2QglEY4.mjs";
import { r as STATUS_LABEL, t as STATUS_BADGE } from "./status-lXSun_aS.mjs";
import { a as useReservations, i as usePatchReservation } from "./useReservations-BEok-WZp.mjs";
import { t as Badge } from "./badge-XwZ3ZDTe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reservas-CzWCGsOl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 10;
var ROOM_TYPES = [
	"todas",
	"Standard",
	"Luxo",
	"Suíte"
];
var STATUSES = [
	"todas",
	"confirmada",
	"pendente",
	"cancelada",
	"no-show",
	"check-in",
	"check-out"
];
var BULK_STATUSES = [
	"pendente",
	"confirmada",
	"check-in",
	"check-out",
	"cancelada"
];
function createdAtOf(row) {
	return row.createdAt ?? row.checkIn;
}
function isNoShow(row) {
	return row.status === "confirmada" && row.checkIn < TODAY_ISO && !row.actualCheckInAt;
}
function paymentOf(row) {
	const folio = getFolio(row.id);
	const paid = folio.totais.totalPagamentos;
	const saldo = folio.totais.saldo;
	return {
		paid,
		saldo,
		label: paid <= 0 ? "Pendente" : saldo <= 0 ? "Pago" : "Parcial"
	};
}
function exportCsv(rows) {
	const header = [
		"codigo",
		"hospede",
		"quarto",
		"check_in",
		"check_out",
		"noites",
		"total",
		"pagamento",
		"status",
		"origem"
	];
	const lines = rows.map((row) => {
		const room = roomById(row.roomId);
		const pay = paymentOf(row);
		return [
			row.id,
			row.guestName,
			room?.number ?? row.roomId,
			row.checkIn,
			row.checkOut,
			stayNights(row.checkIn, row.checkOut),
			row.totalAmount,
			pay.label,
			isNoShow(row) ? "no-show" : row.status,
			row.origin
		].join(";");
	});
	const blob = new Blob([[header.join(";"), ...lines].join("\n")], { type: "text/csv;charset=utf-8" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = "reservas.csv";
	link.click();
	URL.revokeObjectURL(url);
}
function BookingListView() {
	const { data: reservations = [] } = useReservations();
	const patch = usePatchReservation();
	const guests = listGuests();
	const origins = (0, import_react.useMemo)(() => ["todas", ...[...new Set(reservations.map((row) => row.origin))].sort()], [reservations]);
	const [filtersOpen, setFiltersOpen] = (0, import_react.useState)(true);
	const [keyword, setKeyword] = (0, import_react.useState)("");
	const [dateField, setDateField] = (0, import_react.useState)("checkIn");
	const [from, setFrom] = (0, import_react.useState)("");
	const [to, setTo] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("todas");
	const [roomType, setRoomType] = (0, import_react.useState)("todas");
	const [origin, setOrigin] = (0, import_react.useState)("todas");
	const [page, setPage] = (0, import_react.useState)(1);
	const [selected, setSelected] = (0, import_react.useState)([]);
	const [bulkStatus, setBulkStatus] = (0, import_react.useState)("confirmada");
	const rows = (0, import_react.useMemo)(() => {
		const q = keyword.trim().toLowerCase();
		return reservations.filter((row) => {
			const room = roomById(row.roomId);
			const guest = guests.find((item) => item.name === row.guestName);
			if (q) {
				if (!`${row.id} ${row.guestName} ${guest?.cpf ?? ""} ${row.guestEmail}`.toLowerCase().includes(q)) return false;
			}
			if (status === "no-show") {
				if (!isNoShow(row)) return false;
			} else if (status !== "todas" && row.status !== status) return false;
			if (roomType !== "todas" && room?.type !== roomType) return false;
			if (origin !== "todas" && row.origin !== origin) return false;
			const dateValue = dateField === "checkOut" ? row.checkOut : dateField === "createdAt" ? createdAtOf(row) : row.checkIn;
			if (from && dateValue < from) return false;
			if (to && dateValue > to) return false;
			return true;
		});
	}, [
		reservations,
		guests,
		keyword,
		status,
		roomType,
		origin,
		dateField,
		from,
		to
	]);
	(0, import_react.useEffect)(() => {
		setPage(1);
		setSelected([]);
	}, [
		keyword,
		status,
		roomType,
		origin,
		dateField,
		from,
		to
	]);
	const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
	const currentPage = Math.min(page, pages);
	const paged = rows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
	const allOnPageSelected = paged.length > 0 && paged.every((row) => selected.includes(row.id));
	const payments = listAllPagamentos();
	const totals = rows.reduce((acc, row) => {
		acc.amount += row.totalAmount;
		acc.paid += payments.filter((item) => item.reserva_id === row.id).reduce((sum, item) => sum + item.valor, 0);
		return acc;
	}, {
		amount: 0,
		paid: 0
	});
	function toggleAll() {
		if (allOnPageSelected) {
			setSelected((current) => current.filter((id) => !paged.some((row) => row.id === id)));
			return;
		}
		setSelected((current) => [.../* @__PURE__ */ new Set([...current, ...paged.map((row) => row.id)])]);
	}
	function toggleOne(id) {
		setSelected((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
	}
	async function applyBulk() {
		if (selected.length === 0) {
			toast.error("Selecione ao menos uma reserva.");
			return;
		}
		try {
			for (const id of selected) await patch.mutateAsync({
				id,
				status: bulkStatus
			});
			toast.success(`${selected.length} reserva(s) → ${STATUS_LABEL[bulkStatus]}`);
			setSelected([]);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível alterar o status em massa.");
		}
	}
	const fromItem = rows.length === 0 ? 0 : (currentPage - 1) * PAGE_SIZE + 1;
	const toItem = Math.min(currentPage * PAGE_SIZE, rows.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Recepção"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "Reservas"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "max-w-sm",
					placeholder: "Busca rápida: hóspede, CPF ou código",
					value: keyword,
					onChange: (event) => setKeyword(event.target.value)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-card shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex w-full items-center justify-between px-5 py-3 text-sm font-medium",
					onClick: () => setFiltersOpen((open) => !open),
					children: ["Filtros avançados", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: filtersOpen ? "Recolher" : "Expandir"
					})]
				}), filtersOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 border-t border-border px-5 py-4 sm:grid-cols-2 lg:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Intervalo por" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
								value: dateField,
								onChange: (event) => setDateField(event.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "checkIn",
										children: "Check-in"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "checkOut",
										children: "Check-out"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "createdAt",
										children: "Data de criação"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "De" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: from,
								onChange: (event) => setFrom(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Até" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: to,
								onChange: (event) => setTo(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Status" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
								value: status,
								onChange: (event) => setStatus(event.target.value),
								children: STATUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item,
									children: item === "todas" ? "Todas" : item === "no-show" ? "No-show" : STATUS_LABEL[item]
								}, item))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Tipo de acomodação" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
								value: roomType,
								onChange: (event) => setRoomType(event.target.value),
								children: ROOM_TYPES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item,
									children: item === "todas" ? "Todas" : item
								}, item))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 lg:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Origem / canal (UTM)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
								value: origin,
								onChange: (event) => setOrigin(event.target.value),
								children: origins.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: item,
									children: item === "todas" ? "Todas" : item
								}, item))
							})]
						})
					]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 rounded-xl bg-card px-4 py-3 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm text-muted-foreground",
						children: [selected.length, " selecionada(s)"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-10 rounded-md border border-input bg-card px-3 text-sm",
						value: bulkStatus,
						onChange: (event) => setBulkStatus(event.target.value),
						children: BULK_STATUSES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item,
							children: STATUS_LABEL[item]
						}, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => void applyBulk(),
						disabled: patch.isPending,
						children: "Alterar status"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						onClick: () => {
							const pack = reservations.filter((row) => selected.includes(row.id));
							if (pack.length === 0) {
								toast.error("Selecione reservas para exportar.");
								return;
							}
							exportCsv(pack);
							toast.success("CSV exportado");
						},
						children: "Exportar selecionados"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-x-auto rounded-xl bg-card shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[64rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "bg-secondary text-xs tracking-wide text-muted-foreground uppercase",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: allOnPageSelected,
									onChange: toggleAll,
									"aria-label": "Selecionar página"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Código"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Hóspede"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Quarto"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Check-in / Out"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Noites"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Total"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Pagamento"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-3 font-medium",
								children: "Origem"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: paged.map((row) => {
						const room = roomById(row.roomId);
						const pay = paymentOf(row);
						const noShow = isNoShow(row);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: selected.includes(row.id),
										onChange: () => toggleOne(row.id),
										"aria-label": `Selecionar ${row.id}`
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 font-medium",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/calendario",
										search: { reserva: row.id },
										className: "underline underline-offset-2",
										children: row.id
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/calendario",
										search: { reserva: row.id },
										className: "underline underline-offset-2",
										children: row.guestName
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: room ? `${room.number} · ${room.type}` : row.roomId
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-3 py-3 text-muted-foreground",
									children: [
										row.checkIn,
										" → ",
										row.checkOut
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 tabular-nums",
									children: stayNights(row.checkIn, row.checkOut)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 tabular-nums",
									children: formatCurrency(row.totalAmount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: pay.label === "Pago" ? "checkout" : pay.label === "Parcial" ? "pending" : "cancelled",
										children: pay.label
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: noShow ? "cancelled" : STATUS_BADGE[row.status],
										children: noShow ? "No-show" : STATUS_LABEL[row.status]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-3 py-3 text-muted-foreground",
									children: row.origin
								})
							]
						}, row.id);
					}) })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3 border-t border-border px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: [
							"Mostrando ",
							fromItem,
							"–",
							toItem,
							" de ",
							rows.length,
							" · Total ",
							formatCurrency(totals.amount),
							" · Recebido ",
							formatCurrency(totals.paid)
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								disabled: currentPage <= 1,
								onClick: () => setPage((value) => value - 1),
								children: "Anterior"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: [
									currentPage,
									" / ",
									pages
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								disabled: currentPage >= pages,
								onClick: () => setPage((value) => value + 1),
								children: "Próxima"
							})
						]
					})]
				})]
			})
		]
	});
}
var SplitComponent = BookingListView;
//#endregion
export { SplitComponent as component };
