import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { O as formatCurrency, U as normalizeExtras, n as EXTRA_UNIT_LABEL } from "./bookingStore-Bq0ubAXy.mjs";
import { t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Input, i as Label, o as Button, p as useProperty } from "./router-D2QglEY4.mjs";
import { t as Textarea } from "./textarea-CJRv6rNU.mjs";
import { n as useSaveBookingConfig, t as useBookingConfig } from "./useBookingEngine-1wAIPgj0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reservas-diretas-CGZSGPEV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BookingEngineModal({ open, onOpenChange }) {
	const { data: config } = useBookingConfig();
	const save = useSaveBookingConfig();
	const [photos, setPhotos] = (0, import_react.useState)(config.photos.join("\n"));
	const [pixKey, setPixKey] = (0, import_react.useState)(config.pixKey);
	const [deposit, setDeposit] = (0, import_react.useState)(String(config.depositPercent));
	const [extras, setExtras] = (0, import_react.useState)(() => normalizeExtras(config.extras));
	(0, import_react.useEffect)(() => {
		if (!open) return;
		setPhotos(config.photos.join("\n"));
		setPixKey(config.pixKey);
		setDeposit(String(config.depositPercent));
		setExtras(normalizeExtras(config.extras));
	}, [open, config]);
	async function onSubmit(event) {
		event.preventDefault();
		try {
			await save.mutateAsync({
				...config,
				photos: photos.split("\n"),
				pixKey,
				depositPercent: Number(deposit) || 0,
				extras: normalizeExtras(extras)
			});
			toast.success("Página pública atualizada");
			onOpenChange(false);
		} catch {
			toast.error("Não foi possível salvar.");
		}
	}
	async function copyLink() {
		const url = `${window.location.origin}/reservar`;
		await navigator.clipboard.writeText(url);
		toast.success("Link copiado");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-[60] bg-foreground/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed top-1/2 left-1/2 z-[70] max-h-[90dvh] w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-xl border border-border bg-card p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Configurar página pública"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Fotos, Pix e experiências da reserva. Horários e cancelamento ficam em Hotel."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
					className: "absolute top-4 right-4 opacity-70 hover:opacity-100",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Fechar"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "photos",
								children: "Fotos (uma URL por linha)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "photos",
								rows: 4,
								value: photos,
								onChange: (event) => setPhotos(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "rounded-lg bg-secondary/50 px-3 py-2 text-xs text-muted-foreground",
							children: [
								"Check-in ",
								config.checkInTime,
								" · check-out ",
								config.checkOutTime,
								". ",
								config.cancellationPolicy,
								" ",
								"Alterar em Hotel."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Chave Pix" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: pixKey,
								onChange: (event) => setPixKey(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Sinal de garantia (%)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "numeric",
								value: deposit,
								onChange: (event) => setDeposit(event.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "grid gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
								className: "text-sm font-medium",
								children: "Experiências no site"
							}), extras.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2 rounded-lg bg-secondary/40 p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: item.enabled,
											onChange: (event) => setExtras((current) => current.map((row, rowIndex) => rowIndex === index ? {
												...row,
												enabled: event.target.checked
											} : row))
										}), "Oferecer na reserva"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: item.name,
										onChange: (event) => setExtras((current) => current.map((row, rowIndex) => rowIndex === index ? {
											...row,
											name: event.target.value
										} : row))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-[1fr_auto] items-end gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												className: "text-xs",
												children: "Preço (R$)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												inputMode: "numeric",
												value: String(item.price),
												onChange: (event) => setExtras((current) => current.map((row, rowIndex) => rowIndex === index ? {
													...row,
													price: Number(event.target.value) || 0
												} : row))
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "pb-2 text-xs text-muted-foreground",
											children: EXTRA_UNIT_LABEL[item.unit]
										})]
									})
								]
							}, item.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: () => void copyLink(),
								children: "Copiar link público"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: save.isPending,
								children: "Salvar"
							})]
						})
					]
				})
			]
		})] })
	});
}
function BookingEngineView() {
	const { data: config } = useBookingConfig();
	const { data: property } = useProperty();
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Configuração"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-medium tracking-tight",
						children: "Motor de reservas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							"Página do ",
							property.name,
							" para o hóspede reservar sozinho."
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/reservar",
							children: "Abrir visão do hóspede"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setOpen(true),
						children: "Configurar página"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: config.photos.map((src) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: "",
					className: "h-40 w-full rounded-xl object-cover shadow-[var(--shadow-border)]"
				}, src))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid gap-2 rounded-xl bg-card p-5 text-sm shadow-[var(--shadow-border)] sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Check-in / Check-out"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "sm:text-right",
						children: [
							config.checkInTime,
							" / ",
							config.checkOutTime
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Cancelamento gratuito"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "sm:text-right",
						children: [property.cancelFreeHours, "h antes"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Pix"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "sm:text-right",
						children: config.pixKey
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Sinal"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "sm:text-right",
						children: [config.depositPercent, "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Cancelamento"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "sm:col-span-2",
						children: [
							property.cancellationPolicy,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Editar em Hotel."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: "Experiências"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "sm:col-span-2",
						children: (config.extras ?? []).filter((item) => item.enabled).length ? (config.extras ?? []).filter((item) => item.enabled).map((item) => `${item.name} · ${formatCurrency(item.price)} ${EXTRA_UNIT_LABEL[item.unit]}`).join(" · ") : "Nenhuma experiência no site"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookingEngineModal, {
				open,
				onOpenChange: setOpen
			})
		]
	});
}
var SplitComponent = BookingEngineView;
//#endregion
export { SplitComponent as component };
