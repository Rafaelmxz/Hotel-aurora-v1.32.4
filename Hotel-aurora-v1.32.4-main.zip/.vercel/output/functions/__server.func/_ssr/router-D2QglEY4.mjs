import { o as __toESM } from "../_runtime.mjs";
import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as useRouter, _ as createRootRoute, b as Navigate, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as getRouteApi, y as Link, z as redirect } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay, i as DialogDescription, l as Slot, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { i as format, p as differenceInCalendarDays, t as ptBR, y as addDays } from "../_libs/date-fns.mjs";
import { $ as reservations, A as getBookingConfig, G as parseISODate, H as normalizeEmail, I as isStayActiveOn, K as parseVault, L as listSaleCloses, M as getProperty, Q as replaceSaleCloses, X as replaceBookingConfig, Z as replaceProperty, _ as assertValidPeriod, c as TODAY, d as absorbSiteBookings, dt as unionVaultReservations, et as roomById, g as assertValidEmail, l as TODAY_ISO, lt as stayNights, m as assertNoOverbooking, nt as rooms, ot as saveProperty, q as propertyKeys, ut as toISODate, x as bookingKeys, y as availableRoomsByType } from "./bookingStore-Bq0ubAXy.mjs";
import { F as object, M as literal, P as number, R as string, z as union } from "../_libs/@better-auth/core+[...].mjs";
import { i as signOut, t as authClient } from "./client-CVqXY6bk.mjs";
import { a as hasGateSessionMarker, n as auth } from "./server-DhL3ZIaK.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { C as ChevronLeft, D as Building2, E as CalendarDays, O as BookOpen, S as ChevronRight, T as ChartColumn, _ as House, a as TriangleAlert, b as FileChartColumnIncreasing, c as Sparkles, i as Users, l as Shield, r as Wallet, s as Tags, t as X, v as Globe } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, r as QueryClientProvider, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as Provider } from "../_libs/radix-ui__react-tooltip.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-C_uf36nf.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/guestStore-DkAAJeSo.js
var offerKeys = { all: ["offers"] };
function withAlias(offer) {
	return {
		...offer,
		roomTypes: [...offer.roomTypes],
		weekdays: [...offer.weekdays],
		percent: offer.kind === "percent" ? offer.value : 0
	};
}
var offers = [
	{
		id: "off-pix",
		name: "Desconto Pix",
		kind: "percent",
		value: 5,
		percent: 5,
		start: "2026-01-01",
		end: "2026-12-31",
		roomTypes: [],
		weekdays: [],
		pixOnly: true,
		minNights: 0,
		active: true
	},
	{
		id: "off-semana",
		name: "30% off Segunda a Quinta",
		kind: "percent",
		value: 30,
		percent: 30,
		start: "2026-01-01",
		end: "2026-12-31",
		roomTypes: ["Standard", "Luxo"],
		weekdays: [
			1,
			2,
			3,
			4
		],
		pixOnly: false,
		minNights: 0,
		active: true
	},
	{
		id: "off-3noites",
		name: "Estadia 3 noites",
		kind: "percent",
		value: 10,
		percent: 10,
		start: "2026-01-01",
		end: "2026-12-31",
		roomTypes: [],
		weekdays: [],
		pixOnly: false,
		minNights: 3,
		active: true
	}
].map(withAlias);
var seq$1 = offers.length + 1;
function listOffers() {
	return offers.map(withAlias);
}
function replaceOffers(rows) {
	offers = rows.map(withAlias);
	seq$1 = offers.length + 1;
}
function addOffer(input) {
	const offer = withAlias({
		...input,
		id: `off-${String(seq$1++).padStart(3, "0")}`,
		name: input.name.trim(),
		percent: 0
	});
	offers = [...offers, offer];
	return withAlias(offer);
}
function patchOffer(id, patch) {
	const index = offers.findIndex((row) => row.id === id);
	if (index < 0) throw new Error("Oferta não encontrada");
	const next = withAlias({
		...offers[index],
		...patch
	});
	offers = [
		...offers.slice(0, index),
		next,
		...offers.slice(index + 1)
	];
	return withAlias(next);
}
function removeOffer(id) {
	offers = offers.filter((row) => row.id !== id);
}
function offerDiscount(amount, offer) {
	if (offer.kind === "percent") return Math.round(amount * (offer.value / 100));
	return Math.min(amount, Math.round(offer.value));
}
function offerApplies(offer, input) {
	if (!offer.active) return false;
	if (input.dateIso < offer.start || input.dateIso > offer.end) return false;
	if (offer.roomTypes.length > 0 && !offer.roomTypes.includes(input.roomType)) return false;
	if (offer.weekdays.length > 0 && !offer.weekdays.includes(input.weekday)) return false;
	if (offer.pixOnly && !input.pix) return false;
	if (offer.minNights > 0 && (input.nights ?? 0) < offer.minNights) return false;
	return true;
}
function strongestOffer(amount, candidates) {
	if (candidates.length === 0) return void 0;
	return candidates.reduce((best, current) => offerDiscount(amount, current) >= offerDiscount(amount, best) ? current : best);
}
var rateKeys = {
	all: ["rates"],
	seasons: ["rates", "seasons"],
	packages: ["rates", "packages"],
	promos: ["rates", "promos"]
};
var OCCUPANCY_FIELDS = [
	"adl1",
	"adl2",
	"adl3",
	"adl4",
	"chd1",
	"chd2",
	"plusAdl",
	"plusChd"
];
var OCCUPANCY_LABEL = {
	adl1: "1 ADL",
	adl2: "2 ADL",
	adl3: "3 ADL",
	adl4: "4 ADL",
	chd1: "1 CHD",
	chd2: "2 CHD",
	plusAdl: "+ADL",
	plusChd: "+CHD"
};
function money(value, fallback) {
	const n = Number(value);
	if (!Number.isFinite(n)) return fallback;
	return Math.max(0, Math.round(n));
}
function fillBand(raw = {}) {
	const pax1Cafe = money(raw.pax1Cafe, 0);
	const pax2Cafe = money(raw.pax2Cafe, pax1Cafe);
	return {
		pax1Cafe,
		pax1Pensao: money(raw.pax1Pensao, pax1Cafe),
		pax2Cafe,
		pax2Pensao: money(raw.pax2Pensao, pax2Cafe),
		adl1: money(raw.adl1, pax1Cafe),
		adl2: money(raw.adl2, pax2Cafe),
		adl3: money(raw.adl3, Math.round(pax2Cafe * 1.2)),
		adl4: money(raw.adl4, Math.round(pax2Cafe * 1.4)),
		chd1: money(raw.chd1, Math.max(40, Math.round(pax2Cafe * .12))),
		chd2: money(raw.chd2, Math.max(70, Math.round(pax2Cafe * .22))),
		plusAdl: money(raw.plusAdl, Math.max(40, Math.round(pax2Cafe * .15))),
		plusChd: money(raw.plusChd, Math.max(30, Math.round(pax2Cafe * .1)))
	};
}
function band(pax1Cafe, pax1Pensao, pax2Cafe, pax2Pensao) {
	return fillBand({
		pax1Cafe,
		pax1Pensao,
		pax2Cafe,
		pax2Pensao
	});
}
function withLegacy(type, weekday, weekend, sitePercent = 0) {
	const week = fillBand(weekday);
	const end = fillBand(weekend);
	return {
		type,
		weekday: week,
		weekend: end,
		weekdayRate: week.adl2,
		weekendRate: end.adl2,
		sitePercent: clampSitePercent(sitePercent)
	};
}
function clampSitePercent(value) {
	const n = Number(value);
	if (!Number.isFinite(n)) return 0;
	return Math.min(80, Math.max(-80, Math.round(n)));
}
var CATEGORY_SEED = [
	withLegacy("Standard", band(280, 340, 320, 390), band(340, 400, 390, 470)),
	withLegacy("Luxo", band(470, 550, 540, 640), band(590, 680, 680, 790)),
	withLegacy("Suíte", band(780, 890, 890, 1040), band(980, 1120, 1120, 1290))
];
var SEASON_SEED = [
	{
		id: "sea-reveillon",
		name: "Réveillon",
		start: "2026-12-28",
		end: "2027-01-02",
		modifier: "percent",
		value: 40,
		minNights: 3
	},
	{
		id: "sea-carnaval",
		name: "Carnaval",
		start: "2026-02-14",
		end: "2026-02-18",
		modifier: "percent",
		value: 30,
		minNights: 3
	},
	{
		id: "sea-julho",
		name: "Alta temporada julho",
		start: "2026-07-01",
		end: "2026-07-31",
		modifier: "fixed",
		value: 80,
		minNights: 2
	}
];
var PACKAGE_SEED = [{
	id: "pkg-lua",
	name: "Lua de mel",
	start: "2026-09-11",
	end: "2026-09-14",
	minNights: 2,
	roomType: "Suíte"
}, {
	id: "pkg-feriado",
	name: "Feriado prolongado",
	start: "2026-11-14",
	end: "2026-11-16",
	minNights: 2,
	roomType: "todas"
}];
var PROMO_SEED = [{
	id: "pro-vip",
	code: "CLIENTEVIP",
	kind: "percent",
	value: 10,
	start: "2026-01-01",
	end: "2026-12-31",
	usageLimit: 30,
	usageCount: 4,
	active: true
}, {
	id: "pro-noiva",
	code: "NOIVAVIP",
	kind: "percent",
	value: 15,
	start: "2026-01-01",
	end: "2026-12-31",
	usageLimit: 10,
	usageCount: 1,
	active: true
}];
var categories = CATEGORY_SEED.map((row) => ({
	...row,
	weekday: { ...row.weekday },
	weekend: { ...row.weekend }
}));
var seasons = SEASON_SEED.map((row) => ({ ...row }));
var packages = PACKAGE_SEED.map((row) => ({ ...row }));
var promos = PROMO_SEED.map((row) => ({ ...row }));
var seasonSeq = seasons.length + 1;
var packageSeq = packages.length + 1;
var promoSeq = promos.length + 1;
function listCategoryRates() {
	return categories.map((row) => ({
		...row,
		weekday: fillBand(row.weekday),
		weekend: fillBand(row.weekend)
	}));
}
function replaceRates(next) {
	categories = next.categories.map((row) => withLegacy(row.type, row.weekday, row.weekend, row.sitePercent));
	seasons = next.seasons.map((row) => ({ ...row }));
	packages = next.packages.map((row) => ({ ...row }));
	promos = next.promos.map((row) => ({ ...row }));
	seasonSeq = seasons.length + 1;
	packageSeq = packages.length + 1;
	promoSeq = promos.length + 1;
}
function occupancyNightRate(category, weekend, adults, children) {
	const band = fillBand(weekend ? category.weekend : category.weekday);
	const a = Math.max(1, Math.round(adults) || 1);
	const c = Math.max(0, Math.round(children) || 0);
	const adl = a <= 1 ? band.adl1 : a === 2 ? band.adl2 : a === 3 ? band.adl3 : band.adl4;
	const extraAdl = a > 4 ? (a - 4) * band.plusAdl : 0;
	const chd = c <= 0 ? 0 : c === 1 ? band.chd1 : band.chd2;
	const extraChd = c > 2 ? (c - 2) * band.plusChd : 0;
	return adl + extraAdl + chd + extraChd;
}
function patchCategoryRate(type, patch) {
	const index = categories.findIndex((row) => row.type === type);
	if (index < 0) throw new Error("Categoria não encontrada");
	const current = categories[index];
	const weekday = fillBand({
		...current.weekday,
		...patch.weekday
	});
	const weekend = fillBand({
		...current.weekend,
		...patch.weekend
	});
	if (patch.weekdayRate != null) {
		weekday.adl2 = money(patch.weekdayRate, weekday.adl2);
		weekday.pax2Cafe = weekday.adl2;
	}
	if (patch.weekendRate != null) {
		weekend.adl2 = money(patch.weekendRate, weekend.adl2);
		weekend.pax2Cafe = weekend.adl2;
	}
	const next = withLegacy(type, weekday, weekend, patch.sitePercent != null ? patch.sitePercent : current.sitePercent);
	categories = [
		...categories.slice(0, index),
		next,
		...categories.slice(index + 1)
	];
	return {
		...next,
		weekday: { ...next.weekday },
		weekend: { ...next.weekend }
	};
}
function listSeasons() {
	return seasons.map((row) => ({ ...row }));
}
function addSeason(input) {
	const season = {
		...input,
		id: `sea-${String(seasonSeq++).padStart(3, "0")}`,
		name: input.name.trim()
	};
	seasons = [...seasons, season];
	return { ...season };
}
function removeSeason(id) {
	seasons = seasons.filter((row) => row.id !== id);
}
function listPackages() {
	return packages.map((row) => ({ ...row }));
}
function addPackage(input) {
	const item = {
		...input,
		id: `pkg-${String(packageSeq++).padStart(3, "0")}`,
		name: input.name.trim()
	};
	packages = [...packages, item];
	return { ...item };
}
function removePackage(id) {
	packages = packages.filter((row) => row.id !== id);
}
function listPromos() {
	return promos.map((row) => ({ ...row }));
}
function addPromo(input) {
	const promo = {
		...input,
		id: `pro-${String(promoSeq++).padStart(3, "0")}`,
		code: input.code.trim().toUpperCase(),
		usageCount: 0
	};
	promos = [...promos, promo];
	return { ...promo };
}
function removePromo(id) {
	promos = promos.filter((row) => row.id !== id);
}
function findPromo(code) {
	const normalized = code.trim().toUpperCase();
	return promos.find((row) => row.code === normalized);
}
function resolveAdults(options) {
	const raw = options.adults ?? options.pax ?? 2;
	return Math.min(6, Math.max(1, Math.round(raw) || 1));
}
function resolveChildren(options) {
	return Math.min(4, Math.max(0, Math.round(options.children ?? 0) || 0));
}
function isWeekendNight(date) {
	const day = date.getDay();
	return day === 0 || day === 5 || day === 6;
}
function toISO(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function seasonsOn(dateIso, seasons = listSeasons()) {
	return seasons.filter((season) => dateIso >= season.start && dateIso <= season.end);
}
function paintNight(roomType, dateIso, options = {}) {
	const weekend = isWeekendNight(parseISODate(dateIso));
	const adults = resolveAdults(options);
	const children = resolveChildren(options);
	const category = (options.categories ?? listCategoryRates()).find((row) => row.type === roomType);
	const base = category ? occupancyNightRate(category, weekend, adults, children) : 0;
	const season = strongestSeason(base, seasonsOn(dateIso, options.seasons ?? listSeasons()));
	return {
		date: dateIso,
		weekend,
		base,
		amount: season ? applySeason(base, season) : base,
		season
	};
}
function applySeason(base, season) {
	if (season.modifier === "percent") return Math.round(base * (1 + season.value / 100));
	return Math.round(base + season.value);
}
function strongestSeason(base, seasons) {
	if (seasons.length === 0) return void 0;
	return seasons.reduce((best, current) => applySeason(base, current) >= applySeason(base, best) ? current : best);
}
function packagesOn(checkIn, checkOut, roomType) {
	return listPackages().filter((item) => {
		if (item.roomType !== "todas" && item.roomType !== roomType) return false;
		return checkIn < item.end && checkOut > item.start;
	});
}
function applyPromoAmount(subtotal, promo) {
	if (promo.kind === "percent") return Math.round(subtotal * (promo.value / 100));
	return Math.min(subtotal, Math.round(promo.value));
}
function quoteStay(roomType, checkIn, checkOut, options = {}) {
	const adults = resolveAdults(options);
	const children = resolveChildren(options);
	const pax = adults;
	const mealPlan = options.mealPlan ?? "cafe";
	const start = parseISODate(checkIn);
	const end = parseISODate(checkOut);
	const nights = Math.max(1, differenceInCalendarDays(end, start));
	const category = (options.categories ?? listCategoryRates()).find((row) => row.type === roomType);
	const allSeasons = listSeasons();
	const nightsDetail = [];
	for (let i = 0; i < nights; i += 1) {
		const date = addDays(start, i);
		const dateIso = toISO(date);
		const weekendNight = isWeekendNight(date);
		const raw = category ? occupancyNightRate(category, weekendNight, adults, children) : 0;
		const siteCut = options.segment === "site" ? Math.round(category?.sitePercent ?? 0) : 0;
		const base = Math.max(0, Math.round(raw * (1 + siteCut / 100)));
		const season = strongestSeason(base, seasonsOn(dateIso, allSeasons));
		let amount = season ? applySeason(base, season) : base;
		const offer = strongestOffer(amount, listOffers().filter((item) => offerApplies(item, {
			dateIso,
			weekday: date.getDay(),
			roomType,
			pix: options.pix,
			nights
		})));
		if (offer) amount = Math.max(0, amount - offerDiscount(amount, offer));
		nightsDetail.push({
			date: dateIso,
			base,
			weekend: weekendNight,
			season,
			offer,
			amount
		});
	}
	const subtotal = nightsDetail.reduce((sum, night) => sum + night.amount, 0);
	const matchedPackages = packagesOn(checkIn, checkOut, roomType);
	const minNightsRequired = Math.max(1, ...nightsDetail.map((night) => night.season?.minNights ?? 1), ...matchedPackages.map((item) => item.minNights));
	let promo;
	let discount = 0;
	if (options.promoCode) {
		const found = findPromo(options.promoCode);
		const stayDay = checkIn;
		if (found && found.active && found.usageCount < found.usageLimit && stayDay >= found.start && stayDay <= found.end) {
			promo = found;
			discount = applyPromoAmount(subtotal, found);
		}
	}
	const total = Math.max(0, subtotal - discount);
	const appliedOffers = [...new Map(nightsDetail.flatMap((night) => night.offer ? [night.offer] : []).map((item) => [item.id, item])).values()];
	const offerDiscountTotal = nightsDetail.reduce((sum, night) => {
		if (!night.offer) return sum;
		return sum + ((night.season ? applySeason(night.base, night.season) : night.base) - night.amount);
	}, 0);
	return {
		roomType,
		checkIn,
		checkOut,
		nights,
		nightsDetail,
		subtotal,
		discount,
		total,
		averageNight: Math.round(total / nights),
		minNightsRequired,
		minNightsOk: nights >= minNightsRequired,
		mealPlan,
		pax,
		adults,
		children,
		promo,
		packages: matchedPackages,
		appliedOffers,
		offerDiscountTotal
	};
}
/**
* Bloqueio de quarto no mapa.
* Tela: criar/remover na aba Hotel e faixa no /calendario, com motivo curto.
* Proibido: hóspede, folio, Pix, check-in, voucher, pré-reserva.
* Store que grava: este arquivo → cofre (`blocks`).
* Não ocupa ADR; ocupa a vaga (mapa + site).
* Não mistura com tarifário, OTA nem Experiências.
*/
var blockKeys = { all: ["room-blocks"] };
var store$2 = [];
function listBlocks() {
	return store$2.map((row) => ({ ...row }));
}
function replaceBlocks(rows) {
	store$2 = Array.isArray(rows) ? rows.map((row) => ({ ...row })) : [];
}
function newBlockId() {
	try {
		return `blk-${crypto.randomUUID()}`;
	} catch {
		return `blk-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
	}
}
function createBlock(input, reservations) {
	const reason = input.reason.trim();
	if (reason.length < 2 || reason.length > 80) throw new Error("Informe um motivo curto (2 a 80 caracteres).");
	assertValidPeriod(input.checkIn, input.checkOut);
	assertNoOverbooking(reservations, {
		roomId: input.roomId,
		checkIn: input.checkIn,
		checkOut: input.checkOut
	}, store$2);
	const block = {
		id: newBlockId(),
		roomId: input.roomId,
		checkIn: input.checkIn,
		checkOut: input.checkOut,
		reason,
		createdAt: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
	};
	store$2 = [...store$2, block];
	return { ...block };
}
function removeBlock(id) {
	const next = store$2.filter((row) => row.id !== id);
	if (next.length === store$2.length) throw new Error("Bloqueio não encontrado");
	store$2 = next;
}
var ROOM_CATALOG = [
	{
		type: "Standard",
		photo: "https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=1200&q=60",
		capacity: 3,
		description: "Quarto aconchegante com cama queen, mesa de trabalho e vista para o jardim.",
		highlights: [
			"Cama queen",
			"Banheiro privativo",
			"Frigobar"
		]
	},
	{
		type: "Luxo",
		photo: "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=60",
		capacity: 3,
		description: "Ambiente amplo com varanda, cama king e amenidades de spa.",
		highlights: [
			"Cama king",
			"Varanda",
			"Banheira"
		]
	},
	{
		type: "Suíte",
		photo: "https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=60",
		capacity: 4,
		description: "Suíte master com sala de estar, hidromassagem e vista panorâmica.",
		highlights: [
			"Sala de estar",
			"Hidromassagem",
			"Até 4 pessoas"
		]
	}
];
var FALLBACK_STORY = {
	photo: ROOM_CATALOG[0].photo,
	blurb: "Serviço extra cobrado na conta da reserva.",
	included: ""
};
var EXTRA_STORIES = {
	cafe: {
		photo: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1200&q=60",
		blurb: "Mesa no restaurante das 7h às 10h, com pães, frutas, sucos e café. Cobra-se por hóspede da reserva.",
		included: "O café da diária continua incluso; este é o serviço extra, cobrado à parte."
	},
	traslado: {
		photo: "https://images.unsplash.com/photo-1544620341-11cb2cd57ee8?auto=format&fit=crop&w=1200&q=60",
		blurb: "Van particular no check-in ou no check-out. Combine o horário com a recepção depois de confirmar. Valor único por estadia.",
		included: "Motorista e espera de até 45 minutos no aeroporto."
	},
	cama: {
		photo: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=1200&q=60",
		blurb: "Berço ou cama extra montada no quarto antes da chegada, sujeito à capacidade. Cobra-se por noite.",
		included: "Roupa de cama e montagem no horário combinado."
	}
};
function extraStory(id) {
	return EXTRA_STORIES[id] ?? FALLBACK_STORY;
}
var roomTypeKeys = { all: ["room-types"] };
var ORDER = [
	"Standard",
	"Luxo",
	"Suíte"
];
var DEFAULT_OCCUPANCY = {
	Standard: {
		maxAdults: 2,
		maxChildren: 1
	},
	Luxo: {
		maxAdults: 2,
		maxChildren: 1
	},
	Suíte: {
		maxAdults: 2,
		maxChildren: 2
	}
};
function seed() {
	return ORDER.map((type) => {
		const item = ROOM_CATALOG.find((row) => row.type === type);
		return {
			type,
			photo: item.photo,
			description: item.description,
			amenities: [...item.highlights],
			...DEFAULT_OCCUPANCY[type]
		};
	});
}
var DEFAULTS = seed();
function clamp(value, min, max, fallback) {
	const n = Number(value);
	if (!Number.isFinite(n)) return fallback;
	return Math.min(max, Math.max(min, Math.round(n)));
}
function occupancyOfType(row) {
	return row.maxAdults + row.maxChildren;
}
function typeHoldsParty(row, adults, children) {
	const a = Math.max(1, adults);
	const c = Math.max(0, children);
	return a <= row.maxAdults && c <= row.maxChildren && a + c <= occupancyOfType(row);
}
function assertTypeHoldsParty(type, adults, children) {
	const row = roomTypeByName(type);
	if (!typeHoldsParty(row, adults, children)) throw new Error(`Capacidade excedida: ${type} cabe ${row.maxAdults} adulto(s) e ${row.maxChildren} criança(s).`);
}
function normalizeRoomTypes(raw) {
	const byType = new Map((raw ?? []).map((row) => [row.type, row]));
	return DEFAULTS.map((def) => {
		const row = byType.get(def.type);
		const amenities = (row?.amenities ?? def.amenities).map((item) => item.trim()).filter(Boolean).slice(0, 8);
		return {
			type: def.type,
			photo: row?.photo?.trim() || def.photo,
			description: row?.description?.trim() || def.description,
			amenities: amenities.length ? amenities : [...def.amenities],
			maxAdults: clamp(row?.maxAdults, 1, 6, def.maxAdults),
			maxChildren: clamp(row?.maxChildren, 0, 4, def.maxChildren)
		};
	});
}
var store$1 = seed();
function listRoomTypes() {
	store$1 = normalizeRoomTypes(store$1);
	return store$1.map((row) => ({
		...row,
		amenities: [...row.amenities]
	}));
}
function replaceRoomTypes(rows) {
	store$1 = normalizeRoomTypes(rows);
}
function saveRoomTypes(rows) {
	store$1 = normalizeRoomTypes(rows);
	return listRoomTypes();
}
function roomTypeByName(type) {
	return listRoomTypes().find((row) => row.type === type) ?? normalizeRoomTypes()[0];
}
function typeFitsParty(row, adults, children) {
	return adults <= row.maxAdults && children <= row.maxChildren;
}
var reservationKeys = { all: ["reservations"] };
var store$3 = reservations.map((row) => ({ ...row }));
function applyQuote(reservation) {
	const room = roomById(reservation.roomId);
	if (!room) return reservation;
	const quote = quoteStay(room.type, reservation.checkIn, reservation.checkOut);
	return {
		...reservation,
		nightlyRate: quote.averageNight,
		totalAmount: quote.total
	};
}
function listReservations() {
	return store$3.map((row) => ({ ...row }));
}
function replaceReservations(rows) {
	store$3 = rows.map((row) => ({ ...row }));
	createSeq = store$3.length + 1;
}
function patchReservation(id, patch) {
	const index = store$3.findIndex((row) => row.id === id);
	if (index < 0) throw new Error("Reserva não encontrada");
	let next = {
		...store$3[index],
		...patch
	};
	if (patch.roomId || patch.checkIn || patch.checkOut) next = applyQuote(next);
	store$3 = [
		...store$3.slice(0, index),
		next,
		...store$3.slice(index + 1)
	];
	return { ...next };
}
function quoteNewReservation(roomId, checkIn, checkOut, options = {}) {
	const room = roomById(roomId);
	if (!room) throw new Error("Quarto não encontrado");
	return quoteStay(room.type, checkIn, checkOut, options);
}
var createSeq = store$3.length + 1;
function newStayId() {
	try {
		return `res-${crypto.randomUUID()}`;
	} catch {
		return `res-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
	}
}
function createReservation(input) {
	const room = roomById(input.roomId);
	if (!room) throw new Error("Quarto não encontrado");
	const children = Math.max(0, input.children ?? 0);
	const adults = Math.max(1, input.adults ?? input.guests ?? 1);
	if ((input.origin ?? "Balcão") === "Link público") assertTypeHoldsParty(room.type, adults, children);
	assertValidPeriod(input.checkIn, input.checkOut);
	assertNoOverbooking(store$3, {
		roomId: input.roomId,
		checkIn: input.checkIn,
		checkOut: input.checkOut
	}, listBlocks(), listSaleCloses());
	const publicStay = (input.origin ?? "Balcão") === "Link público";
	const quote = quoteStay(room.type, input.checkIn, input.checkOut, {
		adults,
		children,
		segment: publicStay ? "site" : "balcao",
		pix: publicStay ? Boolean(input.pix) : false
	});
	const email = input.guestEmail.trim();
	const reservation = {
		id: input.id ?? newStayId(),
		roomId: input.roomId,
		guestName: input.guestName.trim(),
		guestEmail: email ? assertValidEmail(email) : "",
		guests: Math.max(1, input.guests ?? 1),
		checkIn: input.checkIn,
		checkOut: input.checkOut,
		status: input.status ?? "confirmada",
		nightlyRate: quote.averageNight,
		totalAmount: quote.total,
		origin: input.origin ?? "Balcão",
		createdAt: TODAY_ISO,
		notes: input.notes,
		guestPhone: input.guestPhone?.trim() || void 0,
		holdUntil: input.holdUntil
	};
	createSeq += 1;
	store$3 = [...store$3, reservation];
	return { ...reservation };
}
function seedPublicPending() {
	if (store$3.filter((row) => row.origin === "Link público" && row.status === "pendente").length >= 3) return;
	const checkIn = TODAY_ISO;
	const checkOut = toISODate(addDays(TODAY, 3));
	const checkOutB = toISODate(addDays(TODAY, 2));
	const checkOutC = toISODate(addDays(TODAY, 4));
	const grouped = availableRoomsByType(store$3, checkIn, checkOut, void 0, listBlocks(), listSaleCloses());
	const rooms = Object.values(grouped).flat();
	const extras = [
		{
			id: "res-link-demo",
			name: "Rafael Cruz",
			email: "rafael.cruz@email.com",
			out: checkOut
		},
		{
			id: "res-link-demo-2",
			name: "Marina Costa",
			email: "marina.costa@email.com",
			out: checkOutB
		},
		{
			id: "res-link-demo-3",
			name: "Paulo Nogueira",
			email: "paulo.nogueira@email.com",
			out: checkOutC
		}
	].filter((item) => !store$3.some((row) => row.id === item.id));
	for (const extra of extras) {
		const room = rooms.shift();
		if (!room) break;
		const quote = quoteStay(room.type, checkIn, extra.out);
		store$3 = [...store$3, {
			id: extra.id,
			roomId: room.id,
			guestName: extra.name,
			guestEmail: extra.email,
			guests: 2,
			checkIn,
			checkOut: extra.out,
			status: "pendente",
			nightlyRate: quote.averageNight,
			totalAmount: quote.total,
			origin: "Link público",
			notes: `Sinal Pix 30% · comprovante: pix-${extra.id}.pdf · quarto ${room.number}`
		}];
	}
}
seedPublicPending();
var METODO_PAGAMENTO_LABEL = {
	pix: "Pix",
	cartao_credito: "Cartão de crédito",
	cartao_debito: "Cartão de débito",
	dinheiro: "Dinheiro"
};
function notesSayPayAtCheckIn(notes) {
	return Boolean(notes?.includes("Pagamento no check-in"));
}
var folioKeys = {
	all: ["folio"],
	byReservation: (reservaId) => ["folio", reservaId]
};
function formatHora(date) {
	return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}
var CONSUMOS_SEED = [
	{
		id: "csm-001",
		reserva_id: "res-001",
		descricao: "Frigobar — água",
		valor: 12,
		quantidade: 2,
		data_lancamento: "2026-09-07"
	},
	{
		id: "csm-002",
		reserva_id: "res-001",
		descricao: "Café da manhã extra",
		valor: 45,
		quantidade: 1,
		data_lancamento: "2026-09-08"
	},
	{
		id: "csm-003",
		reserva_id: "res-002",
		descricao: "Lavanderia",
		valor: 38,
		quantidade: 1,
		data_lancamento: "2026-09-06"
	},
	{
		id: "csm-004",
		reserva_id: "res-002",
		descricao: "Room service — jantar",
		valor: 89,
		quantidade: 1,
		data_lancamento: "2026-09-07"
	},
	{
		id: "csm-005",
		reserva_id: "res-003",
		descricao: "Estacionamento",
		valor: 25,
		quantidade: 2,
		data_lancamento: "2026-09-08"
	}
];
var PAGAMENTOS_SEED = [{
	id: "pag-001",
	reserva_id: "res-001",
	descricao: "Sinal na reserva",
	valor: 200,
	data_pagamento: "2026-09-01",
	metodo: "pix"
}, {
	id: "pag-002",
	reserva_id: "res-002",
	descricao: "Pagamento parcial",
	valor: 350,
	data_pagamento: "2026-09-05",
	metodo: "cartao_credito"
}];
var consumos = CONSUMOS_SEED.map((row) => ({ ...row }));
var pagamentos = PAGAMENTOS_SEED.map((row) => ({ ...row }));
var consumoSeq = consumos.length + 1;
var pagamentoSeq = pagamentos.length + 1;
function seedTodayPayments() {
	const reservations = listReservations();
	if (reservations.length === 0) return;
	const extras = [
		{
			metodo: "pix",
			valor: 420,
			hora: "09:14"
		},
		{
			metodo: "cartao_credito",
			valor: 890,
			hora: "10:36"
		},
		{
			metodo: "dinheiro",
			valor: 180,
			hora: "11:05"
		},
		{
			metodo: "cartao_debito",
			valor: 310,
			hora: "13:22"
		},
		{
			metodo: "pix",
			valor: 150,
			hora: "15:48"
		},
		{
			metodo: "dinheiro",
			valor: 95,
			hora: "16:10"
		},
		{
			metodo: "cartao_credito",
			valor: 640,
			hora: "17:41"
		}
	].map((row, index) => {
		const reservation = reservations[index % reservations.length];
		return {
			id: `pag-today-${String(index + 1).padStart(3, "0")}`,
			reserva_id: reservation.id,
			descricao: "Pagamento na recepção",
			valor: row.valor,
			data_pagamento: TODAY_ISO,
			hora: row.hora,
			metodo: row.metodo
		};
	});
	pagamentos = [...pagamentos, ...extras];
	pagamentoSeq = pagamentos.length + 1;
}
seedTodayPayments();
function listConsumos(reservaId) {
	return consumos.filter((item) => item.reserva_id === reservaId).map((item) => ({ ...item }));
}
function listPagamentos(reservaId) {
	return pagamentos.filter((item) => item.reserva_id === reservaId).map((item) => ({ ...item }));
}
function listAllPagamentos() {
	return pagamentos.map((item) => ({ ...item }));
}
function listAllConsumos() {
	return consumos.map((item) => ({ ...item }));
}
function replaceFolio(next) {
	consumos = next.consumos.map((item) => ({ ...item }));
	pagamentos = next.pagamentos.map((item) => ({ ...item }));
	consumoSeq = consumos.length + 1;
	pagamentoSeq = pagamentos.length + 1;
}
function totalConsumo(itens) {
	return itens.reduce((sum, item) => sum + item.valor * item.quantidade, 0);
}
function totalPagamentos(itens) {
	return itens.reduce((sum, item) => sum + item.valor, 0);
}
function calcularTotais(totalDiarias, itens, pagamentosReserva) {
	const consumo = totalConsumo(itens);
	const pagos = totalPagamentos(pagamentosReserva);
	return {
		totalDiarias,
		totalConsumo: consumo,
		totalPagamentos: pagos,
		saldo: totalDiarias + consumo - pagos
	};
}
function buildFolioLinhas(reservaId, totalDiarias, nightlyRate, checkIn, checkOut, itens, pagamentosReserva) {
	const nights = stayNights(checkIn, checkOut);
	const linhas = [{
		id: `diaria-${reservaId}`,
		tipo: "diaria",
		descricao: `Diárias · ${nights} ${nights === 1 ? "noite" : "noites"}`,
		quantidade: nights,
		valor: nightlyRate,
		total: totalDiarias,
		data: checkIn
	}];
	for (const item of itens) linhas.push({
		id: item.id,
		tipo: "consumo",
		descricao: item.descricao,
		quantidade: item.quantidade,
		valor: item.valor,
		total: item.valor * item.quantidade,
		data: item.data_lancamento,
		removivel: true
	});
	for (const item of pagamentosReserva) {
		const metodo = METODO_PAGAMENTO_LABEL[item.metodo];
		linhas.push({
			id: item.id,
			tipo: "pagamento",
			descricao: item.observacao ? `${item.descricao} · ${metodo} · ${item.observacao}` : `${item.descricao} · ${metodo}`,
			quantidade: 1,
			valor: item.valor,
			total: -item.valor,
			data: item.data_pagamento
		});
	}
	return linhas;
}
function getFolio(reservaId) {
	const reservation = listReservations().find((row) => row.id === reservaId);
	const itens = listConsumos(reservaId);
	const pagamentosReserva = listPagamentos(reservaId);
	const totalDiarias = reservation?.totalAmount ?? 0;
	return {
		reservaId,
		itens,
		pagamentos: pagamentosReserva,
		linhas: reservation ? buildFolioLinhas(reservaId, totalDiarias, reservation.nightlyRate, reservation.checkIn, reservation.checkOut, itens, pagamentosReserva) : [],
		totais: calcularTotais(totalDiarias, itens, pagamentosReserva)
	};
}
function addConsumo(input) {
	const item = {
		id: input.id ?? `csm-${String(consumoSeq++).padStart(3, "0")}`,
		reserva_id: input.reserva_id,
		descricao: input.descricao.trim(),
		valor: input.valor,
		quantidade: input.quantidade,
		data_lancamento: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
	};
	consumos = [...consumos, item];
	return { ...item };
}
function removeConsumo(id) {
	consumos = consumos.filter((item) => item.id !== id);
}
function removePagamento(id) {
	pagamentos = pagamentos.filter((item) => item.id !== id);
}
function addPagamento(input) {
	const item = {
		id: input.id ?? `pag-${String(pagamentoSeq++).padStart(3, "0")}`,
		reserva_id: input.reserva_id,
		descricao: input.descricao?.trim() || "Pagamento na recepção",
		valor: input.valor,
		data_pagamento: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
		hora: formatHora(/* @__PURE__ */ new Date()),
		metodo: input.metodo,
		observacao: input.observacao?.trim() || void 0
	};
	pagamentos = [...pagamentos, item];
	return { ...item };
}
var guestKeys = {
	all: ["guests"],
	byId: (id) => ["guests", id]
};
var PROFILE_SEED = [
	{
		name: "Ana Ribeiro",
		tags: ["VIP", "Frequente"],
		preferences: ["Andar alto", "Cortesia no frigobar"],
		notes: "Hóspede fiel. Tratar como VIP na recepção."
	},
	{
		name: "Bruno Costa",
		tags: ["Corporativo"],
		preferences: ["Andar alto", "Check-in tardio"]
	},
	{
		name: "Camila Ferreira",
		tags: ["Frequente"],
		preferences: ["Alérgica a mofo", "Travesseiro extra"]
	},
	{
		name: "Diego Almeida",
		tags: ["Inadimplente"],
		preferences: ["Evitar pré-autorização baixa"],
		notes: "Histórico de saldo em aberto. Confirmar pagamento no check-in."
	},
	{
		name: "Helena Paiva",
		tags: ["VIP"],
		preferences: ["Suíte se disponível", "Silêncio"]
	}
];
function slugName(name) {
	return name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
function fakeCpf(name) {
	let hash = 0;
	for (const char of name) hash = hash * 33 + char.charCodeAt(0) >>> 0;
	const body = String(hash).padStart(9, "0").slice(0, 9);
	return `${body.slice(0, 3)}.${body.slice(3, 6)}.${body.slice(6, 9)}-${String(hash % 100).padStart(2, "0")}`;
}
function fakePhone(name) {
	let hash = 0;
	for (const char of name) hash = hash * 17 + char.charCodeAt(0) >>> 0;
	return `(11) 9${String(hash).padStart(8, "0").slice(0, 4)}-${String(hash).slice(-4)}`;
}
function digits(value) {
	return value.replace(/\D/g, "");
}
function guestIdFromName(name) {
	return `gst-${slugName(name)}`;
}
function fromReservation(reservation, extra) {
	return {
		id: guestIdFromName(reservation.guestName),
		name: reservation.guestName,
		email: reservation.guestEmail,
		cpf: extra?.cpf ?? fakeCpf(reservation.guestName),
		phone: extra?.phone ?? fakePhone(reservation.guestName),
		preferences: extra?.preferences ?? [],
		tags: extra?.tags ?? [],
		notes: extra?.notes
	};
}
function listGuests() {
	const extras = new Map(PROFILE_SEED.map((row) => [row.name, row]));
	const byName = /* @__PURE__ */ new Map();
	for (const reservation of listReservations()) {
		if (byName.has(reservation.guestName)) continue;
		byName.set(reservation.guestName, fromReservation(reservation, extras.get(reservation.guestName)));
	}
	return [...byName.values()].sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));
}
function getGuest(id) {
	return listGuests().find((guest) => guest.id === id);
}
function findGuestByName(name) {
	return listGuests().find((guest) => guest.name === name);
}
function searchGuests(query) {
	const term = query.trim().toLowerCase();
	const termDigits = digits(query);
	if (!term) return listGuests().slice(0, 8);
	return listGuests().filter((guest) => {
		if (`${guest.name} ${guest.email} ${guest.cpf}`.toLowerCase().includes(term)) return true;
		return termDigits.length >= 3 && digits(guest.cpf).includes(termDigits);
	}).slice(0, 8);
}
function getGuestStats(guest) {
	const stays = listReservations().filter((row) => row.guestName === guest.name && row.status !== "cancelada").slice().sort((a, b) => b.checkIn.localeCompare(a.checkIn)).map((reservation) => {
		const folio = getFolio(reservation.id);
		return {
			reservation,
			consumo: folio.totais.totalConsumo,
			pagos: folio.totais.totalPagamentos,
			folio
		};
	});
	return {
		guest,
		stays,
		ltv: stays.reduce((sum, stay) => sum + stay.reservation.totalAmount + stay.consumo, 0),
		stayCount: stays.length
	};
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/hydrate-B-493WV7.js
var roomKeys = { all: ["rooms"] };
function seedHousekeeping() {
	const occupied = new Set(listReservations().filter((reservation) => isStayActiveOn(reservation, TODAY)).map((reservation) => reservation.roomId));
	return rooms.map((room) => {
		let housekeepingStatus = occupied.has(room.id) ? "sujo" : "limpo";
		if (room.number === "402") housekeepingStatus = "manutencao";
		return {
			...room,
			housekeepingStatus
		};
	});
}
var store = seedHousekeeping();
function listRooms() {
	return store.map((row) => ({ ...row }));
}
function replaceRooms(rows) {
	store = rows.map((row) => ({ ...row }));
}
function patchRoomHousekeeping(id, housekeepingStatus, extras) {
	const index = store.findIndex((row) => row.id === id);
	if (index < 0) throw new Error("Quarto não encontrado");
	const current = store[index];
	const next = {
		...current,
		housekeepingStatus,
		housekeepingNote: housekeepingStatus === "manutencao" ? extras?.note?.trim() || current.housekeepingNote : void 0,
		cleaningStartedAt: housekeepingStatus === "em_limpeza" ? current.cleaningStartedAt ?? (/* @__PURE__ */ new Date()).toISOString() : void 0
	};
	store = [
		...store.slice(0, index),
		next,
		...store.slice(index + 1)
	];
	return { ...next };
}
function markRoomDirty(id) {
	const room = store.find((row) => row.id === id);
	if (!room) return void 0;
	if (room.housekeepingStatus === "manutencao") return { ...room };
	return patchRoomHousekeeping(id, "sujo");
}
function setRoomNote(id, note) {
	const index = store.findIndex((row) => row.id === id);
	if (index < 0) throw new Error("Quarto não encontrado");
	const current = store[index];
	const frontDeskNote = note.trim().slice(0, 80) || void 0;
	const next = {
		...current,
		frontDeskNote
	};
	store = [
		...store.slice(0, index),
		next,
		...store.slice(index + 1)
	];
	return { ...next };
}
var cashKeys = {
	all: ["cash"],
	day: (date) => ["cash", date]
};
var closes = [];
function totalsForDate(date) {
	const dayItems = listAllPagamentos().filter((item) => item.data_pagamento === date);
	const totals = {
		pix: 0,
		cartao_credito: 0,
		cartao_debito: 0,
		dinheiro: 0,
		total: 0
	};
	for (const item of dayItems) {
		totals[item.metodo] += item.valor;
		totals.total += item.valor;
	}
	return totals;
}
function getCashClose(date = TODAY_ISO) {
	return closes.find((row) => row.date === date);
}
function listCashCloses() {
	return closes.map((row) => ({
		...row,
		totals: { ...row.totals }
	}));
}
function replaceCashCloses(rows) {
	closes = rows.map((row) => ({
		...row,
		totals: { ...row.totals }
	}));
}
function closeCash(input) {
	const date = input.date ?? TODAY_ISO;
	const totals = totalsForDate(date);
	const systemCash = totals.dinheiro;
	const report = {
		id: `caixa-${date}`,
		date,
		status: "fechado",
		countedCash: input.countedCash,
		systemCash,
		difference: input.countedCash - systemCash,
		totals,
		notes: input.notes?.trim() || void 0,
		closedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
	closes = [...closes.filter((row) => row.date !== date), report];
	return { ...report };
}
var ROLE_LABEL = {
	admin: "Administrador / Dono",
	gerente: "Gerente",
	recepcionista: "Recepcionista",
	governanca: "Governança / Limpeza",
	financeiro: "Financeiro"
};
var ROLE_PERMISSIONS = {
	admin: [
		"dashboard",
		"calendar",
		"housekeeping",
		"cash",
		"rates",
		"crm",
		"reports",
		"booking",
		"settings",
		"users"
	],
	gerente: [
		"dashboard",
		"calendar",
		"housekeeping",
		"cash",
		"rates",
		"crm",
		"reports",
		"booking",
		"settings"
	],
	recepcionista: [
		"dashboard",
		"calendar",
		"cash",
		"crm",
		"booking"
	],
	governanca: ["housekeeping"],
	financeiro: [
		"dashboard",
		"cash",
		"reports"
	]
};
var PATH_PERMISSION = [
	{
		prefix: "/reservar",
		permission: null
	},
	{
		prefix: "/login",
		permission: null
	},
	{
		prefix: "/calendario",
		permission: "calendar"
	},
	{
		prefix: "/ocupacao",
		permission: "calendar"
	},
	{
		prefix: "/reservas",
		permission: "calendar"
	},
	{
		prefix: "/ofertas",
		permission: "rates"
	},
	{
		prefix: "/casa",
		permission: "calendar"
	},
	{
		prefix: "/governanca",
		permission: "housekeeping"
	},
	{
		prefix: "/caixa",
		permission: "cash"
	},
	{
		prefix: "/tarifas",
		permission: "rates"
	},
	{
		prefix: "/hospedes",
		permission: "crm"
	},
	{
		prefix: "/relatorios",
		permission: "reports"
	},
	{
		prefix: "/reservas-diretas",
		permission: "booking"
	},
	{
		prefix: "/configuracoes",
		permission: "settings"
	},
	{
		prefix: "/equipe",
		permission: "users"
	},
	{
		prefix: "/",
		permission: "dashboard"
	}
];
var ROLE_RANK = {
	governanca: 0,
	recepcionista: 1,
	financeiro: 2,
	gerente: 3,
	admin: 4
};
var PIN_ROLES = ["admin", "gerente"];
function requiresPin(role) {
	return PIN_ROLES.includes(role);
}
function isPrivilegeElevation(from, to) {
	return requiresPin(to) && ROLE_RANK[to] > ROLE_RANK[from];
}
function can(role, permission) {
	return ROLE_PERMISSIONS[role].includes(permission);
}
function permissionForPath(pathname) {
	return PATH_PERMISSION.find((row) => row.prefix === "/" ? pathname === "/" : pathname === row.prefix || pathname.startsWith(`${row.prefix}/`))?.permission ?? "dashboard";
}
function canAccessPath(role, pathname) {
	const permission = permissionForPath(pathname);
	if (permission === null) return true;
	return can(role, permission);
}
function homeForRole(role) {
	if (role === "governanca") return "/governanca";
	if (role === "financeiro") return "/relatorios";
	return "/";
}
var staffKeys = {
	all: ["staff"],
	session: ["staff", "session"]
};
var PinError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "PinError";
	}
};
var users = [
	{
		id: "usr-admin",
		name: "Ana Souza",
		email: "ana.souza@hotelaurora.com",
		role: "admin",
		status: "ativo",
		pin: "1234"
	},
	{
		id: "usr-gerente",
		name: "Elisa Prado",
		email: "elisa.prado@hotelaurora.com",
		role: "gerente",
		status: "ativo",
		pin: "1234"
	},
	{
		id: "usr-recepcao",
		name: "Bruno Lima",
		email: "bruno.lima@hotelaurora.com",
		role: "recepcionista",
		status: "ativo"
	},
	{
		id: "usr-gov",
		name: "Carla Mendes",
		email: "carla.mendes@hotelaurora.com",
		role: "governanca",
		status: "ativo"
	},
	{
		id: "usr-fin",
		name: "Diego Alves",
		email: "diego.alves@hotelaurora.com",
		role: "financeiro",
		status: "ativo"
	}
].map((row) => ({ ...row }));
var seq = users.length + 1;
var sessionId = "usr-admin";
var boundAuthUserId = null;
var STORAGE_KEY = "pms-staff-session";
function publicUser(user) {
	const { pin: _pin, ...rest } = user;
	return {
		...rest,
		pin: user.pin ? "****" : void 0
	};
}
function countActiveAdmins() {
	return users.filter((row) => row.role === "admin" && row.status === "ativo").length;
}
function hydrateStaffSession() {
	if (typeof window === "undefined") return;
	const saved = window.localStorage.getItem(STORAGE_KEY);
	if (saved && users.some((row) => row.id === saved && row.status === "ativo")) sessionId = saved;
}
function listStaff() {
	return users.map(publicUser);
}
function dumpStaff() {
	return users.map((row) => ({ ...row }));
}
function replaceStaff(rows) {
	users = rows.map((row) => ({ ...row }));
	seq = users.length + 1;
	if (!users.some((row) => row.id === sessionId && row.status === "ativo")) sessionId = users.find((row) => row.status === "ativo")?.id ?? sessionId;
}
function getSessionUser() {
	return publicUser(users.find((row) => row.id === sessionId && row.status === "ativo") ?? users[0]);
}
function setSessionUser(id, pin) {
	const user = users.find((row) => row.id === id && row.status === "ativo");
	if (!user) throw new Error("Usuário inativo ou não encontrado");
	const current = users.find((row) => row.id === sessionId) ?? users[0];
	if (current.id !== user.id && isPrivilegeElevation(current.role, user.role)) {
		if (!user.pin) throw new PinError("Defina um PIN de 4 dígitos para este perfil na Equipe.");
		if (pin !== user.pin) throw new PinError("Acesso negado: PIN incorreto");
	}
	sessionId = user.id;
	if (typeof window !== "undefined") window.localStorage.setItem(STORAGE_KEY, sessionId);
	return publicUser(user);
}
function assumeStaffSession(id) {
	const user = users.find((row) => row.id === id && row.status === "ativo");
	if (!user) throw new Error("Usuário inativo ou não encontrado");
	sessionId = user.id;
	if (typeof window !== "undefined") window.localStorage.setItem(STORAGE_KEY, sessionId);
	return publicUser(user);
}
function bindAuthToStaff(input) {
	if (boundAuthUserId === input.authUserId) return {
		user: getSessionUser(),
		created: false
	};
	boundAuthUserId = input.authUserId;
	const email = input.email ? normalizeEmail(input.email) : null;
	if (email) {
		const match = users.find((row) => normalizeEmail(row.email) === email && row.status === "ativo");
		if (match) return {
			user: assumeStaffSession(match.id),
			created: false
		};
	}
	if (!email) return {
		user: getSessionUser(),
		created: false
	};
	const role = input.membershipRole;
	try {
		return {
			user: assumeStaffSession(inviteStaff({
				name: (input.name ?? "").trim() || email.split("@")[0] || "Equipe",
				email,
				role,
				pin: requiresPin(role) ? "1234" : void 0
			}).id),
			created: true
		};
	} catch {
		const match = users.find((row) => normalizeEmail(row.email) === email && row.status === "ativo");
		if (match) return {
			user: assumeStaffSession(match.id),
			created: false
		};
		throw new Error("Não foi possível vincular a conta à equipe.");
	}
}
function inviteStaff(input) {
	const email = assertValidEmail(input.email);
	if (users.some((row) => row.email === email)) throw new Error("Já existe alguém na equipe com este e-mail.");
	const user = {
		id: `usr-${String(seq++).padStart(3, "0")}`,
		name: input.name.trim(),
		email,
		role: input.role,
		status: "ativo",
		pin: input.pin
	};
	users = [...users, user];
	return publicUser(user);
}
function patchStaff(id, patch) {
	const index = users.findIndex((row) => row.id === id);
	if (index < 0) throw new Error("Usuário não encontrado");
	const current = users[index];
	const next = {
		...current,
		...patch
	};
	if (patch.email !== void 0) next.email = assertValidEmail(patch.email);
	if (patch.pin === "") delete next.pin;
	if (current.role === "admin" && current.status === "ativo" && countActiveAdmins() <= 1 && (next.status === "inativo" || next.role !== "admin")) throw new Error("Não é possível desativar ou rebaixar o último administrador.");
	users = [
		...users.slice(0, index),
		next,
		...users.slice(index + 1)
	];
	if (sessionId === id && next.status === "inativo") sessionId = (users.find((row) => row.status === "ativo") ?? next).id;
	return publicUser(next);
}
function removeStaff(id) {
	const target = users.find((row) => row.id === id);
	if (!target) throw new Error("Usuário não encontrado");
	if (target.id === sessionId) throw new Error("Não é possível excluir quem está na sessão agora.");
	if (target.role === "admin" && target.status === "ativo" && countActiveAdmins() <= 1) throw new Error("Não é possível excluir o último administrador ativo.");
	users = users.filter((row) => row.id !== id);
}
hydrateStaffSession();
var KEY = "aurora-hotel-vault-v1";
function readLocalVault() {
	if (typeof window === "undefined") return null;
	try {
		const raw = window.localStorage.getItem(KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.reservations)) return null;
		return {
			...parsed,
			blocks: Array.isArray(parsed.blocks) ? parsed.blocks : []
		};
	} catch {
		return null;
	}
}
function writeLocalVault(vault) {
	if (typeof window === "undefined") return;
	window.localStorage.setItem(KEY, JSON.stringify(vault));
}
function snapshotVault() {
	return {
		version: 1,
		savedAt: Date.now(),
		rooms: listRooms(),
		reservations: listReservations(),
		blocks: listBlocks(),
		saleCloses: listSaleCloses(),
		consumos: listAllConsumos(),
		pagamentos: listAllPagamentos(),
		guests: listGuests(),
		cashCloses: listCashCloses(),
		property: getProperty(),
		booking: getBookingConfig(),
		roomTypes: listRoomTypes(),
		rates: {
			categories: listCategoryRates(),
			seasons: listSeasons(),
			packages: listPackages(),
			promos: listPromos()
		},
		offers: listOffers(),
		staff: dumpStaff()
	};
}
function applyVault(vault) {
	if (vault.rooms?.length) replaceRooms(vault.rooms);
	if (vault.reservations) replaceReservations(vault.reservations);
	replaceBlocks(vault.blocks ?? []);
	replaceSaleCloses(vault.saleCloses ?? []);
	replaceFolio({
		consumos: vault.consumos ?? [],
		pagamentos: vault.pagamentos ?? []
	});
	if (vault.property) replaceProperty(vault.property);
	if (vault.booking) replaceBookingConfig(vault.booking);
	if (vault.property && !vault.property.cancellationPolicy && vault.booking?.cancellationPolicy) replaceProperty({
		...getProperty(),
		cancellationPolicy: vault.booking.cancellationPolicy
	});
	if (vault.rates) replaceRates(vault.rates);
	if (vault.offers) replaceOffers(vault.offers);
	if (vault.roomTypes) replaceRoomTypes(vault.roomTypes);
	if (vault.cashCloses) replaceCashCloses(vault.cashCloses);
	if (vault.staff?.length) replaceStaff(vault.staff);
}
function occupancyToReservation(row) {
	return {
		id: row.id,
		roomId: row.roomId,
		guestName: "",
		guestEmail: "ocupacao@hotel.local",
		guests: 1,
		checkIn: row.checkIn,
		checkOut: row.checkOut,
		status: row.status,
		nightlyRate: 0,
		totalAmount: 0,
		origin: "Ocupação"
	};
}
function applyPublicStay(data) {
	if (data.rooms?.length) replaceRooms(data.rooms);
	const local = readLocalVault();
	if (local?.property) replaceProperty(local.property);
	else if (data.property) replaceProperty({
		...data.property,
		cancellationPolicy: data.property.cancellationPolicy || data.booking?.cancellationPolicy || "",
		checkInTime: data.property.checkInTime || data.booking?.checkInTime || "14:00",
		checkOutTime: data.property.checkOutTime || data.booking?.checkOutTime || "12:00"
	});
	if (data.booking) replaceBookingConfig(data.booking);
	if (data.rates) replaceRates(data.rates);
	if (data.offers) replaceOffers(data.offers);
	if (local?.roomTypes?.length) replaceRoomTypes(local.roomTypes);
	else if (data.roomTypes?.length) replaceRoomTypes(data.roomTypes);
	replaceBlocks(data.blocks ?? []);
	if (local?.saleCloses?.length) replaceSaleCloses(local.saleCloses);
	else replaceSaleCloses(data.saleCloses ?? []);
	const stubs = data.occupancy.map(occupancyToReservation);
	if (data.hasVault) {
		replaceReservations(stubs);
		return;
	}
	if (!stubs.length) return;
	const current = listReservations();
	const ids = new Set(current.map((row) => row.id));
	const extras = stubs.filter((row) => !ids.has(row.id));
	if (extras.length) replaceReservations([...current, ...extras]);
}
async function pushVault(vault) {
	const { pushHotelVaultFn } = await import("./api-iTCU0mCO.mjs").then((n) => n.t);
	await pushHotelVaultFn({ data: { payload: JSON.stringify(vault) } });
}
function bootVaultFromLocal() {
	const local = readLocalVault();
	if (local) applyVault(local);
}
var persistChain = Promise.resolve();
var vaultMode = "staff";
var lastMembershipRole = "recepcionista";
function getLastMembershipRole() {
	return lastMembershipRole;
}
function detectVaultMode() {
	if (typeof window === "undefined") return vaultMode;
	const path = window.location.pathname;
	if (path === "/reservar" || path.startsWith("/reservar/") || path === "/login") return "public";
	return "staff";
}
function setVaultMode(mode) {
	vaultMode = mode;
}
function resetVaultRestore() {
	restored = null;
}
async function ingestSiteBookings(base) {
	try {
		const { pullPublicBookingsFn } = await import("./api-iTCU0mCO.mjs").then((n) => n.t);
		const slice = await pullPublicBookingsFn();
		const next = absorbSiteBookings(base, slice);
		if (next === base) return base;
		return {
			...next,
			savedAt: Date.now()
		};
	} catch {
		return base;
	}
}
function schedulePush(vault) {
	persistChain = persistChain.catch(() => void 0).then(() => pushVault(vault)).catch(() => void 0);
	return persistChain;
}
async function persistVault() {
	if (detectVaultMode() === "public" || vaultMode === "public") return;
	let vault = snapshotVault();
	const ingested = await ingestSiteBookings(vault);
	if (ingested !== vault) {
		applyVault(ingested);
		vault = ingested;
	}
	writeLocalVault(vault);
	persistChain = persistChain.catch(() => void 0).then(() => pushVault(vault)).catch(() => void 0);
	await persistChain;
}
async function restorePublicStay() {
	vaultMode = "public";
	try {
		const { pullPublicStayFn } = await import("./api-iTCU0mCO.mjs").then((n) => n.t);
		const payload = await pullPublicStayFn();
		applyPublicStay(payload);
		return payload;
	} catch {
		return null;
	}
}
async function restoreVault() {
	vaultMode = "staff";
	const local = readLocalVault();
	try {
		const { pullHotelVaultFn } = await import("./api-iTCU0mCO.mjs").then((n) => n.t);
		const pulled = await pullHotelVaultFn();
		lastMembershipRole = pulled.role;
		const remote = parseVault(pulled.payload);
		const preferred = local && remote ? (local.savedAt ?? 0) >= (remote.savedAt ?? 0) ? local : remote : local ?? remote;
		let vault = preferred ? unionVaultReservations(preferred, preferred && local && remote ? preferred === local ? remote : local : null) : null;
		if (!vault) {
			await persistVault();
			return snapshotVault();
		}
		vault = await ingestSiteBookings(vault);
		applyVault(vault);
		writeLocalVault(vault);
		if (!remote || vault.reservations.length !== remote.reservations.length) await schedulePush(vault);
		return vault;
	} catch {
		let vault = local;
		if (!vault) return snapshotVault();
		const before = vault.reservations.length;
		vault = await ingestSiteBookings(vault);
		applyVault(vault);
		writeLocalVault(vault);
		if (vault.reservations.length !== before) await schedulePush(vault);
		return vault;
	}
}
var restored = null;
function ensureVaultRestored() {
	const mode = detectVaultMode();
	vaultMode = mode;
	if (!restored) restored = mode === "public" ? restorePublicStay().then(() => snapshotVault()) : restoreVault();
	return restored;
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-D2QglEY4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function makeQueryClient() {
	return new QueryClient({ defaultOptions: { queries: {
		staleTime: 15e3,
		refetchOnWindowFocus: false
	} } });
}
var browserClient;
function getQueryClient() {
	if (typeof window === "undefined") return makeQueryClient();
	if (!browserClient) browserClient = makeQueryClient();
	return browserClient;
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function TooltipProvider({ delayDuration = 200, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Provider, {
		delayDuration,
		...props
	});
}
function Logo({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-8", className),
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				className: "fill-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M7 22V15.5c0-4.7 4-8.5 9-8.5s9 3.8 9 8.5V22",
				fill: "none",
				className: "stroke-primary-foreground",
				strokeWidth: "1.75",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M11 22v-5.2c0-2.7 2.2-4.8 5-4.8s5 2.1 5 4.8V22",
				className: "fill-primary-foreground/15 stroke-primary-foreground",
				strokeWidth: "1.25"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "14.4",
				y: "18",
				width: "3.2",
				height: "4",
				rx: "0.6",
				className: "fill-primary-foreground"
			})
		]
	});
}
function useProperty() {
	return useQuery({
		queryKey: propertyKeys.current,
		queryFn: async () => getProperty(),
		initialData: () => getProperty()
	});
}
function useSaveProperty() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (next) => {
			const saved = saveProperty(next);
			await persistVault();
			return saved;
		},
		onSuccess: async (saved) => {
			queryClient.setQueryData(propertyKeys.current, saved);
			queryClient.setQueryData(bookingKeys.config, getBookingConfig());
			await queryClient.invalidateQueries({ queryKey: propertyKeys.current });
			await queryClient.invalidateQueries({ queryKey: bookingKeys.config });
		}
	});
}
function HotelBrand({ className }) {
	const { data } = useProperty();
	if (data.logoUrl) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: data.logoUrl,
		alt: "",
		className: cn("size-8 rounded-lg object-cover", className)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, { className });
}
var APP_VERSION_LABEL = `v1.32.47`;
function useStaff() {
	return useQuery({
		queryKey: staffKeys.all,
		queryFn: async () => listStaff(),
		initialData: () => listStaff()
	});
}
function useStaffSession() {
	return useQuery({
		queryKey: staffKeys.session,
		queryFn: async () => getSessionUser(),
		initialData: () => getSessionUser()
	});
}
function useCan(permission) {
	const { data: session } = useStaffSession();
	return can(session.role, permission);
}
function useCanPath(pathname) {
	const { data: session } = useStaffSession();
	return canAccessPath(session.role, pathname);
}
function useSwitchStaff() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => setSessionUser(input.id, input.pin),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: staffKeys.session });
		}
	});
}
function useInviteStaff() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => {
			const user = inviteStaff(input);
			await persistVault();
			return user;
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: staffKeys.all });
		}
	});
}
function usePatchStaff() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async ({ id, ...patch }) => {
			const user = patchStaff(id, patch);
			await persistVault();
			return user;
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: staffKeys.all });
			await queryClient.invalidateQueries({ queryKey: staffKeys.session });
		}
	});
}
function useRemoveStaff() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (id) => {
			removeStaff(id);
			await persistVault();
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: staffKeys.all });
			await queryClient.invalidateQueries({ queryKey: staffKeys.session });
		}
	});
}
function RequirePath({ pathname, children }) {
	if (!useCanPath(pathname)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccessDenied, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function AccessDenied() {
	const { data: session } = useStaffSession();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg rounded-xl bg-card p-6 text-center shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
				children: "Acesso negado"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display mt-2 text-2xl font-medium tracking-tight",
				children: "Sem permissão"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: [
					session.name,
					" está como ",
					ROLE_LABEL[session.role],
					" e não pode abrir esta tela."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: homeForRole(session.role),
				className: "mt-4 inline-block text-sm underline",
				children: "Ir para a tela permitida"
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/40 focus-visible:ring-[3px] active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-primary/90",
			outline: "border border-border bg-card text-foreground hover:bg-secondary",
			ghost: "text-foreground hover:bg-secondary",
			secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
			destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-10 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-11 rounded-md px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		"data-slot": "input",
		className: cn("h-11 w-full min-w-0 rounded-md border border-input bg-card px-3 text-sm text-foreground shadow-[var(--shadow-border)] outline-none transition-shadow duration-150", "placeholder:text-muted-foreground", "focus-visible:border-ring focus-visible:ring-ring/40 focus-visible:ring-[3px]", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		"data-slot": "label",
		className: cn("text-xs font-medium tracking-wide text-muted-foreground uppercase", className),
		...props
	});
}
function PinChallengeModal({ open, user, error, pending, onOpenChange, onConfirm }) {
	const [pin, setPin] = (0, import_react.useState)("");
	function submit(event) {
		event.preventDefault();
		onConfirm(pin);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => {
			if (!next) setPin("");
			onOpenChange(next);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-[80] bg-foreground/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed top-1/2 left-1/2 z-[90] w-[calc(100%-2rem)] max-w-sm -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-card p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-xl font-medium tracking-tight",
					children: "PIN de segurança"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
					className: "mt-1 text-sm text-muted-foreground",
					children: [
						"Para entrar como ",
						user?.name,
						" (",
						user ? ROLE_LABEL[user.role] : "",
						") informe o PIN de 4 dígitos."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
					className: "absolute top-4 right-4 opacity-70 hover:opacity-100",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Fechar"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "staff-pin",
								children: "Senha master / PIN"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "staff-pin",
								inputMode: "numeric",
								autoComplete: "off",
								maxLength: 4,
								pattern: "\\d{4}",
								placeholder: "••••",
								value: pin,
								onChange: (event) => setPin(event.target.value.replace(/\D/g, "").slice(0, 4))
							})]
						}),
						error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: error
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: pending || pin.length !== 4,
							children: "Confirmar acesso"
						})
					]
				})
			]
		})] })
	});
}
function StaffSwitcher() {
	const { data: session } = useStaffSession();
	const { data: staff = [] } = useStaff();
	const switchStaff = useSwitchStaff();
	const [target, setTarget] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const active = staff.filter((user) => user.status === "ativo");
	async function apply(id, pin) {
		try {
			const next = await switchStaff.mutateAsync({
				id,
				pin
			});
			setTarget(null);
			setError("");
			toast.success(`Sessão: ${next.name}`);
		} catch (err) {
			const message = err instanceof PinError ? err.message : "Não foi possível trocar o usuário.";
			setError(message);
			toast.error(message);
		}
	}
	function requestSwitch(id) {
		if (id === session.id) return;
		const user = active.find((row) => row.id === id);
		if (!user) return;
		if (isPrivilegeElevation(session.role, user.role)) {
			setError("");
			setTarget(user);
			return;
		}
		apply(id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		"aria-label": "Usuário da sessão",
		className: "hidden h-10 max-w-[11rem] truncate rounded-full border border-input bg-card px-3 text-xs sm:block",
		value: session.id,
		onChange: (event) => requestSwitch(event.target.value),
		children: active.map((user) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: user.id,
			children: user.name
		}, user.id))
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinChallengeModal, {
		open: Boolean(target),
		user: target,
		error,
		pending: switchStaff.isPending,
		onOpenChange: (open) => {
			if (!open) {
				setTarget(null);
				setError("");
			}
		},
		onConfirm: (pin) => {
			if (target) apply(target.id, pin);
		}
	})] });
}
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
function AuthStaffBridge() {
	const { user, isPending } = useCurrentUserState();
	const queryClient = useQueryClient();
	(0, import_react.useEffect)(() => {
		if (isPending || !user) return;
		let cancelled = false;
		ensureVaultRestored().then(async () => {
			if (cancelled) return;
			if (bindAuthToStaff({
				authUserId: user.id,
				email: user.primaryEmail,
				name: user.displayName,
				membershipRole: getLastMembershipRole()
			}).created) await persistVault();
			await queryClient.invalidateQueries({ queryKey: staffKeys.all });
			await queryClient.invalidateQueries({ queryKey: staffKeys.session });
		}).catch(() => void 0);
		return () => {
			cancelled = true;
		};
	}, [
		user,
		isPending,
		queryClient
	]);
	return null;
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var NAV_GROUPS = [
	{
		id: "dia",
		label: "Dia",
		items: [{
			to: "/",
			label: "Início",
			icon: House
		}, {
			to: "/calendario",
			label: "Mapa",
			icon: CalendarDays
		}]
	},
	{
		id: "estadia",
		label: "Estadia",
		items: [
			{
				to: "/reservas",
				label: "Reservas",
				icon: BookOpen
			},
			{
				to: "/ocupacao",
				label: "Ocupação",
				icon: ChartColumn
			},
			{
				to: "/hospedes",
				label: "Hóspedes",
				icon: Users
			}
		]
	},
	{
		id: "casa",
		label: "Casa",
		items: [{
			to: "/casa",
			label: "Casa",
			icon: House
		}, {
			to: "/governanca",
			label: "Limpeza",
			icon: Sparkles
		}]
	},
	{
		id: "caixa",
		label: "Contas",
		items: [{
			to: "/caixa",
			label: "Caixa",
			icon: Wallet
		}, {
			to: "/relatorios",
			label: "Relatórios",
			icon: FileChartColumnIncreasing
		}]
	},
	{
		id: "config",
		label: "Casa / config",
		items: [
			{
				to: "/tarifas",
				label: "Tarifas",
				icon: Tags
			},
			{
				to: "/reservas-diretas",
				label: "Motor de reservas",
				icon: Globe
			},
			{
				to: "/configuracoes",
				label: "Hotel",
				icon: Building2
			},
			{
				to: "/equipe",
				label: "Equipe",
				icon: Shield
			}
		]
	}
];
var NAV_KEY = "aurora-nav-expanded";
var rootRouteApi = getRouteApi("__root__");
function formatToday(date) {
	const raw = format(date, "EEEE, d 'de' MMMM", { locale: ptBR });
	return raw.charAt(0).toUpperCase() + raw.slice(1);
}
function AuthSlot() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-8 shrink-0 animate-pulse rounded-full bg-secondary" });
	return user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}) : null;
}
function isActivePath(pathname, to) {
	return to === "/" ? pathname === "/" : pathname.startsWith(to);
}
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const todayLabel = formatToday(TODAY);
	const isLogin = pathname === "/login";
	const isPublic = isLogin || pathname === "/reservar" || pathname.startsWith("/reservar/");
	const { data: property } = useProperty();
	const { data: session } = useStaffSession();
	const { sessionUser } = rootRouteApi.useRouteContext();
	const { user, isPending } = useCurrentUserState();
	const authed = Boolean(user ?? sessionUser);
	const [expanded, setExpanded] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			setExpanded(localStorage.getItem(NAV_KEY) === "1");
		} catch {}
	}, []);
	function toggleNav() {
		setExpanded((current) => {
			const next = !current;
			try {
				localStorage.setItem(NAV_KEY, next ? "1" : "0");
			} catch {}
			return next;
		});
	}
	if (isLogin) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children
	});
	if (!isPublic && isPending && sessionUser === void 0 && !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-14 border-r border-border bg-card" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "min-w-0 flex-1 px-4 py-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-48 animate-pulse rounded-xl bg-secondary/70" })
		})]
	});
	if (!isPublic && !authed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	if (isPublic) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-7xl items-center gap-3 px-4 py-3 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/reservar",
						className: "flex min-w-0 items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HotelBrand, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display block truncate text-lg leading-tight font-medium tracking-tight",
								children: property.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden text-xs tracking-wide text-muted-foreground uppercase sm:block",
								children: "Reserve sua estadia"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "ml-auto text-sm text-muted-foreground",
						children: ["Página do hóspede", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "ml-3 underline underline-offset-4",
							children: "Equipe"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto w-full min-w-0 max-w-7xl flex-1 px-4 py-6 sm:px-6 sm:py-8",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				"aria-label": `Versão ${APP_VERSION_LABEL}`,
				className: "pointer-events-none fixed right-3 bottom-3 z-50 rounded-full bg-card/90 px-2.5 py-1 text-xs tracking-wide text-muted-foreground shadow-[var(--shadow-border)]",
				children: APP_VERSION_LABEL
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthStaffBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: cn("sticky top-0 z-40 flex h-dvh shrink-0 flex-col border-r border-border bg-card transition-[width] duration-200", expanded ? "w-52" : "w-14"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: cn("flex h-14 items-center gap-2 border-b border-border px-3", !expanded && "justify-center px-0"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HotelBrand, {}), expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "min-w-0 truncate font-display text-sm font-medium tracking-tight",
							children: property.name
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						"aria-label": "Principal",
						className: "flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto px-2 py-3",
						children: NAV_GROUPS.map((group) => {
							const items = group.items.filter((item) => canAccessPath(session.role, item.to));
							if (!items.length) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-1",
								children: [expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-2 text-[10px] font-medium tracking-wide text-muted-foreground uppercase",
									children: group.label
								}) : null, items.map((item) => {
									const Icon = item.icon;
									const active = isActivePath(pathname, item.to);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: item.to,
										title: item.label,
										className: cn("inline-flex h-10 items-center rounded-lg text-sm font-medium transition-colors duration-150", expanded ? "gap-2.5 px-2.5" : "justify-center", active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary hover:text-foreground"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0" }), expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: item.label
										}) : null]
									}, item.to);
								})]
							}, group.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("grid gap-2 border-t border-border p-2", !expanded && "justify-items-center"),
						children: [expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaffSwitcher, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthSlot, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-[11px] text-muted-foreground",
									suppressHydrationWarning: true,
									children: todayLabel
								})]
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthSlot, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "icon",
							className: "h-9 w-full",
							"aria-label": expanded ? "Recolher menu" : "Expandir menu",
							onClick: toggleNav,
							children: expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "min-w-0 flex-1 px-4 py-6 sm:px-6 sm:py-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto w-full max-w-7xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequirePath, {
						pathname,
						children
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				"aria-label": `Versão ${APP_VERSION_LABEL}`,
				className: "pointer-events-none fixed right-3 bottom-3 z-50 rounded-full bg-card/90 px-2.5 py-1 text-xs tracking-wide text-muted-foreground shadow-[var(--shadow-border)]",
				children: APP_VERSION_LABEL
			})
		]
	});
}
var styles_default = "/assets/styles-6aQ266V0.css";
var APP_NAME = "Hotel Aurora";
var fetchSessionUser = createServerFn({ method: "GET" }).handler(createSsrRpc("2c4985e96c199268f7f639534cb5e8e31d6b19d43286bf77416413db60ffde26"));
var Route$18 = createRootRoute({
	beforeLoad: async () => ({ sessionUser: await fetchSessionUser() }),
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#2f5454"
			},
			{
				name: "description",
				content: "Protótipo de gestão hoteleira do Hotel Aurora — painel e calendário."
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;0,700&family=Fraunces:opsz,wght@9..144,500;9..144,600&display=swap"
			}
		]
	}),
	component: RootDocument
});
function VaultHydrator() {
	const queryClient = useQueryClient();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useLayoutEffect)(() => {
		const isLogin = pathname === "/login";
		const isPublic = isLogin || pathname === "/reservar" || pathname.startsWith("/reservar/");
		resetVaultRestore();
		if (isLogin) return;
		if (isPublic) {
			setVaultMode("public");
			restorePublicStay().then(() => {
				queryClient.invalidateQueries();
			});
			return;
		}
		setVaultMode("staff");
		bootVaultFromLocal();
		queryClient.invalidateQueries();
		ensureVaultRestored().then(() => {
			queryClient.invalidateQueries();
		});
	}, [pathname, queryClient]);
	return null;
}
function RootDocument() {
	const queryClient = getQueryClient();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "pt-BR",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
				client: queryClient,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VaultHydrator, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					position: "bottom-center",
					toastOptions: { className: "border-border bg-card text-card-foreground shadow-[var(--shadow-border)]" }
				})] })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$16 = () => import("./routes-DD_dAAk4.mjs");
var Route$17 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("./caixa-z-ZXBYd7.mjs");
var Route$16 = createFileRoute("/caixa")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("./calendario-G9cSgntR.mjs");
var Route$15 = createFileRoute("/calendario")({
	validateSearch: (search) => ({ reserva: typeof search.reserva === "string" ? search.reserva : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./casa-DtIEe9jf.mjs");
var Route$14 = createFileRoute("/casa")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./configuracoes-DVIgz5xn.mjs");
var Route$13 = createFileRoute("/configuracoes")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./equipe-CQrGGPgh.mjs");
var Route$12 = createFileRoute("/equipe")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./governanca-DMALmfpv.mjs");
var Route$11 = createFileRoute("/governanca")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./hospedes-BUExBgWu.mjs");
var Route$10 = createFileRoute("/hospedes")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./login-DsZUOjt0.mjs");
var Route$9 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./ocupacao-BUhmBaLc.mjs");
var Route$8 = createFileRoute("/ocupacao")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./ofertas-D1DgnoHx.mjs");
var Route$7 = createFileRoute("/ofertas")({
	beforeLoad: () => {
		throw redirect({ href: "/tarifas?aba=ofertas" });
	},
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./relatorios-F5rLpfG9.mjs");
var Route$6 = createFileRoute("/relatorios")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./reservar-BxJ8GGg4.mjs");
var Route$5 = createFileRoute("/reservar")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./reservas-CzWCGsOl.mjs");
var Route$4 = createFileRoute("/reservas")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./reservas-diretas-CGZSGPEV.mjs");
var Route$3 = createFileRoute("/reservas-diretas")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./tarifas-BmlD0jVF.mjs");
var ABAS = [
	"tarifas",
	"pacotes",
	"cupons",
	"ofertas"
];
var Route$2 = createFileRoute("/tarifas")({
	validateSearch: (search) => {
		const aba = search.aba;
		if (typeof aba === "string" && ABAS.includes(aba)) return { aba };
		return {};
	},
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./hospedes._guestId-UfUiVyxF.mjs");
var Route$1 = createFileRoute("/hospedes/$guestId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var Route = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => auth.handler(request),
	POST: ({ request }) => auth.handler(request)
} } });
var IndexRoute = Route$17.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$18
});
var CaixaRoute = Route$16.update({
	id: "/caixa",
	path: "/caixa",
	getParentRoute: () => Route$18
});
var CalendarioRoute = Route$15.update({
	id: "/calendario",
	path: "/calendario",
	getParentRoute: () => Route$18
});
var CasaRoute = Route$14.update({
	id: "/casa",
	path: "/casa",
	getParentRoute: () => Route$18
});
var ConfiguracoesRoute = Route$13.update({
	id: "/configuracoes",
	path: "/configuracoes",
	getParentRoute: () => Route$18
});
var EquipeRoute = Route$12.update({
	id: "/equipe",
	path: "/equipe",
	getParentRoute: () => Route$18
});
var GovernancaRoute = Route$11.update({
	id: "/governanca",
	path: "/governanca",
	getParentRoute: () => Route$18
});
var HospedesRoute = Route$10.update({
	id: "/hospedes",
	path: "/hospedes",
	getParentRoute: () => Route$18
});
var LoginRoute = Route$9.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$18
});
var OcupacaoRoute = Route$8.update({
	id: "/ocupacao",
	path: "/ocupacao",
	getParentRoute: () => Route$18
});
var OfertasRoute = Route$7.update({
	id: "/ofertas",
	path: "/ofertas",
	getParentRoute: () => Route$18
});
var RelatoriosRoute = Route$6.update({
	id: "/relatorios",
	path: "/relatorios",
	getParentRoute: () => Route$18
});
var ReservarRoute = Route$5.update({
	id: "/reservar",
	path: "/reservar",
	getParentRoute: () => Route$18
});
var ReservasRoute = Route$4.update({
	id: "/reservas",
	path: "/reservas",
	getParentRoute: () => Route$18
});
var ReservasDiretasRoute = Route$3.update({
	id: "/reservas-diretas",
	path: "/reservas-diretas",
	getParentRoute: () => Route$18
});
var TarifasRoute = Route$2.update({
	id: "/tarifas",
	path: "/tarifas",
	getParentRoute: () => Route$18
});
var HospedesGuestIdRoute = Route$1.update({
	id: "/$guestId",
	path: "/$guestId",
	getParentRoute: () => HospedesRoute
});
var ApiAuthSplatRoute = Route.update({
	id: "/api/auth/$",
	path: "/api/auth/$",
	getParentRoute: () => Route$18
});
var HospedesRouteChildren = { HospedesGuestIdRoute };
var rootRouteChildren = {
	IndexRoute,
	CaixaRoute,
	CalendarioRoute,
	CasaRoute,
	ConfiguracoesRoute,
	EquipeRoute,
	GovernancaRoute,
	HospedesRoute: HospedesRoute._addFileChildren(HospedesRouteChildren),
	LoginRoute,
	OcupacaoRoute,
	OfertasRoute,
	RelatoriosRoute,
	ReservarRoute,
	ReservasRoute,
	ReservasDiretasRoute,
	TarifasRoute,
	ApiAuthSplatRoute
};
var routeTree = Route$18._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { listAllConsumos as $, setRoomNote as A, saveRoomTypes as At, addSeason as B, listRooms as C, removePackage as Ct, requiresPin as D, replaceReservations as Dt, persistVault as E, removeSeason as Et, addConsumo as F, extraStory as G, clampSitePercent as H, addOffer as I, folioKeys as J, fillBand as K, addPackage as L, METODO_PAGAMENTO_LABEL as M, typeFitsParty as Mt, OCCUPANCY_FIELDS as N, typeHoldsParty as Nt, restoreVault as O, reservationKeys as Ot, OCCUPANCY_LABEL as P, cn as Pt, guestKeys as Q, addPagamento as R, getCashClose as S, removeOffer as St, patchRoomHousekeeping as T, removePromo as Tt, createBlock as U, blockKeys as V, createReservation as W, getGuest as X, getFolio as Y, getGuestStats as Z, ROLE_LABEL as _, quoteNewReservation as _t, Input as a, listPackages as at, detectVaultMode as b, removeBlock as bt, useInviteStaff as c, listRoomTypes as ct, useStaff as d, occupancyOfType as dt, listAllPagamentos as et, useStaffSession as f, offerKeys as ft, createSsrRpc as g, patchReservation as gt, Logo as h, patchOffer as ht, Label as i, listOffers as it, totalsForDate as j, searchGuests as jt, roomKeys as k, roomTypeKeys as kt, usePatchStaff as l, listSeasons as lt, useSaveProperty as m, patchCategoryRate as mt, Route$1 as n, listCategoryRates as nt, Button as o, listPromos as ot, useProperty as p, paintNight as pt, findGuestByName as q, useCurrentUserState as r, listGuests as rt, useCan as s, listReservations as st, router_exports as t, listBlocks as tt, useRemoveStaff as u, notesSayPayAtCheckIn as ut, cashKeys as v, quoteStay as vt, markRoomDirty as w, removePagamento as wt, ensureVaultRestored as x, removeConsumo as xt, closeCash as y, rateKeys as yt, addPromo as z };
