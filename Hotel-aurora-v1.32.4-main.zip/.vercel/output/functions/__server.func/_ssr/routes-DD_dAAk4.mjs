import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as format, t as ptBR, y as addDays } from "../_libs/date-fns.mjs";
import { G as parseISODate, O as formatCurrency, V as monthlyMetrics, c as TODAY, et as roomById, j as getDashboardStats, l as TODAY_ISO, lt as stayNights, t as CURRENT_YEAR } from "./bookingStore-Bq0ubAXy.mjs";
import { C as ChevronLeft, S as ChevronRight, f as Plus, g as LogIn, h as LogOut, p as Percent, u as Search, y as FileText } from "../_libs/lucide-react.mjs";
import { Pt as cn, Y as getFolio, a as Input, et as listAllPagamentos, o as Button, s as useCan } from "./router-D2QglEY4.mjs";
import { r as STATUS_LABEL, t as STATUS_BADGE } from "./status-lXSun_aS.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, r as CardDescription, t as Card } from "./card-C5pfQ1_E.mjs";
import { a as useReservations } from "./useReservations-BEok-WZp.mjs";
import { r as useRooms } from "./useRooms-DVLudIq6.mjs";
import { t as Badge } from "./badge-XwZ3ZDTe.mjs";
import { r as PendingBookingsAlert, t as CreateReservationModal } from "./PendingBookingsAlert-CWuJWCAN.mjs";
import { a as CartesianGrid, c as Tooltip, i as Line, n as YAxis, o as Bar, r as XAxis, s as ResponsiveContainer, t as ComposedChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DD_dAAk4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ChartTooltip({ active, payload, label }) {
	if (!active || !payload?.length) return null;
	const revenue = payload.find((item) => item.dataKey === "revenue");
	const occupancy = payload.find((item) => item.dataKey === "occupancy");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-popover px-3 py-2 text-popover-foreground shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-1.5 text-xs font-medium tracking-wide text-muted-foreground uppercase",
				children: label
			}),
			revenue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm tabular-nums",
				children: ["Receita · ", formatCurrency(Number(revenue.value ?? 0))]
			}) : null,
			occupancy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm tabular-nums",
				children: [
					"Ocupação · ",
					Number(occupancy.value ?? 0).toFixed(1),
					"%"
				]
			}) : null
		]
	});
}
function AnnualChart() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [colors, setColors] = (0, import_react.useState)({
		revenue: "#2f5454",
		occupancy: "#1a1916",
		grid: "#ddd6cc",
		tick: "#6b6560"
	});
	(0, import_react.useEffect)(() => {
		const styles = getComputedStyle(document.documentElement);
		const read = (name, fallback) => styles.getPropertyValue(name).trim() || fallback;
		setColors({
			revenue: read("--color-chart-revenue", "#2f5454"),
			occupancy: read("--color-chart-occupancy", "#1a1916"),
			grid: read("--color-border", "#ddd6cc"),
			tick: read("--color-muted-foreground", "#6b6560")
		});
		setReady(true);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "gap-2 py-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, { children: ["Desempenho anual · ", CURRENT_YEAR] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Receita financeira (barras) e taxa de ocupação (linha), calculadas a partir das reservas do hotel." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "sr-only",
				children: monthlyMetrics.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					row.month,
					": ",
					formatCurrency(row.revenue),
					", ocupação ",
					row.occupancy,
					"%"
				] }, row.month))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-wrap gap-4 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-3.5 rounded-sm bg-chart-revenue" }), "Receita (R$)"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-0.5 w-4 bg-chart-occupancy" }), "Ocupação (%)"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-72 w-full sm:h-80",
				children: ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComposedChart, {
						data: monthlyMetrics,
						margin: {
							top: 8,
							right: 8,
							left: 0,
							bottom: 0
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: colors.grid,
								strokeDasharray: "3 3",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "month",
								tick: {
									fill: colors.tick,
									fontSize: 12
								},
								axisLine: false,
								tickLine: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								yAxisId: "left",
								tick: {
									fill: colors.tick,
									fontSize: 12
								},
								axisLine: false,
								tickLine: false,
								width: 56,
								tickFormatter: (value) => `${Math.round(value / 1e3)}k`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								yAxisId: "right",
								orientation: "right",
								domain: [0, 100],
								tick: {
									fill: colors.tick,
									fontSize: 12
								},
								axisLine: false,
								tickLine: false,
								width: 40,
								tickFormatter: (value) => `${value}%`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, {}),
								cursor: {
									fill: "var(--color-muted)",
									fillOpacity: .45
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								yAxisId: "left",
								dataKey: "revenue",
								name: "revenue",
								fill: colors.revenue,
								radius: [
									6,
									6,
									0,
									0
								],
								maxBarSize: 36
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
								yAxisId: "right",
								dataKey: "occupancy",
								name: "occupancy",
								type: "monotone",
								stroke: colors.occupancy,
								strokeWidth: 2,
								dot: {
									r: 3,
									fill: colors.occupancy
								},
								activeDot: { r: 5 }
							})
						]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-full rounded-lg bg-secondary/60" })
			})
		] })]
	});
}
function isOpen(row) {
	return row.status !== "cancelada";
}
function occupiesNight(row, iso) {
	return isOpen(row) && row.status !== "check-out" && row.checkIn <= iso && row.checkOut > iso;
}
function useDashboardData(dayIso = TODAY_ISO) {
	const { data: reservations = [] } = useReservations();
	const { data: rooms = [] } = useRooms();
	return (0, import_react.useMemo)(() => {
		const day = parseISODate(dayIso);
		const stats = getDashboardStats(day, reservations);
		const chegadas = reservations.filter((row) => isOpen(row) && row.checkIn === dayIso);
		const saidas = reservations.filter((row) => isOpen(row) && row.checkOut === dayIso);
		const permanencias = reservations.filter((row) => isOpen(row) && row.checkIn < dayIso && row.checkOut > dayIso);
		const casa = reservations.filter((row) => row.status === "check-in");
		const remainingArrivals = chegadas.filter((row) => row.status === "pendente" || row.status === "confirmada");
		const remainingDepartures = saidas.filter((row) => row.status === "check-in");
		const withBalance = reservations.filter((row) => row.status !== "cancelada" && row.status !== "check-out").map((row) => ({
			row,
			saldo: getFolio(row.id).totais.saldo
		})).filter((item) => item.saldo > 0);
		const byId = new Map(reservations.map((row) => [row.id, row]));
		const salesToday = listAllPagamentos().filter((item) => item.data_pagamento === dayIso).map((item) => {
			const row = byId.get(item.reserva_id);
			return {
				...item,
				guestName: row?.guestName ?? "—",
				checkIn: row?.checkIn,
				nights: row ? stayNights(row.checkIn, row.checkOut) : 0
			};
		});
		const salesTotal = salesToday.reduce((sum, item) => sum + item.valor, 0);
		const createdToday = reservations.filter((row) => row.createdAt === dayIso);
		const roomNightsToday = createdToday.reduce((sum, row) => sum + stayNights(row.checkIn, row.checkOut), 0);
		const cancelamentos = reservations.filter((row) => row.status === "cancelada" && (row.createdAt === dayIso || row.checkIn === dayIso || row.checkOut === dayIso));
		const dirtyArrivals = chegadas.filter((row) => {
			const room = rooms.find((item) => item.id === row.roomId);
			return room?.housekeepingStatus === "sujo" || room?.housekeepingStatus === "manutencao";
		});
		const pendentes = reservations.filter((row) => row.status === "pendente" || row.origin === "Link público" && row.status === "confirmada");
		const occupiedTonight = new Set(reservations.filter((row) => occupiesNight(row, dayIso)).map((row) => row.roomId)).size;
		const totalRooms = rooms.length || stats.totalRooms;
		return {
			stats,
			chegadas,
			saidas,
			permanencias,
			casa,
			remainingArrivals,
			remainingDepartures,
			occupiedTonight,
			totalRooms,
			occupancyPct: totalRooms === 0 ? 0 : Math.round(occupiedTonight / totalRooms * 100),
			pendentesSaldo: withBalance,
			salesToday,
			salesTotal,
			createdToday,
			roomNightsToday,
			cancelamentos,
			dirtyArrivals,
			preReservas: pendentes
		};
	}, [
		reservations,
		rooms,
		dayIso
	]);
}
function reservationRoomLabel(row) {
	const room = roomById(row.roomId);
	return room ? `${room.number} · ${room.type}` : row.roomId;
}
function reservationCode(row) {
	return row.id.replace(/^res-/i, "").toUpperCase();
}
var TABS = [
	{
		id: "chegadas",
		label: "Chegadas"
	},
	{
		id: "saidas",
		label: "Saídas"
	},
	{
		id: "permanencias",
		label: "Permanências"
	},
	{
		id: "casa",
		label: "Na casa"
	}
];
function isoFrom(date) {
	return format(date, "yyyy-MM-dd");
}
function formatDayTitle(date) {
	const raw = format(date, "EEEE, d 'de' MMMM", { locale: ptBR });
	return raw.charAt(0).toUpperCase() + raw.slice(1);
}
function matchesQuery(row, query) {
	if (!query) return true;
	return `${row.guestName} ${row.guestEmail} ${row.id} ${reservationCode(row)} ${reservationRoomLabel(row)}`.toLowerCase().includes(query);
}
function ReservationRow({ row, extra }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "grid gap-2 border-t border-border px-4 py-3 first:border-t-0 sm:grid-cols-[minmax(0,1.4fr)_5.5rem_minmax(0,1fr)_auto] sm:items-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/calendario",
					search: { reserva: row.id },
					className: "font-medium underline-offset-2 hover:underline",
					children: row.guestName
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground sm:hidden",
					children: [
						reservationRoomLabel(row),
						" · ",
						row.checkIn,
						" → ",
						row.checkOut
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden font-mono text-xs tracking-wide text-muted-foreground sm:block",
				children: reservationCode(row)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "hidden truncate text-sm text-muted-foreground sm:block",
				children: reservationRoomLabel(row)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2 sm:justify-end",
				children: [
					extra ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm tabular-nums",
						children: extra
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: STATUS_BADGE[row.status],
						children: STATUS_LABEL[row.status]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-11 shrink-0",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/calendario",
							search: { reserva: row.id },
							"aria-label": `Abrir ficha de ${row.guestName}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" })
						})
					})
				]
			})
		]
	});
}
function DashboardView() {
	const canReports = useCan("reports");
	const [viewDate, setViewDate] = (0, import_react.useState)(TODAY);
	const [tab, setTab] = (0, import_react.useState)("chegadas");
	const [activity, setActivity] = (0, import_react.useState)("vendas");
	const [query, setQuery] = (0, import_react.useState)("");
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const dayIso = isoFrom(viewDate);
	const data = useDashboardData(dayIso);
	const isToday = dayIso === TODAY_ISO;
	const q = query.trim().toLowerCase();
	const lists = {
		chegadas: data.chegadas,
		saidas: data.saidas,
		permanencias: data.permanencias,
		casa: data.casa
	};
	const current = (0, import_react.useMemo)(() => lists[tab].filter((row) => matchesQuery(row, q)), [
		lists,
		tab,
		q
	]);
	const kpis = [
		{
			label: "Chegadas",
			value: String(data.chegadas.length),
			hint: data.remainingArrivals.length === 1 ? "1 ainda sem check-in" : `${data.remainingArrivals.length} ainda sem check-in`,
			icon: LogIn
		},
		{
			label: "Saídas",
			value: String(data.saidas.length),
			hint: data.remainingDepartures.length === 1 ? "1 ainda na casa" : `${data.remainingDepartures.length} ainda na casa`,
			icon: LogOut
		},
		{
			label: "Ocupação",
			value: `${data.occupancyPct}%`,
			hint: `${data.occupiedTonight} de ${data.totalRooms} quartos ocupados`,
			icon: Percent
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							"aria-label": "Dia anterior",
							onClick: () => setViewDate((d) => addDays(d, -1)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
							children: isToday ? "Hoje" : "Dia selecionado"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-xl font-medium tracking-tight sm:text-3xl",
							children: formatDayTitle(viewDate)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							"aria-label": "Próximo dia",
							onClick: () => setViewDate((d) => addDays(d, 1)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
						}),
						!isToday ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							onClick: () => setViewDate(TODAY),
							children: "Hoje"
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row sm:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "relative min-w-0 flex-1 sm:w-72",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: query,
							onChange: (event) => setQuery(event.target.value),
							placeholder: "Buscar hóspede, código ou quarto",
							className: "pl-10",
							"aria-label": "Buscar reserva"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						className: "h-11 shrink-0 pl-4 pr-3.5",
						onClick: () => setCreateOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Criar reserva"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingBookingsAlert, { compact: true }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: kpis.map((card) => {
					const Icon = card.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl bg-card px-5 py-4 shadow-[var(--shadow-border)] transition-shadow duration-150",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
									children: card.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-9 items-center justify-center rounded-lg bg-secondary text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-4",
										strokeWidth: 1.75
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display mt-2 text-3xl font-medium tabular-nums",
								children: card.value
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-primary tabular-nums",
								children: card.hint
							})
						]
					}, card.label);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 xl:grid-cols-[minmax(0,1fr)_22rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-3 border-b border-border px-3 py-3 sm:flex-row sm:items-center sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "px-1 text-sm font-medium",
								children: "Reservas"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-1 overflow-x-auto",
								children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: cn("inline-flex h-11 shrink-0 items-center rounded-lg px-3 text-sm font-medium transition-colors duration-150", tab === item.id ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"),
									onClick: () => setTab(item.id),
									children: [item.label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-1.5 tabular-nums text-xs text-primary",
										children: lists[item.id].length
									})]
								}, item.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden grid-cols-[minmax(0,1.4fr)_5.5rem_minmax(0,1fr)_auto] gap-2 px-4 pt-3 text-xs tracking-wide text-muted-foreground uppercase sm:grid",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Hóspede" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Cód." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Quarto" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-right",
									children: "Situação"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: current.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "px-4 py-10 text-center text-sm text-muted-foreground",
							children: q ? "Nenhuma reserva corresponde à busca." : "Nenhum registro nesta lista."
						}) : current.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReservationRow, { row }, row.id)) })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "h-fit overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-border px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium",
								children: "Atividade do dia"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Vendas, cancelamentos e alertas"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1 px-2 pt-2",
							children: [
								["vendas", "Vendas"],
								["cancelamentos", "Cancelamentos"],
								["alertas", "Alertas"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("h-11 flex-1 rounded-lg px-2 text-sm font-medium transition-colors duration-150", activity === id ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"),
								onClick: () => setActivity(id),
								children: label
							}, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "px-4 py-4",
							children: [
								activity === "vendas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-3 gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs tracking-wide text-muted-foreground uppercase",
												children: "Reservas"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-2xl font-medium tabular-nums",
												children: data.createdToday.length
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs tracking-wide text-muted-foreground uppercase",
												children: "Noites"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-2xl font-medium tabular-nums",
												children: data.roomNightsToday
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs tracking-wide text-muted-foreground uppercase",
												children: "Recebido"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-xl font-medium tabular-nums",
												children: formatCurrency(data.salesTotal)
											})] })
										]
									}), data.salesToday.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted-foreground",
										children: "Nenhum pagamento neste dia."
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "grid gap-2",
										children: data.salesToday.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center justify-between gap-2 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "min-w-0 truncate",
												children: item.guestName
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "tabular-nums",
												children: formatCurrency(item.valor)
											})]
										}, item.id))
									})]
								}) : null,
								activity === "cancelamentos" ? data.cancelamentos.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: "Nenhum cancelamento neste dia."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "grid gap-2",
									children: data.cancelamentos.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center justify-between gap-2 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "min-w-0 truncate",
											children: row.guestName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: reservationRoomLabel(row)
										})]
									}, row.id))
								}) : null,
								activity === "alertas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2 text-sm",
									children: [
										data.preReservas.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
											data.preReservas.length,
											" pedido(s) do site ou pré-reserva(s) na recepção.",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/calendario",
												className: "underline",
												children: "Abrir mapa"
											})
										] }) : null,
										data.dirtyArrivals.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-destructive",
											children: [data.dirtyArrivals.length, " chegada(s) em quarto sujo ou manutenção"]
										}) : null,
										data.pendentesSaldo.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [data.pendentesSaldo.length, " conta(s) com saldo em aberto"] }) : null,
										!data.preReservas.length && !data.dirtyArrivals.length && !data.pendentesSaldo.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-muted-foreground",
											children: "Nenhum alerta agora."
										}) : null
									]
								}) : null
							]
						})
					]
				})]
			}),
			canReports ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnnualChart, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateReservationModal, {
				open: createOpen,
				onOpenChange: setCreateOpen
			})
		]
	});
}
var SplitComponent = DashboardView;
//#endregion
export { SplitComponent as component };
