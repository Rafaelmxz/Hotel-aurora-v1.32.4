//#region node_modules/.nitro/vite/services/ssr/assets/status-lXSun_aS.js
var STATUS_LABEL = {
	pendente: "Pendente",
	confirmada: "Confirmada",
	"check-in": "Em check-in",
	"check-out": "Checked-out",
	cancelada: "Cancelado"
};
var STATUS_BADGE = {
	pendente: "pending",
	confirmada: "confirmed",
	"check-in": "checkin",
	"check-out": "checkout",
	cancelada: "cancelled"
};
var STATUS_BAR = {
	pendente: "bg-status-pending text-status-pending-fg",
	confirmada: "bg-status-confirmed text-status-confirmed-fg",
	"check-in": "bg-status-checkin text-status-checkin-fg",
	"check-out": "bg-status-checkout text-status-checkout-fg",
	cancelada: "bg-muted text-muted-foreground line-through ring-1 ring-inset ring-border"
};
//#endregion
export { STATUS_BAR as n, STATUS_LABEL as r, STATUS_BADGE as t };
