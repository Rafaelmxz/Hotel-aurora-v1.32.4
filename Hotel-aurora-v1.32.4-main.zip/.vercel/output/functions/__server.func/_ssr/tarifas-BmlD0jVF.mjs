import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { v as getRouteApi, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { h as startOfWeek, i as format, o as startOfMonth, s as eachDayOfInterval, t as ptBR, v as addMonths, y as addDays } from "../_libs/date-fns.mjs";
import { G as parseISODate, O as formatCurrency, it as saleCloseOnNight, l as TODAY_ISO, ut as toISODate } from "./bookingStore-Bq0ubAXy.mjs";
import { C as ChevronLeft, S as ChevronRight } from "../_libs/lucide-react.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { B as addSeason, Ct as removePackage, E as persistVault, Et as removeSeason, H as clampSitePercent, I as addOffer, J as folioKeys, K as fillBand, L as addPackage, N as OCCUPANCY_FIELDS, Nt as typeHoldsParty, Ot as reservationKeys, P as OCCUPANCY_LABEL, Pt as cn, St as removeOffer, Tt as removePromo, a as Input, at as listPackages, ft as offerKeys, ht as patchOffer, i as Label, it as listOffers, lt as listSeasons, mt as patchCategoryRate, nt as listCategoryRates, o as Button, ot as listPromos, pt as paintNight, vt as quoteStay, yt as rateKeys, z as addPromo } from "./router-D2QglEY4.mjs";
import { t as useRoomTypes } from "./useRoomTypes-B7WZBIgo.mjs";
import { n as useRemoveSaleClose, r as useSaleCloses, t as useCreateSaleClose } from "./useSaleCloses-BDBCA2UD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tarifas-BmlD0jVF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useOffers() {
	return useQuery({
		queryKey: offerKeys.all,
		queryFn: async () => listOffers(),
		initialData: () => listOffers()
	});
}
function useAddOffer() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => {
			const offer = addOffer(input);
			await persistVault();
			return offer;
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: offerKeys.all });
		}
	});
}
function usePatchOffer() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async ({ id, ...patch }) => {
			const offer = patchOffer(id, patch);
			await persistVault();
			return offer;
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: offerKeys.all });
		}
	});
}
function useRemoveOffer() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (id) => {
			removeOffer(id);
			await persistVault();
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: offerKeys.all });
		}
	});
}
var ROOM_TYPES$1 = [
	"Standard",
	"Luxo",
	"Suíte"
];
var WEEKDAYS = [
	{
		value: 1,
		label: "Seg"
	},
	{
		value: 2,
		label: "Ter"
	},
	{
		value: 3,
		label: "Qua"
	},
	{
		value: 4,
		label: "Qui"
	},
	{
		value: 5,
		label: "Sex"
	},
	{
		value: 6,
		label: "Sáb"
	},
	{
		value: 0,
		label: "Dom"
	}
];
function OffersView() {
	const { data: offers = [] } = useOffers();
	const addOffer = useAddOffer();
	const patchOffer = usePatchOffer();
	const removeOffer = useRemoveOffer();
	const [name, setName] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("percent");
	const [value, setValue] = (0, import_react.useState)("10");
	const [start, setStart] = (0, import_react.useState)(TODAY_ISO);
	const [end, setEnd] = (0, import_react.useState)(TODAY_ISO);
	const [active, setActive] = (0, import_react.useState)(true);
	const [pixOnly, setPixOnly] = (0, import_react.useState)(false);
	const [minNights, setMinNights] = (0, import_react.useState)("0");
	const [weekdays, setWeekdays] = (0, import_react.useState)([
		1,
		2,
		3,
		4
	]);
	const [roomTypes, setRoomTypes] = (0, import_react.useState)([]);
	function toggleType(type) {
		setRoomTypes((current) => current.includes(type) ? current.filter((item) => item !== type) : [...current, type]);
	}
	function toggleDay(day) {
		setWeekdays((current) => current.includes(day) ? current.filter((item) => item !== day) : [...current, day]);
	}
	async function onSubmit(event) {
		event.preventDefault();
		try {
			await addOffer.mutateAsync({
				name,
				kind,
				value: Number(value),
				start,
				end,
				roomTypes,
				weekdays,
				pixOnly,
				minNights: Math.max(0, Number(minNights) || 0),
				active
			});
			setName("");
			toast.success("Oferta cadastrada");
		} catch {
			toast.error("Não foi possível cadastrar a oferta.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "Regras ativas entram no site do hóspede (Pix, dias da semana e mínimo de noites)."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[22rem_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "grid gap-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nome da promoção" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: name,
							onChange: (event) => setName(event.target.value),
							placeholder: "Desconto Pix"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Tipo de desconto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
								value: kind,
								onChange: (event) => setKind(event.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "percent",
									children: "Percentual (%)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "fixed",
									children: "Valor fixo (R$)"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: kind === "percent" ? "Percentual" : "Valor R$" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								required: true,
								inputMode: "decimal",
								value,
								onChange: (event) => setValue(event.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Início" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								required: true,
								value: start,
								onChange: (event) => setStart(event.target.value)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Fim" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								required: true,
								value: end,
								onChange: (event) => setEnd(event.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Status" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
								value: active ? "ativa" : "inativa",
								onChange: (event) => setActive(event.target.value === "ativa"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "ativa",
									children: "Ativa"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "inativa",
									children: "Inativa"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Mínimo de noites" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "numeric",
								value: minNights,
								onChange: (event) => setMinNights(event.target.value),
								placeholder: "0 = sem mínimo"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "inline-flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: pixOnly,
							onChange: (event) => setPixOnly(event.target.checked)
						}), "Exclusivo para Pix"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Dias da semana" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: WEEKDAYS.map((day) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex items-center gap-1 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: weekdays.includes(day.value),
									onChange: () => toggleDay(day.value)
								}), day.label]
							}, day.value))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Tipos de quarto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: ROOM_TYPES$1.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "inline-flex items-center gap-1.5 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: roomTypes.includes(type),
									onChange: () => toggleType(type)
								}), type]
							}, type))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: addOffer.isPending,
						children: "Cadastrar oferta"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]",
				children: offers.map((offer) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-3 px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							offer.name,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: offer.active ? "· Ativa" : "· Inativa"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							offer.kind === "percent" ? `${offer.value}%` : formatCurrency(offer.value),
							" ·",
							" ",
							offer.start,
							" → ",
							offer.end,
							offer.pixOnly ? " · Pix" : "",
							offer.minNights > 0 ? ` · mín. ${offer.minNights} noites` : "",
							offer.weekdays.length ? " · dias filtrados" : ""
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => void patchOffer.mutateAsync({
								id: offer.id,
								active: !offer.active
							}),
							children: offer.active ? "Desativar" : "Ativar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => void removeOffer.mutateAsync(offer.id),
							children: "Remover"
						})]
					})]
				}, offer.id))
			})]
		})]
	});
}
function useCategoryRates() {
	return useQuery({
		queryKey: rateKeys.all,
		queryFn: async () => listCategoryRates(),
		initialData: () => listCategoryRates()
	});
}
function useSeasons() {
	return useQuery({
		queryKey: rateKeys.seasons,
		queryFn: async () => listSeasons(),
		initialData: () => listSeasons()
	});
}
function usePackages() {
	return useQuery({
		queryKey: rateKeys.packages,
		queryFn: async () => listPackages(),
		initialData: () => listPackages()
	});
}
function usePromos() {
	return useQuery({
		queryKey: rateKeys.promos,
		queryFn: async () => listPromos(),
		initialData: () => listPromos()
	});
}
async function syncReservations(queryClient) {
	await persistVault();
	await queryClient.invalidateQueries({ queryKey: reservationKeys.all });
	await queryClient.invalidateQueries({ queryKey: folioKeys.all });
}
function usePatchCategoryRate() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => patchCategoryRate(input.type, input),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: rateKeys.all });
			await syncReservations(queryClient);
		}
	});
}
function useAddSeason() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => addSeason(input),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: rateKeys.seasons });
			await syncReservations(queryClient);
		}
	});
}
function useRemoveSeason() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (id) => removeSeason(id),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: rateKeys.seasons });
			await syncReservations(queryClient);
		}
	});
}
function useAddPackage() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => addPackage(input),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: rateKeys.packages });
			await syncReservations(queryClient);
		}
	});
}
function useRemovePackage() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (id) => {
			removePackage(id);
			await persistVault();
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: rateKeys.packages });
		}
	});
}
function useAddPromo() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => {
			const promo = addPromo(input);
			await persistVault();
			return promo;
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: rateKeys.promos });
		}
	});
}
function useRemovePromo() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (id) => {
			removePromo(id);
			await persistVault();
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: rateKeys.promos });
		}
	});
}
var ROOM_FILTER = [
	"todas",
	"Standard",
	"Luxo",
	"Suíte"
];
function PackagesView() {
	const { data: packages = [] } = usePackages();
	const addPackage = useAddPackage();
	const removePackage = useRemovePackage();
	const [name, setName] = (0, import_react.useState)("");
	const [start, setStart] = (0, import_react.useState)(TODAY_ISO);
	const [end, setEnd] = (0, import_react.useState)(TODAY_ISO);
	const [minNights, setMinNights] = (0, import_react.useState)("2");
	const [roomType, setRoomType] = (0, import_react.useState)("todas");
	async function onSubmit(event) {
		event.preventDefault();
		try {
			await addPackage.mutateAsync({
				name,
				start,
				end,
				minNights: Math.max(1, Number(minNights) || 1),
				roomType
			});
			setName("");
			toast.success("Pacote cadastrado");
		} catch {
			toast.error("Não foi possível cadastrar o pacote.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[22rem_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "grid gap-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Pacote especial"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Vinculado a datas com estadia mínima (ex.: mínimo 2 noites)."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Nome" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						value: name,
						onChange: (event) => setName(event.target.value),
						placeholder: "Lua de mel"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Início" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							required: true,
							value: start,
							onChange: (event) => setStart(event.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Término" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							required: true,
							value: end,
							onChange: (event) => setEnd(event.target.value)
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Mínimo de noites" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							inputMode: "numeric",
							value: minNights,
							onChange: (event) => setMinNights(event.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Categoria" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
							value: roomType,
							onChange: (event) => setRoomType(event.target.value),
							children: ROOM_FILTER.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item,
								children: item === "todas" ? "Todas" : item
							}, item))
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: addPackage.isPending,
					children: "Cadastrar pacote"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-border overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]",
			children: packages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center justify-between gap-3 px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: item.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						item.start,
						" → ",
						item.end,
						" · mín. ",
						item.minNights,
						" noites · ",
						item.roomType
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => void removePackage.mutateAsync(item.id),
					children: "Remover"
				})]
			}, item.id))
		})]
	});
}
function PromoCodesView() {
	const { data: promos = [] } = usePromos();
	const addPromo = useAddPromo();
	const removePromo = useRemovePromo();
	const [code, setCode] = (0, import_react.useState)("");
	const [kind, setKind] = (0, import_react.useState)("percent");
	const [value, setValue] = (0, import_react.useState)("10");
	const [start, setStart] = (0, import_react.useState)(TODAY_ISO);
	const [end, setEnd] = (0, import_react.useState)(TODAY_ISO);
	const [limit, setLimit] = (0, import_react.useState)("20");
	async function onSubmit(event) {
		event.preventDefault();
		try {
			await addPromo.mutateAsync({
				code,
				kind,
				value: Number(value),
				start,
				end,
				usageLimit: Math.max(1, Number(limit) || 1),
				active: true
			});
			setCode("");
			toast.success("Cupom cadastrado");
		} catch {
			toast.error("Não foi possível cadastrar o cupom.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[22rem_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "grid gap-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium tracking-tight",
					children: "Novo cupom"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Código" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						value: code,
						onChange: (event) => setCode(event.target.value.toUpperCase()),
						placeholder: "CLIENTEVIP"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Tipo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-11 rounded-md border border-input bg-card px-3 text-sm",
							value: kind,
							onChange: (event) => setKind(event.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "percent",
								children: "Percentual"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "fixed",
								children: "Valor fixo"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Desconto" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							inputMode: "decimal",
							value,
							onChange: (event) => setValue(event.target.value)
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Início" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							required: true,
							value: start,
							onChange: (event) => setStart(event.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Validade" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "date",
							required: true,
							value: end,
							onChange: (event) => setEnd(event.target.value)
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Limite de uso" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						inputMode: "numeric",
						value: limit,
						onChange: (event) => setLimit(event.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: addPromo.isPending,
					children: "Cadastrar cupom"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-border overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]",
			children: promos.map((promo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center justify-between gap-3 px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium tracking-wide",
					children: promo.code
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						promo.kind === "percent" ? `${promo.value}%` : formatCurrency(promo.value),
						" ",
						"· ",
						promo.start,
						" → ",
						promo.end,
						" · ",
						promo.usageCount,
						"/",
						promo.usageLimit,
						" usos"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => void removePromo.mutateAsync(promo.id),
					children: "Remover"
				})]
			}, promo.id))
		})]
	});
}
var ROOM_TYPES = [
	"Standard",
	"Luxo",
	"Suíte"
];
var TABS = [
	["tarifas", "Tarifas"],
	["pacotes", "Pacotes"],
	["cupons", "Cupons"],
	["ofertas", "Ofertas"]
];
var tarifasRoute = getRouteApi("/tarifas");
function abaFromSearch(aba) {
	if (aba === "pacotes" || aba === "cupons" || aba === "ofertas" || aba === "tarifas") return aba;
	return "tarifas";
}
function RateManagementView() {
	const { aba } = tarifasRoute.useSearch();
	const navigate = useNavigate({ from: "/tarifas" });
	const [tab, setTab] = (0, import_react.useState)(() => abaFromSearch(aba));
	const { data: categories = [] } = useCategoryRates();
	const { data: seasons = [] } = useSeasons();
	const { data: roomTypes = [] } = useRoomTypes();
	const { data: saleCloses = [] } = useSaleCloses();
	const createClose = useCreateSaleClose();
	const removeClose = useRemoveSaleClose();
	const patchRate = usePatchCategoryRate();
	const addSeason = useAddSeason();
	const removeSeason = useRemoveSeason();
	const [draft, setDraft] = (0, import_react.useState)();
	const matrix = (0, import_react.useMemo)(() => {
		if (draft) return draft;
		const next = {};
		for (const row of categories) {
			next[`${row.type}-weekday`] = { ...row.weekday };
			next[`${row.type}-weekend`] = { ...row.weekend };
		}
		return next;
	}, [categories, draft]);
	const [seasonName, setSeasonName] = (0, import_react.useState)("");
	const [seasonStart, setSeasonStart] = (0, import_react.useState)(TODAY_ISO);
	const [seasonEnd, setSeasonEnd] = (0, import_react.useState)(TODAY_ISO);
	const [modifier, setModifier] = (0, import_react.useState)("percent");
	const [seasonValue, setSeasonValue] = (0, import_react.useState)("30");
	const [minNights, setMinNights] = (0, import_react.useState)("3");
	const [quoteType, setQuoteType] = (0, import_react.useState)("Standard");
	const [quoteIn, setQuoteIn] = (0, import_react.useState)(TODAY_ISO);
	const [quoteOut, setQuoteOut] = (0, import_react.useState)(() => toISODate(addDays(parseISODate(TODAY_ISO), 1)));
	const [quotePax, setQuotePax] = (0, import_react.useState)(2);
	const [quoteChildren, setQuoteChildren] = (0, import_react.useState)(0);
	const [quotePromo, setQuotePromo] = (0, import_react.useState)("");
	const [quoteSegment, setQuoteSegment] = (0, import_react.useState)("balcao");
	const [siteDraft, setSiteDraft] = (0, import_react.useState)(null);
	const siteOf = (type) => siteDraft?.[type] ?? categories.find((row) => row.type === type)?.sitePercent ?? 0;
	const liveCategories = (0, import_react.useMemo)(() => ROOM_TYPES.map((type) => {
		const weekday = fillBand(matrix[`${type}-weekday`]);
		const weekend = fillBand(matrix[`${type}-weekend`]);
		return {
			type,
			weekday,
			weekend,
			weekdayRate: weekday.adl2,
			weekendRate: weekend.adl2,
			sitePercent: siteOf(type)
		};
	}), [
		matrix,
		siteDraft,
		categories
	]);
	const quoteOutSafe = quoteOut > quoteIn ? quoteOut : toISODate(addDays(parseISODate(quoteIn), 1));
	const quote = quoteStay(quoteType, quoteIn, quoteOutSafe, {
		adults: quotePax,
		children: quoteChildren,
		promoCode: quotePromo || void 0,
		segment: quoteSegment,
		categories: liveCategories
	});
	const [monthCursor, setMonthCursor] = (0, import_react.useState)(() => startOfMonth(parseISODate(TODAY_ISO)));
	const [paintMode, setPaintMode] = (0, import_react.useState)("simular");
	const monthDays = (0, import_react.useMemo)(() => {
		const start = startOfWeek(startOfMonth(monthCursor), { weekStartsOn: 1 });
		const end = addDays(start, 41);
		return eachDayOfInterval({
			start,
			end
		});
	}, [monthCursor]);
	const monthPaints = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const day of monthDays) {
			const iso = toISODate(day);
			map.set(iso, paintNight(quoteType, iso, {
				adults: quotePax,
				children: quoteChildren,
				categories: liveCategories,
				seasons
			}));
		}
		return map;
	}, [
		monthDays,
		quoteType,
		quotePax,
		quoteChildren,
		liveCategories,
		seasons
	]);
	const firstNight = quote.nightsDetail[0];
	const quoteProfile = roomTypes.find((row) => row.type === quoteType);
	const quoteFits = quoteProfile ? typeHoldsParty(quoteProfile, quotePax, quoteChildren) : true;
	(0, import_react.useEffect)(() => {
		setTab(abaFromSearch(aba));
	}, [aba]);
	function selectTab(id) {
		setTab(id);
		navigate({ search: { aba: id === "tarifas" ? void 0 : id } });
	}
	function updateBand(key, field, value) {
		const current = fillBand(matrix[key]);
		setDraft({
			...matrix,
			[key]: {
				...current,
				[field]: Number(value) || 0
			}
		});
	}
	async function onCalendarDay(iso, day) {
		if (paintMode === "simular") {
			setQuoteIn(iso);
			setQuoteOut(toISODate(addDays(day, 1)));
			return;
		}
		const hit = saleCloseOnNight(saleCloses, quoteType, iso);
		try {
			if (hit) {
				await removeClose.mutateAsync(hit.id);
				toast.success(`Venda reaberta · ${quoteType} ${iso}`);
				return;
			}
			await createClose.mutateAsync({
				roomType: quoteType,
				checkIn: iso,
				checkOut: toISODate(addDays(day, 1)),
				reason: "Fechado no tarifário"
			});
			toast.success(`Venda fechada · ${quoteType} ${iso}`);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Não foi possível alterar a venda.");
		}
	}
	async function saveRates() {
		try {
			for (const type of ROOM_TYPES) await patchRate.mutateAsync({
				type,
				weekday: matrix[`${type}-weekday`],
				weekend: matrix[`${type}-weekend`],
				sitePercent: siteOf(type)
			});
			setDraft(void 0);
			setSiteDraft(null);
			toast.success("Tarifas atualizadas · reservas já feitas mantêm o preço");
		} catch {
			toast.error("Não foi possível salvar as tarifas.");
		}
	}
	async function onAddSeason(event) {
		event.preventDefault();
		try {
			await addSeason.mutateAsync({
				name: seasonName,
				start: seasonStart,
				end: seasonEnd,
				modifier,
				value: Number(seasonValue),
				minNights: Math.max(1, Number(minNights) || 1)
			});
			setSeasonName("");
			toast.success("Temporada cadastrada");
		} catch {
			toast.error("Não foi possível cadastrar a temporada.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Comercial"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "Tarifas e ofertas"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Diárias, temporadas, pacotes, cupons e regras de pagamento."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 rounded-full bg-secondary p-1 sm:grid-cols-4",
				children: TABS.map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("h-10 rounded-full text-sm font-medium", tab === id ? "bg-card text-foreground shadow-[var(--shadow-border)]" : "text-muted-foreground"),
					onClick: () => selectTab(id),
					children: label
				}, id))
			}),
			tab === "cupons" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromoCodesView, {}) : null,
			tab === "pacotes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackagesView, {}) : null,
			tab === "ofertas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OffersView, {}) : null,
			tab === "tarifas" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "overflow-x-auto rounded-xl bg-card shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[60rem] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-secondary text-xs tracking-wide text-muted-foreground uppercase",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 font-medium",
									children: "Categoria"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 font-medium",
									children: "Período"
								}),
								OCCUPANCY_FIELDS.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 font-medium",
									children: OCCUPANCY_LABEL[field]
								}, field))
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: ROOM_TYPES.flatMap((type) => ["weekday", "weekend"].map((period) => {
							const key = `${type}-${period}`;
							const band = matrix[key];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-border",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 font-medium",
										children: type
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3 text-muted-foreground",
										children: period === "weekday" ? "Seg–Qui" : "Sex–Dom"
									}),
									OCCUPANCY_FIELDS.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-4 py-3",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											inputMode: "numeric",
											value: band?.[field] ?? "",
											onChange: (event) => updateBand(key, field, event.target.value)
										})
									}, field))
								]
							}, key);
						})) })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex justify-end border-t border-border p-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void saveRates(),
							disabled: patchRate.isPending,
							children: "Salvar tarifas"
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium tracking-tight",
							children: "Diária do site"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "A grelha é o balcão. No site, aplique desconto ou acréscimo sobre essa diária. 0 = igual."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid gap-4 sm:grid-cols-3",
							children: ROOM_TYPES.map((type) => {
								const signed = siteOf(type);
								const mode = signed < 0 ? "desconto" : "acrescimo";
								const amount = Math.abs(signed);
								const write = (nextMode, nextAmount) => {
									const percent = nextMode === "desconto" ? -Math.abs(nextAmount) : Math.abs(nextAmount);
									setSiteDraft({
										Standard: siteOf("Standard"),
										Luxo: siteOf("Luxo"),
										Suíte: siteOf("Suíte"),
										[type]: clampSitePercent(percent)
									});
								};
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: type }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-2 gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: mode === "desconto" ? "default" : "outline",
												onClick: () => write("desconto", amount),
												children: "Desconto"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												type: "button",
												variant: mode === "acrescimo" ? "default" : "outline",
												onClick: () => write("acrescimo", amount),
												children: "Acréscimo"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											inputMode: "numeric",
											value: String(amount),
											onChange: (event) => {
												const raw = event.target.value.replace(/\D/g, "");
												write(mode, clampSitePercent(raw === "" ? 0 : raw));
											}
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted-foreground",
											children: amount === 0 ? "Site igual ao balcão" : mode === "desconto" ? `Site ${amount}% mais barato` : `Site ${amount}% mais caro`
										})
									]
								}, type);
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-xl font-medium tracking-tight",
								children: ["Calendário · ", quoteType]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										size: "icon",
										className: "size-9",
										"aria-label": "Mês anterior",
										onClick: () => setMonthCursor((current) => addMonths(current, -1)),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "min-w-36 text-center text-sm font-medium capitalize",
										children: format(monthCursor, "MMMM yyyy", { locale: ptBR })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										size: "icon",
										className: "size-9",
										"aria-label": "Próximo mês",
										onClick: () => setMonthCursor((current) => addMonths(current, 1)),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Simular escolhe a noite. Fechar venda trava o tipo neste dia (mesmo cofre da aba Hotel)."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								variant: paintMode === "simular" ? "default" : "outline",
								onClick: () => setPaintMode("simular"),
								children: "Simular"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								variant: paintMode === "fechar" ? "default" : "outline",
								onClick: () => setPaintMode("fechar"),
								children: "Fechar venda"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid grid-cols-7 gap-1 text-center text-[11px] text-muted-foreground uppercase",
							children: [
								"Seg",
								"Ter",
								"Qua",
								"Qui",
								"Sex",
								"Sáb",
								"Dom"
							].map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }, label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 grid grid-cols-7 gap-1",
							children: monthDays.map((day) => {
								const iso = toISODate(day);
								const inMonth = day.getMonth() === monthCursor.getMonth();
								const paint = monthPaints.get(iso);
								const selected = iso === quoteIn;
								const closed = Boolean(saleCloseOnNight(saleCloses, quoteType, iso));
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									disabled: !inMonth || createClose.isPending || removeClose.isPending,
									onClick: () => void onCalendarDay(iso, day),
									className: cn("flex min-h-16 flex-col items-center justify-center rounded-md border-2 px-1 py-1 text-xs tabular-nums", !inMonth && "opacity-30", inMonth && paint?.weekend && !closed && "bg-primary/15", inMonth && paint && !paint.weekend && !closed && "bg-secondary", inMonth && paint?.season && !closed ? "border-status-pending bg-status-pending/25" : !closed && "border-transparent", closed && "border-destructive bg-destructive/20 text-destructive line-through", selected && !closed && "border-primary"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: format(day, "d")
									}), inMonth && closed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] leading-tight",
										children: "Fechado"
									}) : inMonth && paint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] leading-tight",
										children: formatCurrency(paint.amount)
									}) : null]
								}, iso);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 flex flex-wrap gap-4 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-sm bg-secondary" }), " Seg–Qui"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-sm bg-primary/15" }), " Sex–Dom"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-sm border-2 border-destructive bg-destructive/20" }), " Fechado"]
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-6 lg:grid-cols-[1fr_20rem]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: onAddSeason,
						className: "grid gap-3 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-xl font-medium tracking-tight",
								children: "Temporada / feriado"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "season-name",
									children: "Nome"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "season-name",
									required: true,
									value: seasonName,
									onChange: (event) => setSeasonName(event.target.value),
									placeholder: "Réveillon"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Início" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										required: true,
										value: seasonStart,
										onChange: (event) => setSeasonStart(event.target.value)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Término" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "date",
										required: true,
										value: seasonEnd,
										onChange: (event) => setSeasonEnd(event.target.value)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Modificador" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: "h-9 rounded-lg border border-input bg-card px-3 text-sm",
										value: modifier,
										onChange: (event) => setModifier(event.target.value),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "percent",
											children: "Acréscimo %"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "fixed",
											children: "Valor fixo / diária"
										})]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Valor" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										required: true,
										inputMode: "decimal",
										value: seasonValue,
										onChange: (event) => setSeasonValue(event.target.value)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Mínimo de noites" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									required: true,
									inputMode: "numeric",
									value: minNights,
									onChange: (event) => setMinNights(event.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: addSeason.isPending,
								children: "Cadastrar regra"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium tracking-tight",
							children: "Simular reserva"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: "h-9 rounded-lg border border-input bg-card px-3 text-sm",
									value: quoteType,
									onChange: (event) => setQuoteType(event.target.value),
									children: ROOM_TYPES.map((type) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: type }, type))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: quoteSegment === "balcao" ? "default" : "outline",
										onClick: () => setQuoteSegment("balcao"),
										children: "Balcão"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: quoteSegment === "site" ? "default" : "outline",
										onClick: () => setQuoteSegment("site"),
										children: "Site"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: "h-9 rounded-lg border border-input bg-card px-3 text-sm",
										value: quotePax,
										onChange: (event) => setQuotePax(Number(event.target.value)),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 1,
												children: "1 adulto"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 2,
												children: "2 adultos"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 3,
												children: "3 adultos"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 4,
												children: "4 adultos"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 5,
												children: "5 adultos"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 6,
												children: "6 adultos"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										className: "h-9 rounded-lg border border-input bg-card px-3 text-sm",
										value: quoteChildren,
										onChange: (event) => setQuoteChildren(Number(event.target.value)),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 0,
												children: "0 crianças"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 1,
												children: "1 criança"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 2,
												children: "2 crianças"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 3,
												children: "3 crianças"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: 4,
												children: "4 crianças"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: quoteIn,
									onChange: (event) => {
										const next = event.target.value || TODAY_ISO;
										setQuoteIn(next);
										if (!(quoteOut > next)) setQuoteOut(toISODate(addDays(parseISODate(next), 1)));
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									min: quoteIn,
									value: quoteOutSafe,
									onChange: (event) => setQuoteOut(event.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: quotePromo,
									onChange: (event) => setQuotePromo(event.target.value.toUpperCase()),
									placeholder: "Cupom (CLIENTEVIP)"
								}),
								!quoteFits ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border-2 border-destructive bg-destructive/15 p-4 text-destructive",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-lg font-semibold leading-tight",
										children: "Capacidade excedida"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm",
										children: [
											quoteType,
											" cabe ",
											quoteProfile?.maxAdults ?? "?",
											" adulto(s) e",
											" ",
											quoteProfile?.maxChildren ?? 0,
											" criança(s). Recepção pode confirmar: entra taxa extra +ADL / +CHD."
										]
									})]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground",
									children: [
										firstNight?.weekend ? "Linha Sex–Dom" : "Linha Seg–Qui",
										" ·",
										" ",
										quotePax,
										" ADL",
										quoteChildren ? ` + ${quoteChildren} CHD` : "",
										firstNight ? ` · tabela ${formatCurrency(firstNight.base)}` : ""
									]
								}),
								firstNight?.season ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground",
									children: [
										"Temporada ",
										firstNight.season.name,
										" nesta data — por isso o total não é só a tabela."
									]
								}) : null,
								quote.offerDiscountTotal > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground",
									children: ["Oferta −", formatCurrency(quote.offerDiscountTotal)]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm",
									children: [
										quote.nights,
										" noites · média ",
										formatCurrency(quote.averageNight)
									]
								}),
								quote.discount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground",
									children: [
										"Subtotal ",
										formatCurrency(quote.subtotal),
										" − cupom ",
										formatCurrency(quote.discount)
									]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xl font-medium tabular-nums",
									children: formatCurrency(quote.total)
								}),
								!quote.minNightsOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-status-pending",
									children: [
										"Mínimo do pacote/temporada: ",
										quote.minNightsRequired,
										" noites"
									]
								}) : null
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "rounded-xl bg-card shadow-[var(--shadow-border)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-border",
						children: seasons.map((season) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-center justify-between gap-3 px-5 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: season.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: [
									season.start,
									" → ",
									season.end,
									" ·",
									" ",
									season.modifier === "percent" ? `+${season.value}%` : `+${formatCurrency(season.value)}/noite`,
									" ",
									"· mín. ",
									season.minNights,
									" noites"
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => void removeSeason.mutateAsync(season.id),
								children: "Remover"
							})]
						}, season.id))
					})
				})
			] }) : null
		]
	});
}
var SplitComponent = RateManagementView;
//#endregion
export { SplitComponent as component };
