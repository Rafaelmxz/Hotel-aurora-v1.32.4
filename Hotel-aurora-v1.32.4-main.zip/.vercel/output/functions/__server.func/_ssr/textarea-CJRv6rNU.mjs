import "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { Pt as cn } from "./router-D2QglEY4.mjs";
require_react();
var import_jsx_runtime = require_jsx_runtime();
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		"data-slot": "textarea",
		className: cn("min-h-24 w-full rounded-md border border-input bg-card px-3 py-2.5 text-sm text-foreground shadow-[var(--shadow-border)] outline-none transition-shadow duration-150", "placeholder:text-muted-foreground", "focus-visible:border-ring focus-visible:ring-ring/40 focus-visible:ring-[3px]", "disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
//#endregion
export { Textarea as t };
