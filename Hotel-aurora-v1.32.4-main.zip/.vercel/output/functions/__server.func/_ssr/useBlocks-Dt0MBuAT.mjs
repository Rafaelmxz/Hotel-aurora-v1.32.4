import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { E as persistVault, Ot as reservationKeys, U as createBlock, V as blockKeys, bt as removeBlock, st as listReservations, tt as listBlocks, x as ensureVaultRestored } from "./router-D2QglEY4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useBlocks-Dt0MBuAT.js
function useBlocks() {
	return useQuery({
		queryKey: blockKeys.all,
		queryFn: async () => {
			await ensureVaultRestored();
			return listBlocks();
		},
		placeholderData: () => listBlocks()
	});
}
async function syncBlocks(queryClient) {
	await persistVault();
	queryClient.setQueryData(blockKeys.all, listBlocks());
	await queryClient.invalidateQueries({ queryKey: blockKeys.all });
	await queryClient.invalidateQueries({ queryKey: reservationKeys.all });
}
function useCreateBlock() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => createBlock(input, listReservations()),
		onSuccess: async () => {
			await syncBlocks(queryClient);
		}
	});
}
function useRemoveBlock() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (id) => {
			removeBlock(id);
		},
		onSuccess: async () => {
			await syncBlocks(queryClient);
		}
	});
}
//#endregion
export { useCreateBlock as n, useRemoveBlock as r, useBlocks as t };
