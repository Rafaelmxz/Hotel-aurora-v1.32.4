import { A as getBookingConfig, at as saveBookingConfig, x as bookingKeys } from "./bookingStore-Bq0ubAXy.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { E as persistVault } from "./router-D2QglEY4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useBookingEngine-1wAIPgj0.js
function useBookingConfig() {
	return useQuery({
		queryKey: bookingKeys.config,
		queryFn: async () => getBookingConfig(),
		initialData: () => getBookingConfig()
	});
}
function useSaveBookingConfig() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (next) => {
			const saved = saveBookingConfig(next);
			await persistVault();
			return saved;
		},
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: bookingKeys.config });
		}
	});
}
//#endregion
export { useSaveBookingConfig as n, useBookingConfig as t };
