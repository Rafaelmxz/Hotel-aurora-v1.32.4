import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { Q as guestKeys, X as getGuest, Z as getGuestStats, jt as searchGuests, rt as listGuests } from "./router-D2QglEY4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useGuests-BJjZTm3Q.js
function useGuests() {
	return useQuery({
		queryKey: guestKeys.all,
		queryFn: async () => listGuests(),
		initialData: () => listGuests()
	});
}
function useGuestSearch(query) {
	return useQuery({
		queryKey: [
			...guestKeys.all,
			"search",
			query
		],
		queryFn: async () => searchGuests(query),
		initialData: () => searchGuests(query)
	});
}
function useGuestProfile(id) {
	return useQuery({
		queryKey: guestKeys.byId(id),
		queryFn: async () => {
			const guest = getGuest(id);
			return guest ? getGuestStats(guest) : null;
		},
		initialData: () => {
			const guest = getGuest(id);
			return guest ? getGuestStats(guest) : null;
		}
	});
}
//#endregion
export { useGuestSearch as n, useGuests as r, useGuestProfile as t };
