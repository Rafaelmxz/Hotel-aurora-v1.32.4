import { L as listSaleCloses, h as assertStayTransition } from "./bookingStore-Bq0ubAXy.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { C as listRooms, Dt as replaceReservations, E as persistVault, F as addConsumo, J as folioKeys, O as restoreVault, Ot as reservationKeys, Q as guestKeys, R as addPagamento, W as createReservation, Y as getFolio, b as detectVaultMode, gt as patchReservation, k as roomKeys, st as listReservations, tt as listBlocks, w as markRoomDirty, wt as removePagamento, x as ensureVaultRestored, xt as removeConsumo } from "./router-D2QglEY4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useReservations-BEok-WZp.js
function useReservations() {
	return useQuery({
		queryKey: reservationKeys.all,
		queryFn: async () => {
			await ensureVaultRestored();
			if (detectVaultMode() === "staff") await restoreVault();
			return listReservations();
		},
		placeholderData: () => listReservations(),
		staleTime: 4e3,
		refetchOnWindowFocus: true,
		refetchInterval: () => typeof window !== "undefined" && detectVaultMode() === "staff" ? 1e4 : false
	});
}
async function syncReservationQueries(queryClient, updated) {
	await persistVault();
	if (updated) queryClient.setQueryData(reservationKeys.all, (current) => {
		return (current ?? listReservations()).map((row) => row.id === updated.id ? updated : row);
	});
	else queryClient.setQueryData(reservationKeys.all, listReservations());
	await queryClient.invalidateQueries({ queryKey: reservationKeys.all });
	await queryClient.refetchQueries({ queryKey: reservationKeys.all });
	await queryClient.invalidateQueries({ queryKey: folioKeys.all });
	await queryClient.invalidateQueries({ queryKey: roomKeys.all });
}
function usePatchReservation() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async ({ id, ...patch }) => {
			const current = listReservations().find((row) => row.id === id);
			if (!current) throw new Error("Reserva não encontrada");
			const next = {
				...current,
				...patch
			};
			assertStayTransition({
				previous: current,
				next,
				reservations: listReservations(),
				rooms: listRooms(),
				saldo: getFolio(id).totais.saldo,
				blocks: listBlocks(),
				saleCloses: listSaleCloses()
			});
			const updated = patchReservation(id, patch);
			if (current.status !== "check-out" && updated.status === "check-out") markRoomDirty(updated.roomId);
			return updated;
		},
		onSuccess: async (updated) => {
			await syncReservationQueries(queryClient, updated);
		}
	});
}
function useCreateReservation() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => createReservation(input),
		onSuccess: async (created) => {
			await queryClient.invalidateQueries({ queryKey: guestKeys.all });
			await syncReservationQueries(queryClient, created);
		}
	});
}
function useCreatePublicReservation() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => {
			const autoConfirm = input.payMode === "pix" && Boolean(input.deposit && input.deposit.valor > 0);
			const created = createReservation({
				roomId: input.roomId,
				guestName: input.guestName,
				guestEmail: input.guestEmail,
				checkIn: input.checkIn,
				checkOut: input.checkOut,
				notes: input.notes,
				guests: input.guests,
				adults: input.adults,
				children: input.children,
				status: autoConfirm ? "confirmada" : "pendente",
				origin: "Link público",
				pix: input.payMode === "pix"
			});
			const extraItems = (input.extras ?? []).filter((line) => line.quantity > 0 && line.unitPrice >= 0).map((line) => addConsumo({
				id: `csm-extra-${line.id}-${created.id}`,
				reserva_id: created.id,
				descricao: line.name,
				valor: line.unitPrice,
				quantidade: line.quantity
			}));
			const deposit = autoConfirm && input.deposit ? addPagamento({
				id: `pag-sinal-${created.id}`,
				reserva_id: created.id,
				valor: input.deposit.valor,
				metodo: "pix",
				descricao: "Sinal Pix da reserva",
				observacao: input.deposit.comprovante ? `Comprovante: ${input.deposit.comprovante}` : void 0
			}) : void 0;
			try {
				const { submitPublicBookingFn } = await import("./api-iTCU0mCO.mjs").then((n) => n.t);
				await submitPublicBookingFn({ data: {
					id: created.id,
					roomId: created.roomId,
					guestName: created.guestName,
					guestEmail: created.guestEmail,
					checkIn: created.checkIn,
					checkOut: created.checkOut,
					guests: created.guests,
					nightlyRate: created.nightlyRate,
					totalAmount: created.totalAmount,
					notes: created.notes,
					status: created.status === "confirmada" ? "confirmada" : "pendente",
					extras: (input.extras ?? []).map((line) => ({
						id: line.id,
						descricao: line.name,
						valor: line.unitPrice,
						quantidade: line.quantity
					})),
					deposit: deposit ? {
						id: deposit.id,
						valor: deposit.valor,
						metodo: deposit.metodo,
						descricao: deposit.descricao,
						observacao: deposit.observacao,
						data_pagamento: deposit.data_pagamento
					} : void 0
				} });
				return created;
			} catch (error) {
				replaceReservations(listReservations().filter((row) => row.id !== created.id));
				if (deposit) removePagamento(deposit.id);
				for (const item of extraItems) removeConsumo(item.id);
				throw error;
			}
		},
		onSuccess: async (created) => {
			queryClient.setQueryData(reservationKeys.all, (current) => {
				const list = current ?? listReservations();
				return list.some((row) => row.id === created.id) ? list : [...list, created];
			});
			await queryClient.invalidateQueries({ queryKey: reservationKeys.all });
			await queryClient.invalidateQueries({ queryKey: folioKeys.all });
		}
	});
}
//#endregion
export { useReservations as a, usePatchReservation as i, useCreatePublicReservation as n, useCreateReservation as r, syncReservationQueries as t };
