import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { At as saveRoomTypes, E as persistVault, ct as listRoomTypes, kt as roomTypeKeys } from "./router-D2QglEY4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useRoomTypes-B7WZBIgo.js
function useRoomTypes() {
	return useQuery({
		queryKey: roomTypeKeys.all,
		queryFn: async () => listRoomTypes(),
		initialData: () => listRoomTypes()
	});
}
function useSaveRoomTypes() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (rows) => {
			const saved = saveRoomTypes(rows);
			await persistVault();
			return saved;
		},
		onSuccess: (saved) => {
			queryClient.setQueryData(roomTypeKeys.all, saved);
		}
	});
}
//#endregion
export { useSaveRoomTypes as n, useRoomTypes as t };
