import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { A as setRoomNote, C as listRooms, E as persistVault, T as patchRoomHousekeeping, k as roomKeys, w as markRoomDirty, x as ensureVaultRestored } from "./router-D2QglEY4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useRooms-DVLudIq6.js
function useRooms() {
	return useQuery({
		queryKey: roomKeys.all,
		queryFn: async () => {
			await ensureVaultRestored();
			return listRooms();
		},
		placeholderData: () => listRooms()
	});
}
function usePatchHousekeeping() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async ({ id, housekeepingStatus, note }) => patchRoomHousekeeping(id, housekeepingStatus, { note }),
		onSuccess: async (room) => {
			await persistVault();
			queryClient.setQueryData(roomKeys.all, (current) => (current ?? listRooms()).map((row) => row.id === room.id ? room : row));
			await queryClient.invalidateQueries({ queryKey: roomKeys.all });
		}
	});
}
function useSetRoomNote() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async ({ id, note }) => setRoomNote(id, note),
		onSuccess: async (room) => {
			await persistVault();
			queryClient.setQueryData(roomKeys.all, (current) => (current ?? listRooms()).map((row) => row.id === room.id ? room : row));
			await queryClient.invalidateQueries({ queryKey: roomKeys.all });
		}
	});
}
function useMarkRoomDirty() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (id) => markRoomDirty(id),
		onSuccess: async () => {
			await persistVault();
			await queryClient.invalidateQueries({ queryKey: roomKeys.all });
		}
	});
}
//#endregion
export { useSetRoomNote as i, usePatchHousekeeping as n, useRooms as r, useMarkRoomDirty as t };
