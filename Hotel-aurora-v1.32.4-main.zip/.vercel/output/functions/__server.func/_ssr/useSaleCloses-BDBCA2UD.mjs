import { C as createSaleClose, L as listSaleCloses, Y as removeSaleClose, rt as saleCloseKeys } from "./bookingStore-Bq0ubAXy.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { E as persistVault, Ot as reservationKeys, x as ensureVaultRestored } from "./router-D2QglEY4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/useSaleCloses-BDBCA2UD.js
function useSaleCloses() {
	return useQuery({
		queryKey: saleCloseKeys.all,
		queryFn: async () => {
			await ensureVaultRestored();
			return listSaleCloses();
		},
		placeholderData: () => listSaleCloses()
	});
}
async function syncCloses(queryClient) {
	await persistVault();
	queryClient.setQueryData(saleCloseKeys.all, listSaleCloses());
	await queryClient.invalidateQueries({ queryKey: saleCloseKeys.all });
	await queryClient.invalidateQueries({ queryKey: reservationKeys.all });
}
function useCreateSaleClose() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (input) => createSaleClose(input),
		onSuccess: async () => {
			await syncCloses(queryClient);
		}
	});
}
function useRemoveSaleClose() {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: async (id) => {
			removeSaleClose(id);
		},
		onSuccess: async () => {
			await syncCloses(queryClient);
		}
	});
}
//#endregion
export { useRemoveSaleClose as n, useSaleCloses as r, useCreateSaleClose as t };
