//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CGF0VdpQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/__root.tsx",
		children: [
			"/",
			"/caixa",
			"/calendario",
			"/casa",
			"/configuracoes",
			"/equipe",
			"/governanca",
			"/hospedes",
			"/login",
			"/ocupacao",
			"/ofertas",
			"/relatorios",
			"/reservar",
			"/reservas",
			"/reservas-diretas",
			"/tarifas",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-DnFbtHZ3.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/react-dom-B4_apJ_4.js",
			"/assets/invariant-DVltax7q.js",
			"/assets/link-C_7isAnY.js",
			"/assets/redirect-x-CWao5M.js",
			"/assets/route-BQADVl2l.js",
			"/assets/jsx-runtime-0vZSBttN.js",
			"/assets/useNavigate-BiBXdZvA.js",
			"/assets/createLucideIcon-BMzGw82M.js",
			"/assets/guestStore-BGARdKc_.js",
			"/assets/hydrate-tOyQBV9H.js",
			"/assets/button-B9od9uCY.js",
			"/assets/dist-BDKNzfzt.js",
			"/assets/utils-DojpP95n.js",
			"/assets/use-current-user-BWonrY4M.js",
			"/assets/preload-helper-BZ1Pz5am.js",
			"/assets/input-B3MdOTDw.js",
			"/assets/label-DcvcuPi5.js",
			"/assets/client-CVxY-SCP.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DnFbtHZ3.js"
		} }]
	},
	"/": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DlDEcyTW.js",
			"/assets/PendingBookingsAlert-CZN5rNlu.js",
			"/assets/card-BoXF_SR6.js",
			"/assets/useReservations-vT4IF9ky.js",
			"/assets/useRooms-vr2gWJ7z.js",
			"/assets/badge--cED0GFC.js",
			"/assets/status-Bah3E53i.js"
		]
	},
	"/caixa": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/caixa.tsx",
		children: void 0,
		preloads: [
			"/assets/caixa-BVjQqlRV.js",
			"/assets/printer-DCERmf0c.js",
			"/assets/card-BoXF_SR6.js",
			"/assets/textarea-CEbBXiwV.js",
			"/assets/useReservations-vT4IF9ky.js"
		]
	},
	"/calendario": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/calendario.tsx",
		children: void 0,
		preloads: [
			"/assets/calendario-BgH-Hmn0.js",
			"/assets/PendingBookingsAlert-CZN5rNlu.js",
			"/assets/FolioStatement-CWWrI-L3.js",
			"/assets/textarea-CEbBXiwV.js",
			"/assets/useReservations-vT4IF9ky.js",
			"/assets/useRooms-vr2gWJ7z.js",
			"/assets/badge--cED0GFC.js",
			"/assets/StayVoucher-T54b9Hd5.js",
			"/assets/status-Bah3E53i.js",
			"/assets/useBookingEngine-BTL5F3F4.js",
			"/assets/useBlocks-CxNtC9dE.js",
			"/assets/useSaleCloses-zHXpWUjx.js"
		]
	},
	"/casa": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/casa.tsx",
		children: void 0,
		preloads: [
			"/assets/casa-BzWWvPuq.js",
			"/assets/check-CYwgOhU4.js",
			"/assets/mail-C7V2Hl1L.js",
			"/assets/textarea-CEbBXiwV.js",
			"/assets/useReservations-vT4IF9ky.js",
			"/assets/useRooms-vr2gWJ7z.js",
			"/assets/useBlocks-CxNtC9dE.js",
			"/assets/useSaleCloses-zHXpWUjx.js"
		]
	},
	"/configuracoes": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/configuracoes.tsx",
		children: void 0,
		preloads: [
			"/assets/configuracoes-B1rFurUz.js",
			"/assets/api-BnN4Zly0.js",
			"/assets/textarea-CEbBXiwV.js",
			"/assets/useReservations-vT4IF9ky.js",
			"/assets/useRooms-vr2gWJ7z.js",
			"/assets/useRoomTypes-DjRbCgPt.js",
			"/assets/useBlocks-CxNtC9dE.js",
			"/assets/useSaleCloses-zHXpWUjx.js"
		]
	},
	"/equipe": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/equipe.tsx",
		children: void 0,
		preloads: ["/assets/equipe-C6Y_xY39.js"]
	},
	"/governanca": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/governanca.tsx",
		children: void 0,
		preloads: [
			"/assets/governanca-E3MdYN29.js",
			"/assets/check-CYwgOhU4.js",
			"/assets/textarea-CEbBXiwV.js",
			"/assets/useReservations-vT4IF9ky.js",
			"/assets/useRooms-vr2gWJ7z.js"
		]
	},
	"/hospedes": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/hospedes.tsx",
		children: ["/hospedes/$guestId"],
		preloads: ["/assets/hospedes-I0vDqW79.js", "/assets/useGuests-DI30Cy0x.js"]
	},
	"/login": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/login.tsx",
		children: void 0,
		preloads: ["/assets/login-B0YWINLQ.js"]
	},
	"/ocupacao": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/ocupacao.tsx",
		children: void 0,
		preloads: ["/assets/ocupacao-C9li4Obz.js", "/assets/useReservations-vT4IF9ky.js"]
	},
	"/ofertas": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/ofertas.tsx",
		children: void 0,
		preloads: ["/assets/ofertas-DJ7LAi8J.js"]
	},
	"/relatorios": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/relatorios.tsx",
		children: void 0,
		preloads: [
			"/assets/relatorios-Drc7hDqa.js",
			"/assets/printer-DCERmf0c.js",
			"/assets/card-BoXF_SR6.js",
			"/assets/useReservations-vT4IF9ky.js"
		]
	},
	"/reservar": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/reservar.tsx",
		children: void 0,
		preloads: [
			"/assets/reservar-C1PSFFwV.js",
			"/assets/check-CYwgOhU4.js",
			"/assets/useReservations-vT4IF9ky.js",
			"/assets/useRooms-vr2gWJ7z.js",
			"/assets/StayVoucher-T54b9Hd5.js",
			"/assets/useBookingEngine-BTL5F3F4.js",
			"/assets/useRoomTypes-DjRbCgPt.js",
			"/assets/useBlocks-CxNtC9dE.js",
			"/assets/useSaleCloses-zHXpWUjx.js"
		]
	},
	"/reservas": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/reservas.tsx",
		children: void 0,
		preloads: [
			"/assets/reservas-D3adIxOn.js",
			"/assets/useReservations-vT4IF9ky.js",
			"/assets/badge--cED0GFC.js",
			"/assets/status-Bah3E53i.js"
		]
	},
	"/reservas-diretas": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/reservas-diretas.tsx",
		children: void 0,
		preloads: [
			"/assets/reservas-diretas-BkQ6yJT9.js",
			"/assets/textarea-CEbBXiwV.js",
			"/assets/useBookingEngine-BTL5F3F4.js"
		]
	},
	"/tarifas": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/tarifas.tsx",
		children: void 0,
		preloads: [
			"/assets/tarifas-CAssKIjV.js",
			"/assets/useRoomTypes-DjRbCgPt.js",
			"/assets/useSaleCloses-zHXpWUjx.js"
		]
	},
	"/hospedes/$guestId": {
		filePath: "D:/Downloads/hotel aurora 1.34/Hotel-aurora-v1.32.4-main/src/routes/hospedes.$guestId.tsx",
		children: void 0,
		preloads: [
			"/assets/hospedes._guestId-DhAa7sVR.js",
			"/assets/FolioStatement-CWWrI-L3.js",
			"/assets/status-Bah3E53i.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
